
  # FINAL FINAL IIDA

  This is a code bundle for FINAL FINAL IIDA. The original project is available at https://www.figma.com/design/9IYyBME6KRdAxq54ym4ffr/FINAL-FINAL-IIDA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  