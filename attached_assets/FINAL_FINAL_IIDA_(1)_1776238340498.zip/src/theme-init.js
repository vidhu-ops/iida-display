// Theme initialization script - prevents flash of wrong theme
// This runs before React loads to immediately apply the saved theme
(function() {
  try {
    const savedTheme = localStorage.getItem('theme');
    const theme = savedTheme || 'dark';
    document.documentElement.classList.add(theme);
  } catch (e) {
    // If localStorage fails, default to dark
    document.documentElement.classList.add('dark');
  }
})();
