import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-8b98c69f/health", (c) => {
  return c.json({ status: "ok" });
});

// ─── Web Scraper Proxy ────────────────────────────────────────────────────────
// Proxies requests to external search APIs without CORS restrictions.
// Uses DuckDuckGo HTML search and Google Search grounding via Gemini.

const GEMINI_KEY = "AIzaSyDLF-2isNDoMKF0kBa_OotUUUJCPCvD9o0";
const GEMINI_GROUNDING_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
const GEMINI_STANDARD_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

/**
 * POST /make-server-8b98c69f/gemini
 * Body: { prompt: string, temperature?: number, useGrounding?: boolean }
 * Generic Gemini API proxy to avoid CORS issues
 */
app.post("/make-server-8b98c69f/gemini", async (c) => {
  try {
    const body = await c.req.json();
    const { prompt, temperature = 0.7, useGrounding = false } = body;

    if (!prompt) {
      return c.json({ error: "Missing prompt" }, 400);
    }

    const geminiBody: any = {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 8192,
        candidateCount: 1,
      },
      safetySettings: [
        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
      ],
    };

    if (useGrounding) {
      geminiBody.tools = [{ google_search: {} }];
    }

    const url = useGrounding ? GEMINI_GROUNDING_URL : GEMINI_STANDARD_URL;
    const geminiRes = await fetch(`${url}?key=${GEMINI_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(geminiBody),
    });

    if (!geminiRes.ok) {
      const errorText = await geminiRes.text();
      console.error("Gemini error:", errorText);
      return c.json({ error: `Gemini API error: ${geminiRes.status}`, details: errorText }, 502);
    }

    const geminiData = await geminiRes.json();
    const candidate = geminiData.candidates?.[0];
    const text = candidate?.content?.parts?.[0]?.text;

    if (!text) {
      return c.json({ error: "No response from Gemini API" }, 502);
    }

    const response: any = { text };

    if (useGrounding && candidate?.groundingMetadata) {
      response.grounding = {
        webSearchQueries: candidate.groundingMetadata.webSearchQueries,
        groundingChunks: candidate.groundingMetadata.groundingChunks,
      };
    }

    return c.json(response);
  } catch (err: any) {
    console.error("Gemini proxy error:", err);
    return c.json({ error: err?.message ?? "Internal server error" }, 500);
  }
});

/**
 * POST /make-server-8b98c69f/ddg-search
 * Body: { query: string }
 * Proxies a DuckDuckGo Instant Answer query (no CORS from browser)
 */
app.post("/make-server-8b98c69f/ddg-search", async (c) => {
  try {
    const { query } = await c.req.json();
    if (!query) return c.json({ error: "Missing query" }, 400);

    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(url);
    if (!res.ok) return c.json({ error: `DDG HTTP ${res.status}` }, 502);
    const data = await res.json();

    return c.json({
      abstract: data.AbstractText || "",
      related: (data.RelatedTopics || [])
        .filter((t: any) => t.Text)
        .slice(0, 8)
        .map((t: any) => ({ text: t.Text, url: t.FirstURL })),
    });
  } catch (err: any) {
    return c.json({ error: err?.message }, 500);
  }
});

Deno.serve(app.fetch);