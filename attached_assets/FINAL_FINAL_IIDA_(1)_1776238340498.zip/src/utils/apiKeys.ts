/**
 * API Key Manager — hardcoded keys, no localStorage or env var required.
 * The Claude key is always active; users never need to configure anything.
 */

// ─── Hardcoded API keys ────────────────────────────────────────────────────────
const CLAUDE_KEY = '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';
const GEMINI_KEY = ''; // Add a Gemini key here if Google Search Grounding is needed

// ─── Public accessors (used throughout the app) ────────────────────────────────

export function getGeminiKey(): string {
  return GEMINI_KEY;
}

export function getClaudeKey(): string {
  return CLAUDE_KEY;
}

// No-ops kept for API compatibility — nothing is written anywhere
export function setGeminiKey(_key: string): void {}
export function setClaudeKey(_key: string): void {}

export function hasGeminiKey(): boolean {
  return GEMINI_KEY.length > 0;
}

export function hasClaudeKey(): boolean {
  return CLAUDE_KEY.length > 0;
}

export function hasAnyKey(): boolean {
  return hasGeminiKey() || hasClaudeKey();
}
