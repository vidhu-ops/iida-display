# Light Mode Text Color Fixes for Business Plan

## Summary
The Business Plan page needs all text to be BLACK in light mode for proper contrast.

## What's Been Fixed ✅
- Main page header and title
- Table of Contents
- Reality Check section
- Executive Summary
- Company Description  
- Market Analysis header and industry overview
- All main Card containers now have white backgrounds in light mode

## Remaining Patterns to Fix ⚠️

The file `/components/BusinessPlanResults.tsx` still has ~100+ instances of hardcoded dark mode text colors that need to be replaced with black text for light mode.

### Pattern Replacements Needed:

1. **Headings (text-white)**
   - `text-white"` → `text-black dark:text-white transition-colors duration-300"`
   - `font-semibold text-lg text-white"` → `font-semibold text-lg text-black dark:text-white transition-colors duration-300"`
   - `font-bold text-white"` → `font-bold text-black dark:text-white transition-colors duration-300"`

2. **Body Text (text-zinc-300)**
   - `text-zinc-300"` → `text-black dark:text-zinc-300 transition-colors duration-300"`
   - `text-sm text-zinc-300"` → `text-sm text-black dark:text-zinc-300 transition-colors duration-300"`

3. **Background Boxes**
   - `bg-zinc-800` → `bg-gray-100 dark:bg-zinc-800 transition-colors duration-300`
   - `border-zinc-700` → `border-gray-300 dark:border-zinc-700 transition-colors duration-300`
   - `bg-zinc-700` → `bg-gray-200 dark:bg-zinc-700 transition-colors duration-300`

4. **Lists**
   - `list-disc list-inside text-zinc-300` → `list-disc list-inside text-black dark:text-zinc-300 transition-colors duration-300`

5. **Table Cells**
   - `p-2 text-zinc-300"` → `p-2 text-black dark:text-zinc-300 transition-colors duration-300"`

## Automated Fix Script

Run the Node.js script to apply all fixes at once:

```bash
node /scripts/fixBlackText.js
```

This script will systematically replace all the patterns above throughout the entire file.

## Manual Verification Points

After applying fixes, verify these sections in light mode:
- [ ] Market Analysis - Competitive Analysis cards
- [ ] Organization & Management - Team member cards
- [ ] Products & Services - Offering cards
- [ ] Marketing Strategy - Promotional strategy cards
- [ ] Operations Plan - Process details
- [ ] Financial Projections - Tables and charts
- [ ] Risk Analysis - Risk cards
- [ ] Implementation Timeline - Milestone cards
- [ ] Exit Strategy - Options

All text should be **black** on white backgrounds and **white** on dark backgrounds.
