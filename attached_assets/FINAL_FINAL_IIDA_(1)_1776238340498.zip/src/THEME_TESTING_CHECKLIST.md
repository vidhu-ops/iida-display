# 🧪 Theme Toggle - Complete Testing Checklist

## ✅ How to Test the Theme Toggle on Startup Dialog

### 🎯 Test 1: Initial Load (Dark Mode Default)

**Steps:**
1. Clear browser cache and localStorage
   - Chrome: DevTools → Application → Storage → Clear site data
   - Or run in console: `localStorage.clear()`
2. Refresh the page (Ctrl+Shift+R or Cmd+Shift+R)
3. Observe the startup dialog

**Expected Results:**
- ✅ Dialog appears with **black background**
- ✅ White text on dialog title
- ✅ Dark gray button cards
- ✅ Orange toggle button in top-right corner showing **🌙 Moon icon**
- ✅ No flash of white before dark theme applies
- ✅ Console shows: Theme applied on load

**Pass/Fail:** ___________

---

### 🎯 Test 2: Toggle to Light Mode

**Steps:**
1. With startup dialog open in dark mode
2. Look at top-right corner
3. Click the orange circular button

**Expected Results:**
- ✅ Smooth 300ms transition starts
- ✅ Dialog background: Black → White
- ✅ Dialog title text: White → Dark gray
- ✅ Button cards: Dark gray → Light gray
- ✅ All text remains readable
- ✅ Toggle button icon: Moon → Sun (🌙 → ☀️)
- ✅ Console shows: `🎨 Theme toggled: dark → light`
- ✅ No jarring flashes or jumps

**Pass/Fail:** ___________

---

### 🎯 Test 3: Toggle Back to Dark Mode

**Steps:**
1. With startup dialog in light mode
2. Click the orange toggle button again

**Expected Results:**
- ✅ Smooth 300ms transition
- ✅ Dialog background: White → Black
- ✅ All colors revert to dark theme
- ✅ Toggle button icon: Sun → Moon (☀️ → 🌙)
- ✅ Console shows: `🎨 Theme toggled: light → dark`

**Pass/Fail:** ___________

---

### 🎯 Test 4: Theme Persistence

**Steps:**
1. Toggle to **light mode**
2. Wait 1 second
3. Refresh the page (F5 or Cmd+R)

**Expected Results:**
- ✅ Dialog reappears in **light mode** (not dark)
- ✅ Sun icon showing in toggle button
- ✅ localStorage contains: `theme: "light"`
- ✅ No flash of dark theme before light applies

**Steps:**
4. Toggle to **dark mode**
5. Refresh the page

**Expected Results:**
- ✅ Dialog reappears in **dark mode**
- ✅ Moon icon showing
- ✅ localStorage contains: `theme: "dark"`

**Pass/Fail:** ___________

---

### 🎯 Test 5: Toggle Button Visibility

**Steps:**
1. Open the app (startup dialog visible)
2. Examine the toggle button position

**Expected Results:**
- ✅ Button is in **top-right corner**
- ✅ Button is **above** the dialog (not behind it)
- ✅ Button is **clickable** (not blocked)
- ✅ Button has orange gradient background
- ✅ Hover effect works (button scales slightly)
- ✅ Cursor changes to pointer on hover

**Pass/Fail:** ___________

---

### 🎯 Test 6: Color Accuracy

**Light Mode Colors:**

**Check these elements:**
- [ ] Dialog background: Pure white `#FFFFFF`
- [ ] Dialog title: Dark gray text
- [ ] Description: Medium gray text
- [ ] Research card: Light gray background
- [ ] Plan It Out card: Light gray background
- [ ] Find Solutions card: Light gray background
- [ ] Business Plan card: Light gray background
- [ ] Card titles: Dark text (readable)
- [ ] Card descriptions: Medium gray text
- [ ] Borders: Light gray
- [ ] Toggle button: Orange gradient

**Dark Mode Colors:**

**Check these elements:**
- [ ] Dialog background: Pure black `#000000`
- [ ] Dialog title: White text
- [ ] Description: Light gray text
- [ ] Research card: Dark gray background
- [ ] Plan It Out card: Dark gray background
- [ ] Find Solutions card: Dark gray background
- [ ] Business Plan card: Dark gray background
- [ ] Card titles: White text (readable)
- [ ] Card descriptions: Light gray text
- [ ] Borders: Dark gray
- [ ] Toggle button: Orange gradient (same as light)

**Pass/Fail:** ___________

---

### 🎯 Test 7: Icon Colors (Both Modes)

**Check these remain colorful in BOTH modes:**
- [ ] Research icon (FileText): Blue gradient background
- [ ] Plan It Out icon (Sparkles): Purple gradient background
- [ ] Find Solutions icon (Lightbulb): Green gradient background
- [ ] Business Plan icon (Briefcase): Orange gradient background
- [ ] All icons: White icon color
- [ ] Toggle button: Orange gradient (consistent)

**Pass/Fail:** ___________

---

### 🎯 Test 8: Smooth Transitions

**Steps:**
1. Toggle between modes multiple times rapidly
2. Watch the transitions carefully

**Expected Results:**
- ✅ No flickering
- ✅ No color jumps
- ✅ Smooth 300ms fade
- ✅ Icon rotation/scale is smooth
- ✅ All elements transition together
- ✅ No layout shifts
- ✅ No content jumping

**Pass/Fail:** ___________

---

### 🎯 Test 9: Accessibility

**Keyboard Navigation:**
1. Click outside the dialog (if possible, or use Tab)
2. Press Tab until toggle button is focused
3. Press Enter or Space

**Expected Results:**
- ✅ Button can be focused with Tab
- ✅ Button shows focus ring when focused
- ✅ Enter key toggles theme
- ✅ Space key toggles theme
- ✅ Theme switches same as mouse click

**Screen Reader:**
- ✅ Button has aria-label: "Switch to [light/dark] mode"
- ✅ Button has title tooltip

**Pass/Fail:** ___________

---

### 🎯 Test 10: After Selecting a Mode

**Steps:**
1. From startup dialog, click "Research"
2. Check if toggle button still works
3. Toggle the theme
4. Click "New Report" to return to dialog

**Expected Results:**
- ✅ Toggle button visible on Research page
- ✅ Theme switches work on Research page
- ✅ Dialog reopens in current theme (not default)
- ✅ Theme persists throughout navigation

**Pass/Fail:** ___________

---

### 🎯 Test 11: Console Verification

**Open Browser DevTools → Console**

**On page load, check for:**
- [ ] No errors
- [ ] No warnings
- [ ] Theme initialization messages (if any)

**On toggle click, check for:**
- [ ] `🎨 Theme toggled: dark → light` or vice versa
- [ ] No errors
- [ ] No warnings

**Pass/Fail:** ___________

---

### 🎯 Test 12: HTML Element Inspection

**Steps:**
1. Open DevTools → Elements
2. Find the `<html>` element
3. Toggle the theme

**Expected Results:**
- ✅ In dark mode: `<html class="dark">` or `<html class="dark ...">` 
- ✅ In light mode: `<html class="light">` or `<html class="light ...">` 
- ✅ Class changes immediately on toggle
- ✅ Only one theme class present at a time

**Pass/Fail:** ___________

---

### 🎯 Test 13: localStorage Verification

**Steps:**
1. Open DevTools → Application → Local Storage
2. Find the 'theme' key
3. Toggle between modes

**Expected Results:**
- ✅ `theme` key exists
- ✅ Value is `"dark"` or `"light"` (with quotes)
- ✅ Value updates immediately on toggle
- ✅ No duplicate keys
- ✅ No other theme-related keys

**Pass/Fail:** ___________

---

### 🎯 Test 14: Responsive Design

**Desktop (1920x1080):**
- [ ] Toggle button visible
- [ ] Dialog centered
- [ ] All elements readable
- [ ] Theme switches work

**Tablet (768x1024):**
- [ ] Toggle button visible
- [ ] Dialog fits screen
- [ ] Touch works on toggle
- [ ] Theme switches work

**Mobile (375x667):**
- [ ] Toggle button visible
- [ ] Dialog responsive
- [ ] Touch works on toggle
- [ ] All text readable
- [ ] Theme switches work

**Pass/Fail:** ___________

---

### 🎯 Test 15: Multiple Browser Test

**Chrome:**
- [ ] Theme toggle works
- [ ] Persistence works
- [ ] Smooth animations

**Firefox:**
- [ ] Theme toggle works
- [ ] Persistence works
- [ ] Smooth animations

**Safari:**
- [ ] Theme toggle works
- [ ] Persistence works
- [ ] Smooth animations

**Edge:**
- [ ] Theme toggle works
- [ ] Persistence works
- [ ] Smooth animations

**Pass/Fail:** ___________

---

## 🔍 Advanced Tests

### 🎯 Test 16: Rapid Toggle Test

**Steps:**
1. Click toggle button 10 times rapidly
2. Observe behavior

**Expected Results:**
- ✅ All clicks register
- ✅ Theme alternates correctly
- ✅ No hanging transitions
- ✅ No console errors
- ✅ Final state is correct
- ✅ No memory leaks

**Pass/Fail:** ___________

---

### 🎯 Test 17: Network Offline Test

**Steps:**
1. Open DevTools → Network
2. Select "Offline" from throttling dropdown
3. Refresh page
4. Toggle theme

**Expected Results:**
- ✅ App loads (cached)
- ✅ Toggle still works
- ✅ Theme persists
- ✅ localStorage still accessible

**Pass/Fail:** ___________

---

### 🎯 Test 18: Incognito/Private Mode

**Steps:**
1. Open app in Incognito/Private window
2. Toggle to light mode
3. Refresh page

**Expected Results:**
- ✅ Toggle works normally
- ✅ Theme does NOT persist (private mode restriction)
- ✅ Defaults back to dark on refresh
- ✅ No console errors

**Pass/Fail:** ___________

---

## 📊 Test Results Summary

**Total Tests:** 18  
**Passed:** _____  
**Failed:** _____  
**Pass Rate:** _____%

---

## 🐛 Common Issues & Solutions

### Issue 1: Button Not Visible
**Symptom:** Can't see orange button  
**Solution:** Check z-index is 100, verify ThemeToggle is rendered

### Issue 2: Theme Not Switching
**Symptom:** Click does nothing  
**Solution:** Check console for errors, verify ThemeProvider wraps app

### Issue 3: Theme Not Persisting
**Symptom:** Resets to dark on refresh  
**Solution:** Check localStorage permissions, disable private browsing

### Issue 4: Flash of Wrong Theme
**Symptom:** See dark before light loads  
**Solution:** Theme should initialize in useState, check implementation

### Issue 5: Colors Look Wrong
**Symptom:** Text unreadable or weird colors  
**Solution:** Verify all elements have `dark:` Tailwind classes

---

## ✅ Final Verification Checklist

Before considering the feature complete:

- [ ] All 18 tests pass
- [ ] No console errors
- [ ] No console warnings
- [ ] Smooth user experience
- [ ] Works on all target browsers
- [ ] Works on all screen sizes
- [ ] Accessible to keyboard users
- [ ] Theme persists correctly
- [ ] Button always visible
- [ ] Icons animate smoothly
- [ ] Colors are correct in both modes
- [ ] Transitions are smooth (300ms)
- [ ] localStorage working
- [ ] HTML class updates correctly
- [ ] No memory leaks
- [ ] No performance issues

---

## 📝 Testing Notes

**Date Tested:** _______________  
**Tester Name:** _______________  
**Browser(s):** _______________  
**OS:** _______________  
**Screen Size:** _______________

**Additional Notes:**
_________________________________________
_________________________________________
_________________________________________
_________________________________________

---

**Status:** Ready for Production ✅  
**Last Updated:** March 15, 2026  
**Version:** 1.0.0
