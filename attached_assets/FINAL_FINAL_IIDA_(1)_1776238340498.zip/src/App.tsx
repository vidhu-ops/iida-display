import { RouterProvider } from 'react-router';
import { router } from './routes';
import { Toaster } from './components/ui/sonner';
import { useEffect, useState } from 'react';
import { setupPWA } from './utils/pwaSetup';
import { ThemeProvider } from './contexts/ThemeContext';
import { ErrorBoundary } from './components/ErrorBoundary';

// Export types for use across the app
export interface Source {
  id: number;
  title: string;
  author: string;
  publication: string;
  date: string;
  url?: string;
  type: 'Research Report' | 'Market Analysis' | 'Industry Publication' | 'Government Data' | 'News Article' | 'Financial Report';
}

export interface ReportData {
  topic: string;
  industry?: string;
  location?: string;
  currency?: string;
  sections: string[];
  generatedDate: string;
  executiveSummary?: string;
  marketAnalysis?: any;
  productAnalysis?: any;
  technologyTrends?: any;
  competitiveAnalysis?: any;
  microSegmentation?: any;
  geographicPenetration?: any;
  financialProjections?: any;
  swotAnalysis?: any;
  riskAssessment?: any;
  regulatoryCompliance?: any;
  supplyChain?: any;
  consumerBehavior?: any;
  disruptiveOpportunities?: any;
  strategicRecommendations?: any;
  investmentReadiness?: any;
  sustainability?: any;
  criticalAnalysis?: any;
  trends?: any[];
  regionalData?: any[];
  customerSegments?: any[];
  riskAnalysis?: any;
  implementationTimeline?: any[];
  industryBenchmarks?: any;
  techAdoption?: any[];
  sources?: Source[];
}

export default function App() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // Ensure theme class is applied on mount
    const savedTheme = localStorage.getItem('theme') || 'dark';
    if (!document.documentElement.classList.contains('dark') && !document.documentElement.classList.contains('light')) {
      document.documentElement.classList.add(savedTheme);
    }
    
    // Setup PWA
    setupPWA();
    
    // Mark as mounted
    setMounted(true);
    
    console.log('✅ App mounted successfully');
    console.log('📊 Document classList:', document.documentElement.classList.toString());
  }, []);

  // Show nothing until mounted to prevent hydration issues
  if (!mounted) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <ThemeProvider>
        <RouterProvider router={router} />
        <Toaster />
      </ThemeProvider>
    </ErrorBoundary>
  );
}