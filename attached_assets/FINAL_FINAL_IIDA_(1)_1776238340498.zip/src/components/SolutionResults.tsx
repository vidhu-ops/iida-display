import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  ArrowLeft, 
  Download, 
  Lightbulb, 
  Target, 
  MapPin, 
  CheckCircle2, 
  AlertCircle,
  Clock,
  DollarSign,
  TrendingUp,
  Users,
  Wrench,
  Coins
} from 'lucide-react';
import { SolutionData } from '../utils/dynamicSolutionGenerator';
import { getCurrencyInfo } from '../utils/locationData';
import { downloadSolutions } from '../utils/pdfGenerator';

interface SolutionResultsProps {
  data: SolutionData;
  onNewSearch: () => void;
}

export function SolutionResults({ data, onNewSearch }: SolutionResultsProps) {
  const handleDownload = async () => {
    await downloadSolutions(data.problem, data.location);
  };

  const getDifficultyColor = (difficulty: string) => {
    if (difficulty === 'Low') return 'bg-green-900 text-green-300 border-green-700';
    if (difficulty === 'Medium') return 'bg-yellow-900 text-yellow-300 border-yellow-700';
    return 'bg-red-900 text-red-300 border-red-700';
  };

  const getCostColor = (cost: string) => {
    if (cost.includes('Low')) return 'text-green-400';
    if (cost.includes('Medium')) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const currencyInfo = getCurrencyInfo(data.currency || 'USD');
  
  // Format the generated date properly
  const formattedDate = new Date(data.generatedDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="min-h-screen bg-white dark:bg-black max-w-7xl mx-auto p-2 sm:p-6 space-y-4 sm:space-y-6 transition-colors duration-300">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 print:hidden">
        
        <Button onClick={handleDownload} className="text-sm sm:text-base bg-[#FF5733] hover:bg-[#FF5733]/90">
          <Download className="w-4 h-4 mr-2" />
          Download Solutions
        </Button>
      </div>

      <div data-pdf-content>
      <Card className="shadow-xl bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 transition-colors duration-300">
        <CardHeader className="border-b border-gray-200 dark:border-zinc-800 transition-colors duration-300">
          <div className="space-y-2">
            <CardTitle className="text-gray-900 dark:text-white text-xl sm:text-2xl md:text-3xl leading-tight font-serif transition-colors duration-300">Solutions for Your Challenge</CardTitle>
            <div className="flex items-center gap-2 sm:gap-3 text-gray-600 dark:text-zinc-400 text-xs sm:text-sm flex-wrap transition-colors duration-300">
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 sm:w-4 sm:h-4" />
                {data.country}
              </span>
              <span className="flex items-center gap-1">
                <Coins className="w-3 h-3 sm:w-4 sm:h-4" />
                {currencyInfo.code} ({currencyInfo.symbol})
              </span>
              <Badge variant="secondary" className="bg-[#FF5733] text-white hover:bg-[#FF5733]/90 text-xs">
                {data.solutions.length} Solutions • Generated: {formattedDate}
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-2 sm:p-6 md:p-8 space-y-8 sm:space-y-12 bg-white dark:bg-zinc-900 transition-colors duration-300">
          {/* TABLE OF CONTENTS */}
          <section>
            <div className="flex items-baseline gap-6 mb-6">
              <span className="text-4xl sm:text-6xl text-[#FF5733] font-light">00.</span>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                Table of Contents
              </h2>
            </div>
            
            <div className="ml-12 sm:ml-20">
              <div className="grid grid-cols-1 gap-3">
                <a
                  href="#challenge"
                  className="bg-white dark:bg-zinc-900 rounded-xl p-4 border border-gray-200 dark:border-zinc-800 hover:border-[#FF5733] transition-all group flex items-center gap-4"
                >
                  <span className="text-xl sm:text-2xl text-[#FF5733] font-light group-hover:text-white transition-colors">
                    01.
                  </span>
                  <Lightbulb className="w-5 h-5 text-[#FF5733] group-hover:text-white transition-colors" />
                  <span className="text-gray-900 dark:text-white text-sm group-hover:text-[#FF5733] transition-colors">
                    Your Challenge
                  </span>
                </a>
                <a
                  href="#market-context"
                  className="bg-white dark:bg-zinc-900 rounded-xl p-4 border border-gray-200 dark:border-zinc-800 hover:border-[#FF5733] transition-all group flex items-center gap-4"
                >
                  <span className="text-xl sm:text-2xl text-[#FF5733] font-light group-hover:text-white transition-colors">
                    02.
                  </span>
                  <MapPin className="w-5 h-5 text-[#FF5733] group-hover:text-white transition-colors" />
                  <span className="text-gray-900 dark:text-white text-sm group-hover:text-[#FF5733] transition-colors">
                    Market Context
                  </span>
                </a>
                <a
                  href="#solutions"
                  className="bg-white dark:bg-zinc-900 rounded-xl p-4 border border-gray-200 dark:border-zinc-800 hover:border-[#FF5733] transition-all group flex items-center gap-4"
                >
                  <span className="text-xl sm:text-2xl text-[#FF5733] font-light group-hover:text-white transition-colors">
                    03.
                  </span>
                  <Target className="w-5 h-5 text-[#FF5733] group-hover:text-white transition-colors" />
                  <span className="text-gray-900 dark:text-white text-sm group-hover:text-[#FF5733] transition-colors">
                    Recommended Solutions ({data.solutions.length})
                  </span>
                </a>
                <a
                  href="#next-steps"
                  className="bg-white dark:bg-zinc-900 rounded-xl p-4 border border-gray-200 dark:border-zinc-800 hover:border-[#FF5733] transition-all group flex items-center gap-4"
                >
                  <span className="text-xl sm:text-2xl text-[#FF5733] font-light group-hover:text-white transition-colors">
                    04.
                  </span>
                  <CheckCircle2 className="w-5 h-5 text-[#FF5733] group-hover:text-white transition-colors" />
                  <span className="text-gray-900 dark:text-white text-sm group-hover:text-[#FF5733] transition-colors">
                    Next Steps
                  </span>
                </a>
              </div>
            </div>
          </section>

          <Separator className="bg-gray-200 dark:bg-zinc-800 transition-colors duration-300" />

          {/* Context Summary */}
          <section id="challenge" className="bg-gray-100 dark:bg-zinc-800 p-4 sm:p-6 rounded-lg border border-gray-200 dark:border-zinc-700 transition-colors duration-300">
            <div className="flex items-baseline gap-4 mb-4">
              <span className="text-3xl sm:text-5xl text-[#FF5733] font-light">01.</span>
              <div className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 sm:w-6 sm:h-6 text-[#FF5733]" />
                <h2 className="text-gray-900 dark:text-white text-lg sm:text-xl lg:text-2xl font-semibold font-serif transition-colors duration-300">Your Challenge</h2>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-600 dark:text-zinc-300 mb-1 text-sm sm:text-base transition-colors duration-300">Current Situation:</h3>
                <p className="text-sm sm:text-base text-gray-500 dark:text-zinc-400 leading-relaxed transition-colors duration-300">{data.problem}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-600 dark:text-zinc-300 mb-1 text-sm sm:text-base transition-colors duration-300">Desired Outcome:</h3>
                <p className="text-sm sm:text-base text-gray-500 dark:text-zinc-400 leading-relaxed transition-colors duration-300">{data.goal}</p>
              </div>
            </div>
          </section>

          <Separator className="bg-gray-200 dark:bg-zinc-800 transition-colors duration-300" />

          {/* Market Context */}
          <section id="market-context">
            <div className="flex items-baseline gap-4 mb-4">
              <span className="text-3xl sm:text-5xl text-[#FF5733] font-light">02.</span>
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-[#FF5733]" />
                <h2 className="text-gray-900 dark:text-white text-xl sm:text-2xl font-serif transition-colors duration-300">Market Context: {data.country}</h2>
              </div>
            </div>
            <div className="bg-gray-100 dark:bg-zinc-800 p-4 sm:p-6 rounded-lg border border-gray-200 dark:border-zinc-700 transition-colors duration-300">
              <p className="text-sm sm:text-base text-gray-500 dark:text-zinc-300 leading-relaxed transition-colors duration-300">{data.marketContext}</p>
            </div>
          </section>

          <Separator className="bg-gray-200 dark:bg-zinc-800 transition-colors duration-300" />

          {/* Solutions */}
          <section id="solutions">
            <div className="flex items-baseline gap-4 mb-4">
              <span className="text-3xl sm:text-5xl text-[#FF5733] font-light">03.</span>
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 sm:w-6 sm:h-6 text-[#FF5733]" />
                <h2 className="text-gray-900 dark:text-white text-xl sm:text-2xl font-serif transition-colors duration-300">Recommended Solutions</h2>
              </div>
            </div>
            
            <div className="bg-gray-100 dark:bg-zinc-800 p-4 sm:p-6 rounded-lg border border-gray-200 dark:border-zinc-700 mb-6 transition-colors duration-300">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2 text-sm sm:text-base transition-colors duration-300">How to Use These Solutions</h3>
              <p className="text-sm sm:text-base text-gray-500 dark:text-zinc-300 leading-relaxed transition-colors duration-300">
                Each solution is tailored to {data.country}'s market conditions, regulatory environment, and economic factors. Solutions are ranked by relevance and feasibility. Consider your resources, timeline, and risk tolerance when selecting solutions. Many solutions can be combined for greater impact. Implementation details include local considerations specific to {data.country}. All costs are shown in {currencyInfo.name} ({currencyInfo.code}).
              </p>
            </div>

            <div className="space-y-6">
              {data.solutions.map((solution, index) => (
                <div key={index} className="space-y-2">
                  {/* Solution number badge - centered above the card */}
                  <div className="flex justify-center">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#FF5733] text-white flex items-center justify-center font-bold text-lg">
                      {index + 1}
                    </div>
                  </div>
                  
                  <Card className="border-l-4 border-[#FF5733] bg-gray-100 dark:bg-zinc-900 hover:shadow-lg transition-shadow">
                  <CardContent className="p-4 sm:p-6">
                    <div className="mb-4">
                      <div className="flex-1">
                        <h3 className="font-bold text-lg sm:text-xl text-gray-900 dark:text-white mb-2 transition-colors duration-300">{solution.title}</h3>
                        <p className="text-sm sm:text-base text-gray-500 dark:text-zinc-300 mb-4 leading-relaxed transition-colors duration-300">{solution.description}</p>
                        
                        {/* Badges */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          <Badge variant="outline" className={getDifficultyColor(solution.difficulty)}>
                            <Wrench className="w-3 h-3 mr-1" />
                            {solution.difficulty} Difficulty
                          </Badge>
                          <Badge variant="outline" className="bg-gray-200 dark:bg-zinc-800 text-gray-500 dark:text-zinc-300 border-gray-300 dark:border-zinc-700">
                            <Clock className="w-3 h-3 mr-1" />
                            {solution.timeline}
                          </Badge>
                          <Badge variant="outline" className="bg-gray-200 dark:bg-zinc-800 text-gray-500 dark:text-zinc-300 border-gray-300 dark:border-zinc-700">
                            <Users className="w-3 h-3 mr-1" />
                            {solution.resources}
                          </Badge>
                        </div>

                        {/* Cost */}
                        <div className="mb-4 p-3 bg-gray-200 dark:bg-zinc-800 rounded border border-gray-300 dark:border-zinc-700">
                          <div className="flex items-center gap-2">
                            <DollarSign className={`w-4 h-4 ${getCostColor(solution.estimatedCost)}`} />
                            <span className="text-sm font-semibold text-gray-500 dark:text-zinc-300">Estimated Cost:</span>
                            <span className={`text-sm font-bold ${getCostColor(solution.estimatedCost)}`}>
                              {solution.estimatedCost}
                            </span>
                          </div>
                        </div>

                        {/* Implementation Steps */}
                        <div className="mb-4">
                          <h4 className="font-semibold text-gray-900 dark:text-white mb-2 text-sm sm:text-base flex items-center gap-2 transition-colors duration-300">
                            <CheckCircle2 className="w-4 h-4 text-green-400" />
                            Implementation Steps:
                          </h4>
                          <ol className="list-decimal list-inside space-y-1 text-sm sm:text-base text-gray-500 dark:text-zinc-300 transition-colors duration-300">
                            {solution.implementationSteps.map((step, stepIndex) => (
                              <li key={stepIndex} className="leading-relaxed">{step}</li>
                            ))}
                          </ol>
                        </div>

                        {/* Location-Specific Considerations */}
                        <div className="mb-4 p-3 bg-blue-900 border border-blue-700 rounded">
                          <h4 className="font-semibold text-blue-100 mb-2 text-sm sm:text-base flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            {data.country}-Specific Considerations:
                          </h4>
                          <p className="text-sm sm:text-base text-blue-200 leading-relaxed">{solution.localConsiderations}</p>
                        </div>

                        {/* Pros and Cons */}
                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div className="p-3 bg-green-900 border border-green-700 rounded">
                            <h4 className="font-semibold text-green-100 mb-2 text-sm flex items-center gap-1">
                              <CheckCircle2 className="w-4 h-4" />
                              Pros:
                            </h4>
                            <ul className="list-disc list-inside text-sm text-green-200 space-y-1">
                              {solution.pros.map((pro, proIndex) => (
                                <li key={proIndex}>{pro}</li>
                              ))}
                            </ul>
                          </div>
                          <div className="p-3 bg-red-900 border border-red-700 rounded">
                            <h4 className="font-semibold text-red-100 mb-2 text-sm flex items-center gap-1">
                              <AlertCircle className="w-4 h-4" />
                              Cons:
                            </h4>
                            <ul className="list-disc list-inside text-sm text-red-200 space-y-1">
                              {solution.cons.map((con, conIndex) => (
                                <li key={conIndex}>{con}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Expected Outcomes */}
                        <div className="p-3 bg-purple-900 border border-purple-700 rounded">
                          <h4 className="font-semibold text-purple-100 mb-2 text-sm flex items-center gap-1">
                            <TrendingUp className="w-4 h-4" />
                            Expected Outcomes:
                          </h4>
                          <p className="text-sm text-purple-200 leading-relaxed">{solution.expectedOutcome}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                </div>
              ))}
            </div>
          </section>

          <Separator className="bg-gray-200 dark:bg-zinc-800 transition-colors duration-300" />

          {/* Next Steps */}
          <section id="next-steps">
            <div className="flex items-baseline gap-4 mb-4">
              <span className="text-3xl sm:text-5xl text-[#FF5733] font-light">04.</span>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-green-400" />
                <h2 className="text-gray-900 dark:text-white text-xl sm:text-2xl font-serif transition-colors duration-300">Recommended Next Steps</h2>
              </div>
            </div>
            <div className="bg-green-900 p-6 rounded-lg border border-green-700">
              <ol className="list-decimal list-inside space-y-3 text-zinc-300">
                <li className="leading-relaxed">
                  <strong>Review all solutions carefully:</strong> Consider which solutions align best with your resources, timeline, and risk tolerance.
                </li>
                <li className="leading-relaxed">
                  <strong>Prioritize 2-3 solutions:</strong> Start with solutions marked as "Low" or "Medium" difficulty for quicker wins.
                </li>
                <li className="leading-relaxed">
                  <strong>Validate assumptions:</strong> Test your chosen solutions with small pilot programs before full implementation.
                </li>
                <li className="leading-relaxed">
                  <strong>Adapt to local conditions:</strong> Pay special attention to {data.country}-specific considerations mentioned in each solution.
                </li>
                <li className="leading-relaxed">
                  <strong>Seek expert advice:</strong> Consult with local professionals (lawyers, accountants, industry experts) before major commitments.
                </li>
                <li className="leading-relaxed">
                  <strong>Monitor and iterate:</strong> Track key metrics, gather feedback, and adjust your approach based on results.
                </li>
                <li className="leading-relaxed">
                  <strong>Combine solutions:</strong> Many solutions work better together - consider implementing complementary approaches simultaneously.
                </li>
              </ol>
            </div>
          </section>

          {/* Footer */}
          <div className="text-center text-gray-500 dark:text-zinc-600 text-xs tracking-wider py-8 border-t border-gray-300 dark:border-zinc-800 transition-colors duration-300">
            <p className="text-[10px]">
              Solutions based on research-backed market analysis and verified vendor data from {data.country}
            </p>
          </div>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}