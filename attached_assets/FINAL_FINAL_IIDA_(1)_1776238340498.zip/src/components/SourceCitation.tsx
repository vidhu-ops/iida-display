import { Badge } from './ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Source } from '../App';

interface SourceCitationProps {
  sourceIds: number[];
  sources: Source[];
  inline?: boolean;
}

export function SourceCitation({ sourceIds, sources, inline = true }: SourceCitationProps) {
  const citedSources = sources.filter(s => sourceIds.includes(s.id));
  
  if (citedSources.length === 0) return null;

  const citationText = `[${sourceIds.join(',')}]`;

  if (inline) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <sup className="text-blue-600 cursor-help ml-0.5">{citationText}</sup>
          </TooltipTrigger>
          <TooltipContent className="max-w-sm">
            <div className="space-y-2">
              {citedSources.map(source => (
                <div key={source.id} className="text-xs">
                  <div>[{source.id}] {source.author}</div>
                  <div className="text-slate-500 italic">{source.title}</div>
                  <div className="text-slate-400">{source.publication}, {source.date}</div>
                </div>
              ))}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return (
    <div className="flex flex-wrap gap-1">
      {citedSources.map(source => (
        <TooltipProvider key={source.id}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge variant="outline" className="cursor-help text-xs">
                [{source.id}]
              </Badge>
            </TooltipTrigger>
            <TooltipContent className="max-w-sm">
              <div className="text-xs">
                <div>{source.author}</div>
                <div className="text-slate-500 italic">{source.title}</div>
                <div className="text-slate-400">{source.publication}, {source.date}</div>
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ))}
    </div>
  );
}
