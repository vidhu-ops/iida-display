import { useState, useEffect } from 'react';
import { ThemeToggle } from './ThemeToggle';
import { ScrollToTop } from './ScrollToTop';
import { ScrollToTopOnMount } from './ScrollToTopOnMount';
import { ReportGenerator } from './ReportGenerator';
import { BusinessReport } from './BusinessReport';
import { PlanItOut } from './PlanItOut';
import { SolutionFinder } from './SolutionFinder';
import { BusinessPlan } from './BusinessPlan';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { FileText, Sparkles, Lightbulb, Briefcase } from 'lucide-react';
import { ReportData } from '../App';
import { useTheme } from '../contexts/ThemeContext';

export default function MainApp() {
  // Consume theme context to trigger re-renders on theme changes
  const { isDark } = useTheme();
  
  // Start with null to show dialog on startup
  
  const [activeTab, setActiveTab] = useState<'reports' | 'plan' | 'solutions' | 'businessplan' | null>(null);
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    console.log('🚀 MainApp mounted');
    console.log('🎨 Current theme (isDark):', isDark);
    console.log('📋 Active tab:', activeTab);
  }, []);

  const handleGenerateReport = (data: ReportData) => {
    setIsGenerating(true);
    // Use setTimeout to allow UI to update with loading state
    setTimeout(() => {
      try {
        setReportData(data);
        setIsGenerating(false);
      } catch (error) {
        console.error('Error setting report data:', error);
        setIsGenerating(false);
      }
    }, 100);
  };

  const handleNewReport = () => {
    setReportData(null);
    setIsGenerating(false);
  };

  const handleBackToMenu = () => {
    setReportData(null);
    setIsGenerating(false);
  };

  const handleModeSelection = (mode: 'reports' | 'plan' | 'solutions' | 'businessplan') => {
    console.log('🎯 Mode selected:', mode);
    setActiveTab(mode);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-black transition-colors duration-300">
      {/* Theme Toggle Button */}
      <ThemeToggle />
      {/* Scroll to Top Button */}
      <ScrollToTop />
      {/* Startup Dialog - Shows when no tab is selected */}
      <Dialog open={activeTab === null} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-[600px] max-w-[90vw] max-h-[85vh] overflow-hidden flex flex-col p-0 bg-white dark:bg-black border-2 border-[#FF5733] transition-colors duration-300">
          <DialogHeader className="shrink-0 px-6 pt-8 pb-4 bg-gradient-to-br from-gray-50 via-white to-gray-50 dark:from-black dark:via-gray-900 dark:to-black transition-colors duration-300">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="relative">
                <div className="absolute inset-0 bg-[#FF5733] blur-xl opacity-50 rounded-full"></div>
                <FileText className="w-12 h-12 text-[#FF5733] relative z-10" />
              </div>
            </div>
            <DialogTitle className="text-3xl sm:text-4xl text-center bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 dark:from-white dark:via-gray-100 dark:to-white bg-clip-text text-transparent font-serif">
              Business Intelligence Hub
            </DialogTitle>
            <DialogDescription className="text-sm sm:text-base pt-3 text-gray-600 dark:text-gray-400 text-center font-light transition-colors duration-300">
              Choose your path to business excellence
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 px-6 pb-8 pt-4 overflow-y-auto bg-white dark:bg-black transition-colors duration-300">
            <Button
              onClick={() => handleModeSelection('reports')}
              className="h-auto py-6 px-6 flex flex-col items-start gap-3 bg-gradient-to-br from-gray-100 to-gray-50 dark:from-slate-800/80 dark:to-slate-900/60 border-2 border-gray-300 dark:border-gray-700/50 hover:border-[#FF5733] transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,87,51,0.3)] group shrink-0"
              variant="outline"
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2.5 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl group-hover:scale-110 transition-transform duration-300">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <span className="font-bold text-xl text-gray-900 dark:text-white block mb-1 transition-colors duration-300">Research</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400 font-normal leading-relaxed transition-colors duration-300">
                    Generate business research
                  </span>
                </div>
              </div>
            </Button>
            <Button
              onClick={() => handleModeSelection('plan')}
              className="h-auto py-6 px-6 flex flex-col items-start gap-3 bg-gradient-to-br from-gray-100 to-gray-50 dark:from-slate-800/80 dark:to-slate-900/60 border-2 border-gray-300 dark:border-gray-700/50 hover:border-[#FF5733] transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,87,51,0.3)] group shrink-0"
              variant="outline"
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2.5 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl group-hover:scale-110 transition-transform duration-300">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <span className="font-bold text-xl text-gray-900 dark:text-white block mb-1 transition-colors duration-300">Plan It Out</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400 font-normal leading-relaxed transition-colors duration-300">
                    Create detailed action plan
                  </span>
                </div>
              </div>
            </Button>
            
            <Button
              onClick={() => handleModeSelection('businessplan')}
              className="h-auto py-6 px-6 flex flex-col items-start gap-3 bg-gradient-to-br from-gray-100 to-gray-50 dark:from-slate-800/80 dark:to-slate-900/60 border-2 border-gray-300 dark:border-gray-700/50 hover:border-[#FF5733] transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,87,51,0.3)] group shrink-0"
              variant="outline"
            >
              <div className="flex items-center gap-3 w-full">
                <div className="p-2.5 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl group-hover:scale-110 transition-transform duration-300">
                  <Briefcase className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <span className="font-bold text-xl text-gray-900 dark:text-white block mb-1 transition-colors duration-300">Business Plan</span>
                  <span className="text-wrap text-sm text-gray-600 dark:text-gray-400 font-normal leading-relaxed transition-colors duration-300">
                    Generate complete business plans
                  </span>
                </div>
              </div>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Main Content - Only shows after dialog selection */}
      {activeTab !== null && (
        <div className="container mx-auto px-2 sm:px-4 md:px-6 py-4 sm:py-6 md:py-8 max-w-7xl">
          <header className="text-center mb-6 sm:mb-8">
            <div className="flex items-center justify-center gap-2 sm:gap-3 mb-3 sm:mb-4">
              <div className="relative">
                <div className="absolute inset-0 bg-[#FF5733] blur-xl opacity-50 rounded-full"></div>
               
              </div>
              <h1 className="text-gray-900 dark:text-white text-xl sm:text-2xl md:text-3xl font-serif transition-colors duration-300">IIDATECH</h1>
            </div>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto text-sm sm:text-base px-4 transition-colors duration-300">
              Welcome to your Business Hub
            </p>
          </header>

          {/* Content Area */}
          {activeTab === 'reports' && (
            <div className="container mx-auto p-2 sm:p-6">
              {!reportData ? (
                <ReportGenerator onGenerateReport={handleGenerateReport} isGenerating={isGenerating} />
              ) : (
                <BusinessReport data={reportData} onNewReport={handleNewReport} />
              )}
            </div>
          )}

          {activeTab === 'plan' && (
            <PlanItOut onSwitchToResearch={() => setActiveTab('reports')} />
          )}

          {activeTab === 'solutions' && (
            <SolutionFinder />
          )}

          {activeTab === 'businessplan' && (
            <BusinessPlan />
          )}
        </div>
      )}
    </div>
  );
}