import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export function ScrollToTop() {
  const scrollToTop = () => {
    // Scroll the main window to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
    
    // Also scroll the document element as a fallback
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  };

  return (
    <button
      onClick={scrollToTop}
      className="fixed top-20 right-4 z-[10000] p-3 rounded-full bg-gradient-to-r from-[#3B82F6] to-[#60A5FA] hover:from-[#2563EB] hover:to-[#3B82F6] transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-110 group pointer-events-auto"
      aria-label="Scroll to top"
      title="Scroll to top"
    >
      <ArrowUp className="w-6 h-6 text-white group-hover:animate-bounce" />
    </button>
  );
}