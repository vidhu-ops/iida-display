import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { FileText, Sparkles, Coins, Loader2, AlertCircle } from 'lucide-react';
import { ReportData } from '../App';
import { generateMockReportData } from '../utils/reportDataGenerator';
import { generateReportWithGemini, generateReportWithGeminiSections, isGeminiConfigured } from '../utils/geminiService';
import { currencies } from '../utils/locationData';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

interface ReportGeneratorProps {
  onGenerateReport: (data: ReportData) => void;
  isGenerating?: boolean;
}

const reportSections = [
  { id: 'executiveSummary', label: 'Executive Summary & Strategic Overview', description: 'High-level overview and strategic insights' },
  { id: 'marketAnalysis', label: 'Global Market Size & Growth Dynamics', description: 'Market size, CAGR, and growth projections' },
  { id: 'productAnalysis', label: 'Core Product Analysis & Value Proposition', description: 'Product portfolio and competitive advantages' },
  { id: 'technologyTrends', label: 'Advanced Technology Trends & R&D Pipeline', description: 'Innovation, R&D investments, and tech roadmap' },
  { id: 'competitiveAnalysis', label: 'Competitive Landscape: Deep Analysis', description: 'Competitor analysis and market positioning' },
  { id: 'microSegmentation', label: 'Micro-Segmentation: Granular Analysis', description: 'Detailed customer segments and personas' },
  { id: 'geographicPenetration', label: 'Geographic Penetration: Regional Hubs', description: 'Regional market breakdown and opportunities' },
  { id: 'financialProjections', label: 'Quarterly Financial Projections', description: 'Revenue forecasts and financial modeling' },
  { id: 'swotAnalysis', label: 'SWOT Analysis: Internal & External Factors', description: 'Comprehensive strengths, weaknesses, opportunities, threats' },
  { id: 'riskAssessment', label: 'Risk Assessment & Mitigation Strategy', description: 'Risk identification and mitigation plans' },
  { id: 'regulatoryCompliance', label: 'Regulatory Compliance & Legal Framework', description: 'Legal requirements and compliance landscape' },
  { id: 'supplyChain', label: 'Supply Chain Logistics & Efficiency', description: 'Supply chain analysis and optimization' },
  { id: 'consumerBehavior', label: 'Consumer Behavior & Adoption Patterns', description: 'Customer insights and behavioral analytics' },
  { id: 'disruptiveOpportunities', label: 'Disruptive Opportunities & Future Roadmap', description: 'Innovation opportunities and strategic roadmap' },
  { id: 'strategicRecommendations', label: 'Strategic Recommendations & Action Plan', description: 'Actionable recommendations and implementation' },
  { id: 'investmentReadiness', label: 'Investment Readiness & ROI Projections', description: 'Investment analysis and return projections' },
  { id: 'sustainability', label: 'Sustainability, Circular Economy & ESG', description: 'Environmental, social, and governance factors' },
  { id: 'criticalAnalysis', label: 'Final Critical Analysis & Synthesis', description: 'Comprehensive synthesis and final insights' },
];

const industries = [
  'Technology',
  'Healthcare',
  'Finance',
  'Retail',
  'Manufacturing',
  'Energy',
  'Real Estate',
  'Entertainment',
  'Education',
  'Automotive',
];

const locations = [
  { value: 'global', label: 'Global' },
  { value: 'north-america', label: 'North America' },
  { value: 'usa', label: 'United States' },
  { value: 'canada', label: 'Canada' },
  { value: 'mexico', label: 'Mexico' },
  { value: 'europe', label: 'Europe' },
  { value: 'uk', label: 'United Kingdom' },
  { value: 'germany', label: 'Germany' },
  { value: 'france', label: 'France' },
  { value: 'spain', label: 'Spain' },
  { value: 'italy', label: 'Italy' },
  { value: 'asia-pacific', label: 'Asia-Pacific' },
  { value: 'china', label: 'China' },
  { value: 'japan', label: 'Japan' },
  { value: 'india', label: 'India' },
  { value: 'south-korea', label: 'South Korea' },
  { value: 'australia', label: 'Australia' },
  { value: 'singapore', label: 'Singapore' },
  { value: 'latin-america', label: 'Latin America' },
  { value: 'brazil', label: 'Brazil' },
  { value: 'argentina', label: 'Argentina' },
  { value: 'middle-east', label: 'Middle East' },
  { value: 'uae', label: 'United Arab Emirates' },
  { value: 'saudi-arabia', label: 'Saudi Arabia' },
  { value: 'africa', label: 'Africa' },
  { value: 'south-africa', label: 'South Africa' },
  { value: 'nigeria', label: 'Nigeria' },
];

export function ReportGenerator({ onGenerateReport, isGenerating = false }: ReportGeneratorProps) {
  const [topic, setTopic] = useState('');
  const [industry, setIndustry] = useState('');
  const [location, setLocation] = useState('global');
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [selectedSections, setSelectedSections] = useState<string[]>(
    reportSections.map(s => s.id) // Select all by default
  );
  const [useAI, setUseAI] = useState(false);
  const [internalGenerating, setInternalGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState('');
  const geminiConfigured = isGeminiConfigured();

  const handleSectionToggle = (sectionId: string) => {
    setSelectedSections((prev) =>
      prev.includes(sectionId)
        ? prev.filter((id) => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const handleSelectAll = () => {
    setSelectedSections(reportSections.map(s => s.id));
  };

  const handleDeselectAll = () => {
    setSelectedSections([]);
  };

  const handleLocationChange = (value: string) => {
    setLocation(value);
    // Reset state and city when country changes
    setState('');
    setCity('');
  };

  const handleStateChange = (value: string) => {
    setState(value);
    // Reset city when state changes
    setCity('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim() && selectedSections.length > 0) {
      setInternalGenerating(true);
      try {
        // Build location string with state and city if provided
        let fullLocation = location;
        if (state) {
          fullLocation = `${location}, ${state}`;
        }
        if (city) {
          fullLocation = `${location}, ${state}, ${city}`;
        }
        
        console.log('Generating report with:', { topic, industry, fullLocation, selectedSections, currency });
        
        // Try to use Gemini API if configured, otherwise fall back to mock data
        let reportData;
        if (geminiConfigured) {
          try {
            console.log('🚀 Using SECTION-BY-SECTION Gemini API generation for maximum accuracy...');
            console.log('⚙️  Each section will be generated with its own dedicated prompt');
            reportData = await Promise.race([
              generateReportWithGeminiSections(topic, industry, fullLocation, selectedSections, currency),
              new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Generation timeout - report is taking too long')), 120000) // Increased timeout for multiple API calls
              )
            ]) as ReportData;
            console.log('✅ ALL SECTIONS generated successfully with REAL, VERIFIED data');
            console.log('✅ NO placeholder or dummy data - everything is research-backed');
          } catch (apiError: any) {
            console.error('❌ Gemini API failed:', apiError);
            // Silent fallback to mock data without showing alert
            console.warn('⚠️ Falling back to sample data due to API error');
            reportData = await generateMockReportData(topic, industry, fullLocation, selectedSections, currency);
          }
        } else {
          console.log('ℹ️ Using mock data generation (Gemini API not configured)');
          reportData = await generateMockReportData(topic, industry, fullLocation, selectedSections, currency);
        }
        
        console.log('📊 Report data prepared, displaying now...');
        onGenerateReport(reportData);
        setInternalGenerating(false);
      } catch (error: any) {
        console.error('❌ Error generating report:', error);
        setInternalGenerating(false);
        // Use toast instead of alert for better UX
        console.error('Please try again or check console for details');
      }
    }
  };

  return (
    <Card className="max-w-3xl mx-auto shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
          <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
          Configure Your Report
        </CardTitle>
        <CardDescription className="text-sm">
          Enter your topic and select the sections you want to include in your business report
        </CardDescription>
      </CardHeader>
      <CardContent>
        {geminiConfigured ? (
          <Alert className="mb-1">
            
            
            
          </Alert>
        ) : (
          null
        )}
        <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
          <div className="space-y-2">
            <Label htmlFor="topic">Report Topic *</Label>
            <Input
              id="topic"
              placeholder="e.g., Electric Vehicle Market Expansion"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              required
              className="text-sm sm:text-base"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="industry">Industry (Optional)</Label>
              <Select value={industry} onValueChange={setIndustry}>
                <SelectTrigger id="industry" className="text-sm sm:text-base">
                  <SelectValue placeholder="Select an industry" />
                </SelectTrigger>
                <SelectContent>
                  {industries.map((ind) => (
                    <SelectItem key={ind} value={ind}>
                      {ind}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Geographic Focus</Label>
              <Select value={location} onValueChange={handleLocationChange}>
                <SelectTrigger id="location" className="text-sm sm:text-base">
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((loc) => (
                    <SelectItem key={loc.value} value={loc.value}>
                      {loc.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Optional State and City fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="state">State/Province (Optional)</Label>
              <Input
                id="state"
                placeholder="e.g., California, Ontario"
                value={state}
                onChange={(e) => handleStateChange(e.target.value)}
                className="text-sm sm:text-base"
              />
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Add for more targeted regional analysis
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="city">City (Optional)</Label>
              <Input
                id="city"
                placeholder="e.g., San Francisco, Toronto"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="text-sm sm:text-base"
              />
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Add for hyper-local market insights
              </p>
            </div>
          </div>

          {/* Location Help Banner */}
          

          <div className="space-y-2">
            <Label htmlFor="currency" className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-purple-600" />
              Preferred Currency *
            </Label>
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger id="currency" className="text-sm sm:text-base">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                {currencies.map((curr) => (
                  <SelectItem key={curr.code} value={curr.code}>
                    {curr.code} - {curr.name} ({curr.symbol})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              All financial data in the report will be displayed in this currency
            </p>
          </div>

          <div className="space-y-3 sm:space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <Label>Report Sections *</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleSelectAll}
                  className="text-xs sm:text-sm"
                >
                  Select All
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleDeselectAll}
                  className="text-xs sm:text-sm"
                >
                  Deselect All
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 max-h-[400px] sm:max-h-[500px] overflow-y-auto pr-1 sm:pr-2">
              {reportSections.map((section) => (
                <div
                  key={section.id}
                  className="flex items-start space-x-2 sm:space-x-3 space-y-0 rounded-lg border p-3 sm:p-4 hover:bg-slate-50 transition-colors"
                >
                  <Checkbox
                    id={section.id}
                    checked={selectedSections.includes(section.id)}
                    onCheckedChange={() => handleSectionToggle(section.id)}
                    className="mt-0.5"
                  />
                  <div className="flex-1 space-y-0.5 sm:space-y-1">
                    <label
                      htmlFor={section.id}
                      className="cursor-pointer text-sm leading-tight sm:leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {section.label}
                    </label>
                    <p className="text-slate-500 text-xs sm:text-sm leading-tight">{section.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Button
            type="submit"
            className="w-full text-sm sm:text-base"
            size="lg"
            disabled={!topic.trim() || selectedSections.length === 0 || internalGenerating}
          >
            {internalGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {generationProgress || 'Generating Report...'}
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Generate Report
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}