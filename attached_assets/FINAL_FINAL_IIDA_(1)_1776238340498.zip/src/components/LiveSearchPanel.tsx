/**
 * LiveSearchPanel — Real-Time Web Intelligence Panel
 *
 * Displays live-scraped (Gemini + Google Search Grounding) competitor, vendor,
 * and industry contact data. Each card links back to Google for verification.
 */

import { useState, useCallback, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Search,
  Globe,
  ExternalLink,
  Linkedin,
  Phone,
  Mail,
  MapPin,
  Building2,
  Users,
  TrendingUp,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  CheckCircle,
  AlertCircle,
  Loader2,
  DollarSign,
  Calendar,
  Tag,
  Network,
} from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  runFullWebSearch,
  WebSearchResults,
  ScrapedEntity,
} from '../utils/webScraperService';

interface LiveSearchPanelProps {
  topic: string;
  location: string;
  /** Which tabs to show. Defaults to 'all'. */
  mode?: 'all' | 'competitors' | 'vendors' | 'contacts';
  /** Optional class for outer wrapper */
  className?: string;
}

// ─── Colour helpers ───────────────────────────────────────────────────────────

const AVATAR_COLOURS = [
  'bg-orange-500',
  'bg-sky-500',
  'bg-emerald-500',
  'bg-violet-500',
  'bg-rose-500',
  'bg-amber-500',
  'bg-cyan-500',
  'bg-fuchsia-500',
  'bg-lime-600',
  'bg-teal-500',
];

function avatarColour(name: string): string {
  const code = name.charCodeAt(0) + (name.charCodeAt(1) || 0);
  return AVATAR_COLOURS[code % AVATAR_COLOURS.length];
}

function categoryBadge(type: ScrapedEntity['type']) {
  if (type === 'competitor') return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 border-red-200 dark:border-red-800';
  if (type === 'vendor')     return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 border-blue-200 dark:border-blue-800';
  return                            'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 border-purple-200 dark:border-purple-800';
}

// ─── Status Banner ────────────────────────────────────────────────────────────

function StatusBanner({ status, queries }: { status: WebSearchResults['searchStatus']; queries?: string[] }) {
  if (status === 'google_live') {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800">
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
        </span>
        <span className="text-xs text-emerald-700 dark:text-emerald-300">
          <strong></strong> — data grounded in real-time Google results
        </span>
      </div>
    );
  }
  if (status === 'mixed') {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
        <CheckCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 flex-shrink-0" />
        <span className="text-xs text-amber-700 dark:text-amber-300">
          <strong>MIXED</strong>
        </span>
      </div>
    );
  }
  if (status === 'ai_research') {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-sky-50 dark:bg-sky-900/20 border border-sky-200 dark:border-sky-800">
        <AlertCircle className="w-4 h-4 text-sky-600 dark:text-sky-400 flex-shrink-0" />
        <span className="text-xs text-sky-700 dark:text-sky-300">
          <strong></strong>
        </span>
      </div>
    );
  }
  return null;
}

// ─── Individual Entity Card ───────────────────────────────────────────────────

function EntityCard({ entity }: { entity: ScrapedEntity }) {
  const [expanded, setExpanded] = useState(false);
  const initial = entity.name.trim()[0]?.toUpperCase() ?? '?';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl p-4 hover:border-[#FF5733] transition-all duration-200 shadow-sm"
    >
      {/* Top row */}
      <div className="flex items-start gap-3">
        {/* Avatar */}
        <div className={`w-10 h-10 flex-shrink-0 rounded-lg ${avatarColour(entity.name)} flex items-center justify-center text-white font-bold text-base`}>
          {initial}
        </div>

        {/* Name + badges */}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h4 className="text-sm font-semibold text-gray-900 dark:text-white truncate max-w-[200px]">
              {entity.name}
            </h4>
            <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${categoryBadge(entity.type)}`}>
              {entity.category}
            </span>
            {entity.source === 'google_live' && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-medium">
                ● LIVE
              </span>
            )}
          </div>

          {/* Description */}
          <p className="text-xs text-gray-600 dark:text-zinc-400 leading-relaxed line-clamp-2">
            {entity.description}
          </p>
        </div>
      </div>

      {/* Quick meta row */}
      <div className="mt-3 flex flex-wrap gap-3 text-xs text-gray-500 dark:text-zinc-500">
        {entity.address && (
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" />
            {entity.address}
          </span>
        )}
        {entity.employees && (
          <span className="flex items-center gap-1">
            <Users className="w-3 h-3" />
            {entity.employees} employees
          </span>
        )}
        {entity.revenue && (
          <span className="flex items-center gap-1">
            <DollarSign className="w-3 h-3" />
            {entity.revenue}
          </span>
        )}
        {entity.founded && (
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            Est. {entity.founded}
          </span>
        )}
      </div>

      {/* Expanded detail (phone, email, full description) */}
      {expanded && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-3 space-y-2 border-t border-gray-100 dark:border-zinc-800 pt-3"
        >
          {entity.phone && (
            <div className="flex items-center gap-2 text-xs text-gray-700 dark:text-zinc-300">
              <Phone className="w-3.5 h-3.5 text-[#FF5733]" />
              <a href={`tel:${entity.phone}`} className="hover:text-[#FF5733]">{entity.phone}</a>
            </div>
          )}
          {entity.email && (
            <div className="flex items-center gap-2 text-xs text-gray-700 dark:text-zinc-300">
              <Mail className="w-3.5 h-3.5 text-[#FF5733]" />
              <a href={`mailto:${entity.email}`} className="hover:text-[#FF5733]">{entity.email}</a>
            </div>
          )}
          <p className="text-xs text-gray-600 dark:text-zinc-400 leading-relaxed">
            {entity.description}
          </p>
          {/* Grounding sources */}
          {entity.sourceUrls && entity.sourceUrls.length > 0 && (
            <div className="mt-2">
              <p className="text-[10px] text-gray-400 dark:text-zinc-600 mb-1 uppercase tracking-wider">Sources</p>
              <div className="space-y-1">
                {entity.sourceUrls.map((s, i) => (
                  <a
                    key={i}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-[11px] text-sky-600 dark:text-sky-400 hover:underline truncate"
                  >
                    <Globe className="w-3 h-3 flex-shrink-0" />
                    <span className="truncate">{s.title || s.url}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}

      {/* Action row */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {entity.website && (
          <a
            href={entity.website}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-[#FF5733] hover:underline"
          >
            <Globe className="w-3 h-3" />
            Website
          </a>
        )}
        {entity.linkedIn && (
          <a
            href={entity.linkedIn}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-sky-600 dark:text-sky-400 hover:underline"
          >
            <Linkedin className="w-3 h-3" />
            LinkedIn
          </a>
        )}
        <a
          href={entity.googleSearchUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-xs text-gray-500 dark:text-zinc-400 hover:text-[#FF5733] hover:underline"
        >
          <Search className="w-3 h-3" />
          Verify on Google
        </a>
        <button
          onClick={() => setExpanded(v => !v)}
          className="ml-auto inline-flex items-center gap-1 text-xs text-gray-400 dark:text-zinc-500 hover:text-gray-600 dark:hover:text-zinc-300"
        >
          {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          {expanded ? 'Less' : 'More'}
        </button>
      </div>
    </motion.div>
  );
}

// ─── Entity Grid ──────────────────────────────────────────────────────────────

function EntityGrid({ entities, emptyLabel }: { entities: ScrapedEntity[]; emptyLabel: string }) {
  if (entities.length === 0) {
    return (
      <div className="text-center py-10 text-gray-400 dark:text-zinc-600">
        <Building2 className="w-8 h-8 mx-auto mb-2 opacity-40" />
        <p className="text-sm">{emptyLabel}</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {entities.map(e => (
        <EntityCard key={e.id} entity={e} />
      ))}
    </div>
  );
}

// ─── Source Drawer ────────────────────────────────────────────────────────────

function SourceDrawer({ sources, queries }: { sources: { title: string; url: string }[]; queries?: string[] }) {
  const [open, setOpen] = useState(false);
  if (sources.length === 0 && (!queries || queries.length === 0)) return null;

  return (
    <div className="border border-gray-200 dark:border-zinc-800 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-4 py-3 text-xs text-gray-500 dark:text-zinc-400 hover:bg-gray-50 dark:hover:bg-zinc-900/50 transition-colors"
      >
        <span className="flex items-center gap-2">
          <Network className="w-3.5 h-3.5 text-[#FF5733]" />
          <span>{sources.length} Google sources referenced</span>
          {queries && queries.length > 0 && (
            <span className="text-gray-400 dark:text-zinc-600">· {queries.length} search queries</span>
          )}
        </span>
        {open ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
      </button>
      {open && (
        <div className="px-4 pb-4 space-y-3 bg-gray-50 dark:bg-zinc-900/50">
          {queries && queries.length > 0 && (
            <div>
              <p className="text-[10px] uppercase tracking-wider text-gray-400 dark:text-zinc-600 mb-2">Search Queries Used</p>
              <div className="flex flex-wrap gap-2">
                {queries.map((q, i) => (
                  <a
                    key={i}
                    href={`https://www.google.com/search?q=${encodeURIComponent(q)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs bg-white dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded-full px-3 py-1 text-gray-600 dark:text-zinc-300 hover:border-[#FF5733] hover:text-[#FF5733] transition-colors"
                  >
                    <Search className="w-3 h-3" />
                    {q}
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                ))}
              </div>
            </div>
          )}
          {sources.length > 0 && (
            <div>
              <p className="text-[10px] uppercase tracking-wider text-gray-400 dark:text-zinc-600 mb-2">Referenced Web Pages</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {sources.map((s, i) => (
                  <a
                    key={i}
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-2 text-xs text-sky-600 dark:text-sky-400 hover:underline"
                  >
                    <Globe className="w-3 h-3 flex-shrink-0 mt-0.5" />
                    <span className="line-clamp-2">{s.title || s.url}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function LiveSearchPanel({ topic, location, mode = 'all', className = '' }: LiveSearchPanelProps) {
  const [results, setResults] = useState<WebSearchResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchedOnce, setSearchedOnce] = useState(false);

  const doSearch = useCallback(async () => {
    if (!topic || !location) return;
    setLoading(true);
    setError(null);
    try {
      const data = await runFullWebSearch(topic, location, mode);
      setResults(data);
    } catch (e: any) {
      setError(e?.message ?? 'Search failed');
    } finally {
      setLoading(false);
      setSearchedOnce(true);
    }
  }, [topic, location, mode]);

  const totalFound =
    (results?.competitors.length ?? 0) +
    (results?.vendors.length ?? 0) +
    (results?.industryContacts.length ?? 0);

  // Auto-search when component mounts or when topic/location changes
  useEffect(() => {
    if (topic && location && !searchedOnce && !loading) {
      doSearch();
    }
  }, [topic, location, searchedOnce, loading, doSearch]);

  return (
    <div className={`rounded-2xl border border-gray-200 dark:border-zinc-800 overflow-hidden ${className}`}>
      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 bg-gradient-to-r from-gray-50 to-white dark:from-zinc-900 dark:to-zinc-950 border-b border-gray-200 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#FF5733] rounded-lg flex items-center justify-center">
            <Search className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
             
            </h3>
            <p className="text-xs text-gray-500 dark:text-zinc-500">
              Auto-discovering real competitors, vendors &amp; contacts for <em>{topic}</em> in <em>{location}</em>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {results && (
            <span className="text-xs text-gray-400 dark:text-zinc-600">
              {totalFound} results
            </span>
          )}
          <Button
            onClick={doSearch}
            disabled={loading}
            size="sm"
            className="bg-[#FF5733] hover:bg-[#e54d2e] text-white border-0 flex items-center gap-2 px-4"
          >
            {loading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : searchedOnce ? (
              <RefreshCw className="w-3.5 h-3.5" />
            ) : (
              <Search className="w-3.5 h-3.5" />
            )}
            {loading ? 'Searching Google…' : searchedOnce ? 'Refresh' : 'Search Now'}
          </Button>
        </div>
      </div>

      {/* ── Body ── */}
      <div className="p-5 space-y-4">
        {/* Pre-search state */}
        {!searchedOnce && !loading && (
          <div className="text-center py-10 space-y-3">
            <div className="w-14 h-14 mx-auto rounded-full bg-gray-100 dark:bg-zinc-800 flex items-center justify-center">
              <Globe className="w-7 h-7 text-gray-400 dark:text-zinc-500" />
            </div>
            <p className="text-sm text-gray-500 dark:text-zinc-500 max-w-sm mx-auto">
              
            </p>
          </div>
        )}

        {/* Loading state */}
        {loading && (
          <div className="space-y-3">
            {[
              '🔍 Querying Google for competitors…',
              '🏭 Finding vendors &amp; suppliers…',
              '🤝 Searching industry contacts…',
            ].map((msg, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-zinc-900/50 animate-pulse">
                <Loader2 className="w-4 h-4 animate-spin text-[#FF5733]" />
                <span className="text-xs text-gray-500 dark:text-zinc-500" dangerouslySetInnerHTML={{ __html: msg }} />
              </div>
            ))}
          </div>
        )}

        {/* Error */}
        {error && !loading && (
          <div className="flex items-center gap-2 p-4 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-sm text-red-700 dark:text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}. Try clicking Search Now again.</span>
          </div>
        )}

        {/* Results */}
        {results && !loading && (
          <div className="space-y-4">
            <StatusBanner status={results.searchStatus} queries={results.searchQueries} />

            <Tabs defaultValue="competitors">
              <TabsList className="bg-gray-100 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl p-1 gap-1">
                {(mode === 'all' || mode === 'competitors') && (
                  <TabsTrigger
                    value="competitors"
                    className="text-xs rounded-lg data-[state=active]:bg-[#FF5733] data-[state=active]:text-white"
                  >
                    <TrendingUp className="w-3.5 h-3.5 mr-1.5" />
                    Competitors ({results.competitors.length})
                  </TabsTrigger>
                )}
                {(mode === 'all' || mode === 'vendors') && (
                  <TabsTrigger
                    value="vendors"
                    className="text-xs rounded-lg data-[state=active]:bg-[#FF5733] data-[state=active]:text-white"
                  >
                    <Tag className="w-3.5 h-3.5 mr-1.5" />
                    Vendors ({results.vendors.length})
                  </TabsTrigger>
                )}
                {(mode === 'all' || mode === 'contacts') && (
                  <TabsTrigger
                    value="contacts"
                    className="text-xs rounded-lg data-[state=active]:bg-[#FF5733] data-[state=active]:text-white"
                  >
                    <Users className="w-3.5 h-3.5 mr-1.5" />
                    Contacts ({results.industryContacts.length})
                  </TabsTrigger>
                )}
              </TabsList>

              {(mode === 'all' || mode === 'competitors') && (
                <TabsContent value="competitors" className="mt-4">
                  <EntityGrid
                    entities={results.competitors}
                    emptyLabel="No direct competitors found — try refreshing or broadening your search."
                  />
                </TabsContent>
              )}
              {(mode === 'all' || mode === 'vendors') && (
                <TabsContent value="vendors" className="mt-4">
                  <EntityGrid
                    entities={results.vendors}
                    emptyLabel="No vendors found — try refreshing."
                  />
                </TabsContent>
              )}
              {(mode === 'all' || mode === 'contacts') && (
                <TabsContent value="contacts" className="mt-4">
                  <EntityGrid
                    entities={results.industryContacts}
                    emptyLabel="No industry contacts found — try refreshing."
                  />
                </TabsContent>
              )}
            </Tabs>

            {/* Source attribution */}
            <SourceDrawer
              sources={results.researchSources}
              queries={results.searchQueries}
            />

            <p className="text-[10px] text-gray-400 dark:text-zinc-600 text-center">
              Searched {new Date(results.searchedAt).toLocaleTimeString()} ·
              
            </p>
          </div>
        )}
      </div>
    </div>
  );
}