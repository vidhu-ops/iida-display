import { useState, useEffect } from 'react';
import { Settings, Eye, EyeOff, Check, X, Loader2, KeyRound, ExternalLink, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { useTheme } from '../contexts/ThemeContext';
import {
  getGeminiKey, getClaudeKey,
  setGeminiKey, setClaudeKey,
  hasGeminiKey, hasClaudeKey
} from '../utils/apiKeys';

interface ApiKeySettingsProps {
  /** If true, renders as a floating trigger button + modal overlay */
  floating?: boolean;
}

type TestStatus = 'idle' | 'testing' | 'ok' | 'fail';

export function ApiKeySettings({ floating = true }: ApiKeySettingsProps) {
  const { isDark } = useTheme();
  const [open, setOpen] = useState(false);
  const [geminiInput, setGeminiInput] = useState('');
  const [claudeInput, setClaudeInput] = useState('');
  const [showGemini, setShowGemini] = useState(false);
  const [showClaude, setShowClaude] = useState(false);
  const [saved, setSaved] = useState(false);
  const [geminiStatus, setGeminiStatus] = useState<TestStatus>('idle');
  const [claudeStatus, setClaudeStatus] = useState<TestStatus>('idle');
  const [geminiError, setGeminiError] = useState('');
  const [claudeError, setClaudeError] = useState('');

  // Load stored keys on open
  useEffect(() => {
    if (open) {
      setGeminiInput(getGeminiKey());
      setClaudeInput(getClaudeKey());
      setSaved(false);
      setGeminiStatus('idle');
      setClaudeStatus('idle');
      setGeminiError('');
      setClaudeError('');
    }
  }, [open]);

  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleSave = () => {
    setGeminiKey(geminiInput);
    setClaudeKey(claudeInput);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const testGemini = async () => {
    const key = geminiInput.trim();
    if (!key) { setGeminiError('Enter a key first'); setGeminiStatus('fail'); return; }
    setGeminiStatus('testing');
    setGeminiError('');
    try {
      const resp = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${key}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts: [{ text: 'Say "ok"' }] }], generationConfig: { maxOutputTokens: 5 } }),
        }
      );
      if (resp.ok) {
        setGeminiStatus('ok');
      } else {
        const err = await resp.json().catch(() => ({}));
        setGeminiStatus('fail');
        setGeminiError(err?.error?.message || `HTTP ${resp.status}`);
      }
    } catch (e: any) {
      setGeminiStatus('fail');
      setGeminiError(e.message || 'Connection failed');
    }
  };

  const testClaude = async () => {
    const key = claudeInput.trim();
    if (!key) { setClaudeError('Enter a key first'); setClaudeStatus('fail'); return; }
    setClaudeStatus('testing');
    setClaudeError('');
    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 5,
          messages: [{ role: 'user', content: 'Say ok' }],
        }),
      });
      if (resp.ok) {
        setClaudeStatus('ok');
      } else {
        const err = await resp.json().catch(() => ({}));
        setClaudeStatus('fail');
        setClaudeError(err?.error?.message || `HTTP ${resp.status}`);
      }
    } catch (e: any) {
      setClaudeStatus('fail');
      setClaudeError(e.message || 'Connection failed');
    }
  };

  const statusIcon = (s: TestStatus) => {
    if (s === 'testing') return <Loader2 className="w-3.5 h-3.5 animate-spin text-[#FF5733]" />;
    if (s === 'ok') return <Check className="w-3.5 h-3.5 text-emerald-500" />;
    if (s === 'fail') return <X className="w-3.5 h-3.5 text-red-500" />;
    return null;
  };

  const configuredCount = (hasGeminiKey() ? 1 : 0) + (hasClaudeKey() ? 1 : 0);

  const modalContent = (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={(e) => { if (e.target === e.currentTarget) setOpen(false); }}
    >
      <div className="w-full max-w-lg bg-white dark:bg-zinc-950 rounded-2xl shadow-2xl border border-gray-200 dark:border-zinc-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-900">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-[#FF5733] rounded-lg flex items-center justify-center">
              <KeyRound className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900 dark:text-white text-sm">API Key Settings</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">Keys are stored locally in your browser</p>
            </div>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-zinc-800 text-gray-500 dark:text-gray-400 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-5">
          {/* Info banner */}
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl px-4 py-3 flex gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
              Keys are stored in <strong>browser localStorage only</strong> and never sent to any server other than the respective AI API. Clear your browser data to remove them.
            </p>
          </div>

          {/* Gemini Key */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-900 dark:text-white flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                  <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400">G</span>
                </span>
                Google Gemini API Key
              </label>
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-[#FF5733] hover:underline flex items-center gap-1"
              >
                Get key <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="relative">
              <input
                type={showGemini ? 'text' : 'password'}
                value={geminiInput}
                onChange={(e) => { setGeminiInput(e.target.value); setGeminiStatus('idle'); setGeminiError(''); }}
                placeholder="AIza..."
                className="w-full pr-20 pl-3 py-2.5 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-900 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-[#FF5733]/40 focus:border-[#FF5733]"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {statusIcon(geminiStatus)}
                <button onClick={() => setShowGemini(v => !v)} className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                  {showGemini ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            {geminiError && <p className="text-xs text-red-500">{geminiError}</p>}
            {geminiStatus === 'ok' && <p className="text-xs text-emerald-600 dark:text-emerald-400">✅ Gemini API key valid — connected!</p>}
            <div className="flex gap-2">
              <button
                onClick={testGemini}
                disabled={geminiStatus === 'testing'}
                className="text-xs px-3 py-1.5 rounded-lg border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors disabled:opacity-50"
              >
                {geminiStatus === 'testing' ? 'Testing…' : 'Test connection'}
              </button>
              <span className="text-xs text-gray-500 dark:text-gray-400 self-center">Powers search-grounded competitor analysis</span>
            </div>
          </div>

          <div className="border-t border-gray-200 dark:border-zinc-800" />

          {/* Claude Key */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-900 dark:text-white flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-orange-100 dark:bg-orange-900 flex items-center justify-center">
                  <span className="text-[10px] font-bold text-orange-600 dark:text-orange-400">A</span>
                </span>
                Anthropic Claude API Key
              </label>
              <a
                href="https://console.anthropic.com/settings/keys"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-[#FF5733] hover:underline flex items-center gap-1"
              >
                Get key <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="relative">
              <input
                type={showClaude ? 'text' : 'password'}
                value={claudeInput}
                onChange={(e) => { setClaudeInput(e.target.value); setClaudeStatus('idle'); setClaudeError(''); }}
                placeholder="sk-ant-api03-..."
                className="w-full pr-20 pl-3 py-2.5 text-sm border border-gray-300 dark:border-zinc-700 rounded-lg bg-white dark:bg-zinc-900 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-[#FF5733]/40 focus:border-[#FF5733]"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {statusIcon(claudeStatus)}
                <button onClick={() => setShowClaude(v => !v)} className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                  {showClaude ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            {claudeError && <p className="text-xs text-red-500">{claudeError}</p>}
            {claudeStatus === 'ok' && <p className="text-xs text-emerald-600 dark:text-emerald-400">✅ Claude API key valid — connected!</p>}
            <div className="flex gap-2">
              <button
                onClick={testClaude}
                disabled={claudeStatus === 'testing'}
                className="text-xs px-3 py-1.5 rounded-lg border border-gray-300 dark:border-zinc-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-zinc-800 transition-colors disabled:opacity-50"
              >
                {claudeStatus === 'testing' ? 'Testing…' : 'Test connection'}
              </button>
              <span className="text-xs text-gray-500 dark:text-gray-400 self-center">Used as Gemini fallback</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-900 flex items-center justify-between gap-3">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {configuredCount === 0 ? '⚠️ No keys configured — app uses static fallback data' :
             configuredCount === 1 ? '⚡ 1 API active — add both for best results' :
             '✅ Both APIs configured'}
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setOpen(false)} className="text-xs border-gray-300 dark:border-zinc-700">
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              className="text-xs bg-[#FF5733] hover:bg-[#FF5733]/90 text-white border-0 min-w-[80px]"
            >
              {saved ? <><Check className="w-3.5 h-3.5 mr-1" /> Saved!</> : 'Save Keys'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  if (!floating) {
    return (
      <>
        <button onClick={() => setOpen(true)}>
          <Settings className="w-4 h-4" />
        </button>
        {open && modalContent}
      </>
    );
  }

  return (
    <>
      {/* Floating trigger button */}
      <button
        onClick={() => setOpen(true)}
        title="API Key Settings"
        className="fixed bottom-6 left-6 z-50 w-11 h-11 rounded-full bg-white dark:bg-zinc-900 border border-gray-300 dark:border-zinc-700 shadow-lg flex items-center justify-center hover:bg-gray-50 dark:hover:bg-zinc-800 hover:border-[#FF5733] transition-all group"
      >
        <Settings className="w-4.5 h-4.5 text-gray-600 dark:text-gray-400 group-hover:text-[#FF5733] transition-colors" />
        {/* Dot indicator showing key status */}
        <span className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-white dark:border-zinc-900 ${
          configuredCount === 2 ? 'bg-emerald-500' :
          configuredCount === 1 ? 'bg-amber-500' :
          'bg-red-500'
        }`} />
      </button>

      {open && modalContent}
    </>
  );
}