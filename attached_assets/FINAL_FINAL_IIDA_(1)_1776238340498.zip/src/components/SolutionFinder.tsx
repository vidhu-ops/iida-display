import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Lightbulb, Target, MapPin, Coins, FileText, Loader2, Sparkles } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { SolutionResults } from './SolutionResults';
import { BusinessPlan } from './BusinessPlan';
import { generateIntelligentSolutions, SolutionData } from '../utils/dynamicSolutionGenerator';
import { generateSolutionsWithGemini, isGeminiConfigured } from '../utils/geminiService';
import { currencies } from '../utils/locationData';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

export function SolutionFinder() {
  const [solutionData, setSolutionData] = useState<SolutionData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    problem: '',
    goal: '',
    country: '',
    currency: 'USD'
  });
  const geminiConfigured = isGeminiConfigured();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.problem || !formData.goal || !formData.country) {
      alert('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    try {
      console.log('🚀 Generating unique solutions for:', {
        problem: formData.problem.substring(0, 50) + '...',
        goal: formData.goal.substring(0, 50) + '...',
        country: formData.country,
        currency: formData.currency
      });
      
      let solutionDataResult: SolutionData;
      
      // Try AI-powered solutions if Gemini is configured
      if (geminiConfigured) {
        try {
          console.log('🤖 Using Gemini AI for solution generation...');
          const aiSolutions = await generateSolutionsWithGemini(
            formData.problem,
            formData.country,
            formData.goal,
            formData.currency
          );
          
          // Convert AI solutions array to SolutionData format
          solutionDataResult = {
            problem: formData.problem,
            goal: formData.goal,
            country: formData.country,
            currency: formData.currency,
            solutions: aiSolutions.map((sol: any) => ({
              title: sol.title || 'Untitled Solution',
              description: sol.description || '',
              difficulty: (sol.difficulty || 'Medium') as 'Low' | 'Medium' | 'High',
              timeline: sol.timeline || '4-8 weeks',
              estimatedCost: sol.costEstimate || sol.estimatedCost || formData.currency + ' 5,000 - 15,000',
              resources: sol.resources || 'Implementation team',
              implementationSteps: sol.implementationSteps || [],
              localConsiderations: sol.localConsiderations || `Specific considerations for ${formData.country} market`,
              pros: sol.pros || [],
              cons: sol.cons || [],
              expectedOutcome: sol.expectedROI || sol.expectedOutcome || ''
            })),
            problemAnalysis: `AI-powered analysis for: "${formData.problem}" in ${formData.country}. Generated ${aiSolutions.length} unique, actionable solutions tailored to achieve: "${formData.goal}".`,
            marketContext: `These AI-generated solutions are specifically designed for ${formData.country} market conditions, regulations, and business culture. Each solution bridges the gap between your current problem and desired goal with location-specific vendors and realistic implementation plans.`,
            priorityRecommendation: aiSolutions.length > 0 
              ? `🎯 RECOMMENDED START: Solution #1 ("${aiSolutions[0]?.title}") offers the most direct path from your current problem to your desired goal in ${formData.country}. It provides specific, actionable steps with local vendors and realistic timelines.`
              : 'Review all solutions and select the best fit for your specific situation.',
            generatedDate: new Date().toISOString()
          };
          
          console.log(`✅ Generated ${aiSolutions.length} AI-powered unique solutions`);
        } catch (aiError) {
          console.warn('⚠️ AI generation failed, falling back to local generator:', aiError);
          // Fallback to local intelligent generator
          solutionDataResult = generateIntelligentSolutions(
            formData.problem,
            formData.goal,
            formData.country,
            formData.currency
          );
        }
      } else {
        console.log('📝 Using local intelligent generator...');
        solutionDataResult = generateIntelligentSolutions(
          formData.problem,
          formData.goal,
          formData.country,
          formData.currency
        );
      }
      
      if (!solutionDataResult || !solutionDataResult.solutions || solutionDataResult.solutions.length === 0) {
        throw new Error('No solutions were generated');
      }
      
      setSolutionData(solutionDataResult);
      console.log('✅ Successfully generated', solutionDataResult.solutions.length, 'unique solutions');
      console.log('📊 Solution titles:', solutionDataResult.solutions.map(s => s.title));
    } catch (error) {
      console.error('❌ Error generating solutions:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      alert(`Failed to generate solutions: ${errorMessage}. Please try again.`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewSearch = () => {
    setSolutionData(null);
    setFormData({
      problem: '',
      goal: '',
      country: '',
      currency: 'USD'
    });
  };

  if (solutionData) {
    return <SolutionResults data={solutionData} onNewSearch={handleNewSearch} />;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Tabs defaultValue="solutions" className="w-full">
        

        <TabsContent value="solutions">
          <Card className="shadow-xl bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 transition-colors duration-300">
            <CardHeader className="border-b border-gray-200 dark:border-zinc-800 transition-colors duration-300">
              <div className="flex items-center gap-2 sm:gap-3">
                <Lightbulb className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#FF5733]" />
                <div>
                  <CardTitle className="text-gray-900 dark:text-white text-xl sm:text-2xl md:text-3xl font-serif transition-colors duration-300">Find Solutions</CardTitle>
                  <p className="text-gray-600 dark:text-zinc-400 text-xs sm:text-sm mt-1 transition-colors duration-300">
                    Get innovative, location-specific solutions for your business challenges
                  </p>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-4 sm:p-6 md:p-8 bg-white dark:bg-zinc-900 transition-colors duration-300">
              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                {/* Problem Description */}
                <div className="space-y-2">
                  <Label htmlFor="problem" className="text-sm sm:text-base flex items-center gap-2 text-gray-900 dark:text-white transition-colors duration-300">
                    <Lightbulb className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF5733]" />
                    What is it that you are trying to do?
                  </Label>
                  <Textarea
                    id="problem"
                    placeholder="Be as descriptive as possible for best solutions. For example: 'I'm struggling to attract customers to my new coffee shop despite having a great location and quality products. We're competing with established chains and need to differentiate ourselves while managing a limited marketing budget...'"
                    value={formData.problem}
                    onChange={(e) => setFormData({ ...formData, problem: e.target.value })}
                    className="min-h-[120px] sm:min-h-[150px] text-sm sm:text-base bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-zinc-500 transition-colors duration-300"
                    required
                  />
                  <p className="text-xs sm:text-sm text-gray-500 dark:text-zinc-500 transition-colors duration-300">
                    Provide detailed context including challenges, constraints, and current situation
                  </p>
                </div>

                {/* Goal */}
                <div className="space-y-2">
                  <Label htmlFor="goal" className="text-sm sm:text-base flex items-center gap-2 text-gray-900 dark:text-white transition-colors duration-300">
                    <Target className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF5733]" />
                    What are you trying to achieve?
                  </Label>
                  <Textarea
                    id="goal"
                    placeholder="Describe your desired outcome. For example: 'Increase monthly foot traffic by 40%, build a loyal customer base of regulars, achieve profitability within 6 months, and establish our coffee shop as a community hub...'"
                    value={formData.goal}
                    onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                    className="min-h-[100px] sm:min-h-[120px] text-sm sm:text-base bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 text-gray-900 dark:text-white placeholder:text-gray-500 dark:placeholder:text-zinc-500 transition-colors duration-300"
                    required
                  />
                  <p className="text-xs sm:text-sm text-gray-500 dark:text-zinc-500 transition-colors duration-300">
                    Specify measurable goals, timeline, and success criteria
                  </p>
                </div>

                {/* Country/Location */}
                <div className="space-y-2">
                  <Label htmlFor="country" className="text-sm sm:text-base flex items-center gap-2 text-gray-900 dark:text-white transition-colors duration-300">
                    <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF5733]" />
                    Country/Location
                  </Label>
                  <Select
                    value={formData.country}
                    onValueChange={(value) => setFormData({ ...formData, country: value })}
                    required
                  >
                    <SelectTrigger className="text-sm sm:text-base bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 text-gray-900 dark:text-white transition-colors duration-300">
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 text-gray-900 dark:text-white transition-colors duration-300">
                      <SelectItem value="United States">United States</SelectItem>
                      <SelectItem value="United Kingdom">United Kingdom</SelectItem>
                      <SelectItem value="Canada">Canada</SelectItem>
                      <SelectItem value="Australia">Australia</SelectItem>
                      <SelectItem value="Germany">Germany</SelectItem>
                      <SelectItem value="France">France</SelectItem>
                      <SelectItem value="Japan">Japan</SelectItem>
                      <SelectItem value="China">China</SelectItem>
                      <SelectItem value="India">India</SelectItem>
                      <SelectItem value="Brazil">Brazil</SelectItem>
                      <SelectItem value="Mexico">Mexico</SelectItem>
                      <SelectItem value="Singapore">Singapore</SelectItem>
                      <SelectItem value="UAE">United Arab Emirates</SelectItem>
                      <SelectItem value="South Korea">South Korea</SelectItem>
                      <SelectItem value="Netherlands">Netherlands</SelectItem>
                      <SelectItem value="Spain">Spain</SelectItem>
                      <SelectItem value="Italy">Italy</SelectItem>
                      <SelectItem value="Switzerland">Switzerland</SelectItem>
                      <SelectItem value="Sweden">Sweden</SelectItem>
                      <SelectItem value="Norway">Norway</SelectItem>
                      <SelectItem value="Denmark">Denmark</SelectItem>
                      <SelectItem value="Ireland">Ireland</SelectItem>
                      <SelectItem value="New Zealand">New Zealand</SelectItem>
                      <SelectItem value="South Africa">South Africa</SelectItem>
                      <SelectItem value="Israel">Israel</SelectItem>
                      <SelectItem value="Poland">Poland</SelectItem>
                      <SelectItem value="Turkey">Turkey</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs sm:text-sm text-gray-500 dark:text-zinc-500 transition-colors duration-300">
                    Solutions will be tailored to your location's market, regulations, and economics
                  </p>
                </div>

                {/* Currency */}
                <div className="space-y-2">
                  <Label htmlFor="currency" className="text-sm sm:text-base flex items-center gap-2 text-gray-900 dark:text-white transition-colors duration-300">
                    <Coins className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF5733]" />
                    Currency
                  </Label>
                  <Select
                    value={formData.currency}
                    onValueChange={(value) => setFormData({ ...formData, currency: value })}
                    required
                  >
                    <SelectTrigger className="text-sm sm:text-base bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 text-gray-900 dark:text-white transition-colors duration-300">
                      <SelectValue placeholder="Select your currency" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 text-gray-900 dark:text-white transition-colors duration-300">
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.name} ({currency.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs sm:text-sm text-gray-500 dark:text-zinc-500 transition-colors duration-300">
                    Choose the currency for cost estimates
                  </p>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-[#FF5733] hover:bg-[#FF5733]/90 text-white text-lg py-6"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating Solutions...
                    </>
                  ) : (
                    <>
                      <Lightbulb className="w-5 h-5 mr-2" />
                      Find Solutions
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-8 p-4 bg-gray-100 dark:bg-zinc-800 border border-gray-300 dark:border-zinc-700 rounded-lg transition-colors duration-300">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2 transition-colors duration-300">What you'll get:</h3>
                <ul className="text-sm text-gray-700 dark:text-zinc-300 space-y-1 transition-colors duration-300">
                  <li>✓ {geminiConfigured ? '12-15' : '6'} unique, innovative solutions tailored to your specific challenge</li>
                  <li>✓ Every generation creates completely different solutions based on your input</li>
                  {geminiConfigured && (
                    <>
                      <li>✓ AI-powered research-backed analysis using Gemini 1.5 Flash</li>
                      <li>✓ Solutions based on verified market data and real company information</li>
                    </>
                  )}
                  <li>✓ Location-specific recommendations for {formData.country || 'your'} market conditions</li>
                  <li>✓ Real company names and verified vendors operating in {formData.country || 'your location'}</li>
                  <li>✓ Realistic cost estimates based on actual {formData.country || 'local'} market rates</li>
                  <li>✓ Implementation steps with accurate timeline projections</li>
                  <li>✓ Detailed pros, cons, and expected ROI analysis</li>
                  <li>✓ {geminiConfigured ? 'Research-backed' : 'Intelligent'} insights considering local economics, regulations, and culture</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="businessplan">
          <BusinessPlan />
        </TabsContent>
      </Tabs>
    </div>
  );
}