import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { PlanData } from '../utils/planGenerator';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Button } from './ui/button';
import { 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  ClipboardCheck,
  ArrowLeft,
  Share2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { ThemeToggle } from './ThemeToggle';
import { ScrollToTop } from './ScrollToTop';
import { ScrollToTopOnMount } from './ScrollToTopOnMount';

export function ChecklistView() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [planData, setPlanData] = useState<PlanData | null>(null);
  const [checklistItems, setChecklistItems] = useState<Record<string, boolean>>({});
  const [checklistId, setChecklistId] = useState<string>('');

  useEffect(() => {
    // Get checklist ID from URL
    const id = searchParams.get('id');
    if (!id) {
      toast.error('No checklist ID provided');
      return;
    }

    setChecklistId(id);

    // Load plan data from localStorage
    const savedData = localStorage.getItem(`checklist_${id}`);
    if (savedData) {
      try {
        const { plan, items } = JSON.parse(savedData);
        setPlanData(plan);
        setChecklistItems(items || {});
      } catch (error) {
        toast.error('Failed to load checklist');
      }
    } else {
      toast.error('Checklist not found');
    }
  }, [searchParams]);

  // Save checklist state whenever it changes
  useEffect(() => {
    if (checklistId && planData) {
      localStorage.setItem(`checklist_${checklistId}`, JSON.stringify({
        plan: planData,
        items: checklistItems
      }));
    }
  }, [checklistItems, checklistId, planData]);

  const toggleChecklistItem = (key: string) => {
    setChecklistItems((prev) => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const calculateProgress = () => {
    if (!planData) return { completed: 0, total: 0, percentage: 0 };
    
    const total = planData.actionSteps.reduce(
      (acc, step) => acc + step.detailedTasks.length,
      0
    );
    const completed = Object.values(checklistItems).filter(Boolean).length;
    return { 
      completed, 
      total, 
      percentage: total > 0 ? Math.round((completed / total) * 100) : 0 
    };
  };

  const handleShare = async () => {
    const url = window.location.href;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Action Plan Checklist: ${planData?.need}`,
          text: 'Track your progress on this action plan',
          url: url
        });
        toast.success('Shared successfully!');
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          copyToClipboard(url);
        }
      }
    } else {
      copyToClipboard(url);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Link copied to clipboard!');
  };

  if (!planData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <ClipboardCheck className="w-16 h-16 text-slate-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-slate-700 mb-2">Loading Checklist...</h2>
            <p className="text-slate-600">Please wait while we load your action plan.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = calculateProgress();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-slate-50 to-blue-50">
      {/* Theme Toggle and Scroll to Top */}
      <ThemeToggle />
      <ScrollToTop />
      <ScrollToTopOnMount />
      
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="shrink-0"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <h1 className="text-lg sm:text-xl font-bold text-purple-700 truncate">
              Action Plan Checklist
            </h1>
            <Button
              variant="outline"
              size="sm"
              onClick={handleShare}
              className="shrink-0"
            >
              <Share2 className="w-4 h-4 sm:mr-2" />
              <span className="hidden sm:inline">Share</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Plan Overview */}
        <Card className="mb-6 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
            <CardTitle className="text-white text-xl sm:text-2xl">{planData.need}</CardTitle>
            <div className="flex items-center gap-3 text-purple-100 text-sm flex-wrap mt-2">
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {planData.timeline}
              </span>
              <span className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                {planData.budget}
              </span>
              <Badge variant="secondary" className="bg-white/20 text-white hover:bg-white/30">
                {planData.area}
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Progress Bar */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-6">
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-purple-900">Overall Progress</span>
                <span className="text-xl font-bold text-purple-700">{progress.completed} / {progress.total} tasks</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-6 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-green-500 to-emerald-600 transition-all duration-500 ease-out flex items-center justify-center"
                  style={{ width: `${progress.percentage}%` }}
                >
                  {progress.percentage > 5 && (
                    <span className="text-sm font-bold text-white">{progress.percentage}%</span>
                  )}
                </div>
              </div>
            </div>

            {/* Install Instructions */}
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm font-semibold text-blue-900 mb-2">💡 Add to Home Screen</p>
              <p className="text-xs text-blue-800 leading-relaxed">
                <strong>iPhone:</strong> Tap Share → Add to Home Screen<br />
                <strong>Android:</strong> Tap Menu (⋮) → Add to Home screen<br />
                Access this checklist anytime from your home screen!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Completion Message */}
        {progress.percentage === 100 && (
          <Card className="mb-6 bg-gradient-to-r from-green-100 to-emerald-100 border-2 border-green-400 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="flex justify-center mb-3">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10 text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-green-800 mb-2">🎉 Congratulations!</h3>
              <p className="text-green-700">
                You've completed all {progress.total} tasks in your action plan. Great work!
              </p>
            </CardContent>
          </Card>
        )}

        {/* Checklist by Phase */}
        <div className="space-y-6">
          {planData.actionSteps.map((step, stepIndex) => (
            <Card key={stepIndex} className="border-l-4 border-purple-500 shadow-lg">
              <CardHeader className="bg-purple-50 pb-3">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-sm">
                    {stepIndex + 1}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg text-purple-900">{step.phase}</CardTitle>
                    <div className="flex items-center gap-3 mt-2 text-xs text-slate-600">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {step.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <DollarSign className="w-3 h-3" />
                        {step.estimatedCost}
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-3">
                  {step.detailedTasks.map((task, taskIndex) => {
                    const key = `${stepIndex}-${taskIndex}`;
                    const isChecked = checklistItems[key] || false;
                    
                    return (
                      <div
                        key={taskIndex}
                        className={`flex items-start gap-3 p-4 rounded-lg border-2 transition-all ${
                          isChecked
                            ? 'bg-green-50 border-green-300'
                            : 'bg-white border-slate-200 hover:border-purple-300'
                        }`}
                      >
                        <Checkbox
                          id={key}
                          checked={isChecked}
                          onCheckedChange={() => toggleChecklistItem(key)}
                          className="mt-1"
                        />
                        <label
                          htmlFor={key}
                          className="flex-1 cursor-pointer"
                        >
                          <div className={`font-semibold ${isChecked ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                            {task.task}
                          </div>
                          <p className={`text-sm mt-1 ${isChecked ? 'line-through text-slate-400' : 'text-slate-600'}`}>
                            {task.description}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline" className="text-xs">
                              <Clock className="w-3 h-3 mr-1" />
                              {task.estimatedTime}
                            </Badge>
                          </div>
                        </label>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}