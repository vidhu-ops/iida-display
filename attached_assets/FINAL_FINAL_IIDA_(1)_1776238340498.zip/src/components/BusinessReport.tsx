import { Button } from './ui/button';
import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  ArrowLeft, Download, TrendingUp, TrendingDown, Target, Globe, 
  Users, DollarSign, BookOpen, AlertTriangle, Shield, Truck, 
  Brain, Leaf, BarChart3, Lightbulb, CheckCircle2, Package, Coins,
  Search, X, Loader2, ExternalLink, ChevronDown, ChevronUp
} from 'lucide-react';
import { ReportData } from '../App';
import { formatCurrency, formatWithCurrency, getCurrencyInfo } from '../utils/locationData';
import { fetchDeepCompetitorAnalysis } from '../utils/competitorAnalysis';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, 
  PolarRadiusAxis, Radar, ComposedChart
} from 'recharts';
import { useTheme } from '../contexts/ThemeContext';
import { downloadBusinessReport } from '../utils/pdfGenerator';


interface BusinessReportProps {
  data: ReportData;
  onNewReport: () => void;
}

const COLORS = ['#FF5733', '#10b981', '#f59e0b', '#FF5733', '#8b5cf6', '#ec4899'];
const BRAND_ORANGE = '#FF5733';

// Section overview data
const sectionOverviews: Record<string, { purpose: string; implementation: string }> = {
  executiveSummary: {
    purpose: "This section provides a high-level synthesis of the entire report, distilling key insights, strategic recommendations, and critical findings into an accessible executive brief. It serves as a standalone overview for decision-makers who need to quickly grasp market dynamics, opportunities, and risks.",
    implementation: "Use this section to brief stakeholders, pitch to investors, or guide strategic planning sessions. The insights here should inform your go/no-go decisions, resource allocation, and strategic positioning in the market."
  },
  marketAnalysis: {
    purpose: "A comprehensive examination of market size, growth trajectories, key drivers, and macro-economic factors shaping the industry. This section quantifies the total addressable market (TAM) and identifies growth opportunities across different segments and geographies.",
    implementation: "Leverage these metrics to validate market opportunity size, justify investment decisions, set revenue targets, and identify which market segments offer the highest growth potential. Use CAGR data to forecast long-term opportunities."
  },
  productAnalysis: {
    purpose: "Deep dive into product portfolios, value propositions, feature differentiation, and competitive advantages. This section evaluates what makes products successful in the market and identifies gaps or opportunities for innovation.",
    implementation: "Apply these insights to refine your product roadmap, enhance value propositions, identify feature gaps, and develop differentiation strategies. Use competitive product analysis to inform R&D priorities and go-to-market positioning."
  },
  technologyTrends: {
    purpose: "Analysis of emerging technologies, R&D investments, innovation pipelines, and technological disruptions shaping the industry. This section identifies which technologies are gaining traction and which are becoming obsolete.",
    implementation: "Use this to guide technology adoption decisions, allocate R&D budgets, identify partnership opportunities, and stay ahead of disruption. Prioritize investments in technologies with strong growth trajectories and competitive advantages."
  },
  competitiveAnalysis: {
    purpose: "Detailed assessment of the competitive landscape including market share analysis, competitor strategies, positioning maps, and competitive advantages. This section identifies who your real competitors are and how they're winning.",
    implementation: "Apply these insights to develop counter-strategies, identify white space opportunities, benchmark your performance, and understand competitive threats. Use this data to refine your unique value proposition and competitive positioning."
  },
  microSegmentation: {
    purpose: "Granular breakdown of customer segments, personas, behavioral patterns, and needs analysis. This section goes beyond demographics to understand psychographics, pain points, and decision-making criteria of different customer groups.",
    implementation: "Use this to tailor marketing messages, develop targeted campaigns, customize product offerings, and optimize customer acquisition strategies. Each segment should inform specific go-to-market tactics and value propositions."
  },
  geographicPenetration: {
    purpose: "Regional market analysis covering geographic opportunities, local market dynamics, regulatory considerations, and expansion strategies. This section identifies which regions offer the best growth potential and entry strategies.",
    implementation: "Leverage this to prioritize geographic expansion, allocate regional resources, adapt products for local markets, and develop region-specific strategies. Use this data to sequence market entry and optimize resource deployment."
  },
  financialProjections: {
    purpose: "Forward-looking financial analysis including revenue forecasts, profitability projections, unit economics, and financial modeling. This section quantifies the financial opportunity and provides data-driven forecasts.",
    implementation: "Use these projections for budgeting, fundraising, investor presentations, and strategic planning. Validate assumptions regularly and adjust forecasts based on actual performance. These numbers should inform resource allocation and growth targets."
  },
  swotAnalysis: {
    purpose: "Structured assessment of internal Strengths and Weaknesses, plus external Opportunities and Threats. This framework provides a balanced view of factors that could impact success or failure in the market.",
    implementation: "Use SWOT to develop strategies that leverage strengths, mitigate weaknesses, capitalize on opportunities, and defend against threats. Each element should inform specific strategic initiatives and risk mitigation plans."
  },
  riskAssessment: {
    purpose: "Comprehensive identification and evaluation of potential risks including market risks, operational risks, competitive threats, and external factors. This section quantifies risk severity and probability.",
    implementation: "Develop mitigation strategies for high-priority risks, create contingency plans, allocate reserves for risk management, and monitor key risk indicators. Use this to make informed go/no-go decisions and prepare for potential challenges."
  },
  regulatoryCompliance: {
    purpose: "Analysis of legal frameworks, regulatory requirements, compliance obligations, and policy trends affecting the industry. This section identifies regulatory barriers, opportunities, and compliance costs.",
    implementation: "Use this to ensure legal compliance, budget for regulatory costs, engage with policymakers, and identify regulatory arbitrage opportunities. Stay ahead of regulatory changes that could impact your business model."
  },
  supplyChain: {
    purpose: "Examination of supply chain dynamics, logistics networks, supplier relationships, and operational efficiency opportunities. This section identifies bottlenecks, cost optimization opportunities, and resilience factors.",
    implementation: "Apply these insights to optimize procurement, reduce costs, improve delivery times, build supplier redundancy, and enhance supply chain resilience. Use this data to make build-vs-buy decisions and vertical integration choices."
  },
  consumerBehavior: {
    purpose: "Deep analysis of customer decision-making processes, purchase patterns, adoption curves, and behavioral economics. This section reveals why customers buy, how they buy, and what drives loyalty.",
    implementation: "Use these insights to optimize customer acquisition, improve conversion rates, enhance customer experience, and build loyalty programs. Apply behavioral insights to marketing, product design, and customer success strategies."
  },
  disruptiveOpportunities: {
    purpose: "Identification of breakthrough opportunities, emerging business models, disruptive innovations, and blue ocean strategies. This section explores unconventional approaches that could create new markets or reshape existing ones.",
    implementation: "Use this to fuel innovation initiatives, explore adjacent markets, develop new business models, and stay ahead of disruption. Prioritize opportunities with high impact and feasibility, and allocate resources to experimentation."
  },
  strategicRecommendations: {
    purpose: "Actionable strategic recommendations synthesized from all report sections, including prioritized initiatives, implementation roadmaps, and resource requirements. This section translates insights into concrete action plans.",
    implementation: "Treat this as your strategic playbook. Prioritize recommendations based on impact and feasibility, assign ownership, set timelines, and allocate resources. Review and adjust quarterly based on results and market changes."
  },
  investmentReadiness: {
    purpose: "Assessment of investment opportunities, capital requirements, ROI projections, and funding strategies. This section evaluates the attractiveness of the opportunity from an investor perspective.",
    implementation: "Use this for fundraising pitches, investor presentations, capital allocation decisions, and partnership discussions. The ROI analysis should inform which initiatives receive funding and how to structure investment asks."
  },
  sustainability: {
    purpose: "Analysis of environmental, social, and governance (ESG) factors, sustainability trends, circular economy opportunities, and corporate responsibility considerations. This section evaluates how sustainability impacts business performance.",
    implementation: "Apply these insights to develop sustainability strategies, reduce environmental impact, improve ESG ratings, attract conscious consumers, and meet stakeholder expectations. Use this to future-proof your business against climate and social risks."
  },
  criticalAnalysis: {
    purpose: "Comprehensive synthesis that challenges assumptions, explores alternative scenarios, identifies blind spots, and provides brutally honest assessment of opportunities and challenges. This is the 'reality check' section.",
    implementation: "Use this as a counterbalance to optimistic projections. The critical analysis should inform risk management, contingency planning, and strategic choices. Pay special attention to warnings and alternative scenarios."
  }
};

export function BusinessReport({ data, onNewReport }: BusinessReportProps) {
  const { isDark } = useTheme();
  const userCurrency = data.currency || 'USD';
  const currencyInfo = getCurrencyInfo(userCurrency);
  
  // Helper function to format amounts in user's selected currency
  const formatAmount = (usdAmount: number, decimals: number = 1): string => {
    return formatWithCurrency(usdAmount, userCurrency, decimals);
  };
  
  const handleDownload = async () => {
    await downloadBusinessReport(
      `${data.topic} - ${data.industry} - ${data.location}`,
      data.topic
    );
  };

  // ── Deep Competitor Analysis modal state ──────────────────────────────
  const [compModalOpen, setCompModalOpen] = useState(false);
  const [compLoading, setCompLoading] = useState(false);
  const [compResult, setCompResult] = useState<string>('');
  const [compError, setCompError] = useState<string>('');
  const [compSearchQueries, setCompSearchQueries] = useState<string[]>([]);
  const [compExpanded, setCompExpanded] = useState<Record<number, boolean>>({});
  const compModalRef = useRef<HTMLDivElement>(null);

  // Close modal on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setCompModalOpen(false); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleDeepCompetitorAnalysis = async () => {
    setCompModalOpen(true);
    setCompLoading(true);
    setCompResult('');
    setCompError('');
    setCompSearchQueries([]);
    setCompExpanded({});

    try {
      const result = await fetchDeepCompetitorAnalysis(
        data.topic,
        data.location || '',
        data.industry || '',
        data.currency || 'USD'
      );
      setCompResult(result.text);
      if (result.queries && result.queries.length > 0) {
        setCompSearchQueries(result.queries);
      }
    } catch (err: any) {
      setCompError(err?.message || 'Failed to run competitor analysis. Please try again.');
    } finally {
      setCompLoading(false);
    }
  };

  // Render markdown-ish text to structured HTML for display
  const renderCompetitorResult = (text: string) => {
    if (!text) return null;
    // Split into competitor blocks by ## headings
    const lines = text.split('\n');
    const blocks: { heading: string; lines: string[] }[] = [];
    let current: { heading: string; lines: string[] } | null = null;
    for (const line of lines) {
      if (line.startsWith('## ')) {
        if (current) blocks.push(current);
        current = { heading: line.replace('## ', ''), lines: [] };
      } else if (current) {
        current.lines.push(line);
      }
    }
    if (current) blocks.push(current);

    if (blocks.length === 0) {
      // Fallback: render as plain formatted text
      return (
        <div className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed font-mono">
          {text}
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {blocks.map((block, idx) => {
          const isSummary = block.heading.includes('Competitive Landscape Summary') || block.heading.includes('🏁');
          const isExpanded = compExpanded[idx] !== false; // default expanded
          const renderLines = (lines: string[]) => lines.map((line, li) => {
            if (!line.trim()) return <div key={li} className="h-2" />;
            if (line.startsWith('**') && line.endsWith('**')) {
              return <p key={li} className="font-semibold text-gray-900 dark:text-white text-sm mt-3 mb-1">{line.replace(/\*\*/g, '')}</p>;
            }
            if (line.match(/^\*\*.*\*\*/)) {
              const formatted = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
              return <p key={li} className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: formatted }} />;
            }
            if (line.startsWith('- ') || line.startsWith('• ')) {
              const content = line.replace(/^[-•]\s/, '').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
              return (
                <div key={li} className="flex items-start gap-2">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-[#FF5733] shrink-0" />
                  <span className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: content }} />
                </div>
              );
            }
            if (line.startsWith('### ')) {
              return <h4 key={li} className="text-xs font-bold tracking-wider text-[#FF5733] uppercase mt-3 mb-1">{line.replace('### ', '')}</h4>;
            }
            const formatted = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            return <p key={li} className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: formatted }} />;
          });

          return (
            <div key={idx} className={`border rounded-xl overflow-hidden transition-all duration-200 ${isSummary ? 'border-[#FF5733]/40 bg-orange-50 dark:bg-orange-950/20' : 'border-gray-200 dark:border-zinc-700 bg-white dark:bg-zinc-900'}`}>
              <button
                className="w-full flex items-center justify-between px-4 py-3 text-left group"
                onClick={() => setCompExpanded(prev => ({ ...prev, [idx]: !(prev[idx] !== false) }))}
              >
                <span className={`font-semibold text-sm ${isSummary ? 'text-[#FF5733]' : 'text-gray-900 dark:text-white'}`}>{block.heading}</span>
                {isExpanded
                  ? <ChevronUp className="w-4 h-4 text-gray-400 shrink-0" />
                  : <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />
                }
              </button>
              {isExpanded && (
                <div className="px-4 pb-4 border-t border-gray-100 dark:border-zinc-800 pt-3">
                  <div className="space-y-0.5">{renderLines(block.lines)}</div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const renderCitation = (sources: number[]) => {
    if (!sources || sources.length === 0) return null;
    return (
      <sup className="text-[#FF5733] cursor-help ml-1 font-medium">
        [{sources.join(',')}]
      </sup>
    );
  };

  const getRiskColor = (severity: number) => {
    if (severity >= 8) return 'bg-red-100 dark:bg-red-950/30 border-red-300 dark:border-red-900 text-red-800 dark:text-red-200';
    if (severity >= 6) return 'bg-orange-100 dark:bg-orange-950/30 border-orange-300 dark:border-orange-900 text-orange-800 dark:text-orange-200';
    return 'bg-yellow-100 dark:bg-yellow-950/30 border-yellow-300 dark:border-yellow-900 text-yellow-800 dark:text-yellow-200';
  };

  // Add safety check for data
  if (!data || !data.topic) {
    return (
      <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white p-6 transition-colors duration-300">
        <Card className="bg-white dark:bg-zinc-900 border-gray-200 dark:border-zinc-800 max-w-3xl mx-auto transition-colors duration-300">
          <CardContent className="p-6">
            <p className="text-[#FF5733]">Error: Invalid report data. Please try generating the report again.</p>
            
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate section numbers based on enabled sections
  const enabledSections = [
    { key: 'executiveSummary', title: 'Executive Summary' },
    { key: 'marketAnalysis', title: 'Market Analysis' },
    { key: 'productAnalysis', title: 'Product Analysis' },
    { key: 'technologyTrends', title: 'Technology & Innovation' },
    { key: 'competitiveAnalysis', title: 'Competitive Landscape' },
    { key: 'microSegmentation', title: 'Micro-Segmentation' },
    { key: 'geographicPenetration', title: 'Geographic Penetration' },
    { key: 'financialProjections', title: 'Financial Projections' },
    { key: 'swotAnalysis', title: 'SWOT Analysis' },
    { key: 'riskAssessment', title: 'Risk Assessment' },
    { key: 'regulatoryCompliance', title: 'Regulatory Compliance' },
    { key: 'supplyChain', title: 'Supply Chain' },
    { key: 'consumerBehavior', title: 'Consumer Behavior' },
    { key: 'disruptiveOpportunities', title: 'Disruptive Opportunities' },
    { key: 'strategicRecommendations', title: 'Strategic Recommendations' },
    { key: 'investmentReadiness', title: 'Investment Readiness' },
    { key: 'sustainability', title: 'Sustainability & ESG' },
    { key: 'criticalAnalysis', title: 'Critical Analysis' },
  ].filter(section => data.sections.includes(section.key));

  const getSectionNumber = (sectionKey: string) => {
    const index = enabledSections.findIndex(s => s.key === sectionKey);
    return index >= 0 ? String(index + 1).padStart(2, '0') : '00';
  };

  // Render section overview component
  const renderSectionOverview = (sectionKey: string) => {
    const overview = sectionOverviews[sectionKey];
    if (!overview) return null;

    return (
      <div className="bg-gray-100 dark:bg-zinc-900 border border-gray-300 dark:border-zinc-800 rounded-2xl space-y-4 transition-colors duration-300 p-[8px]">
        <div className="flex items-center gap-2 pb-2 border-b border-gray-300 dark:border-zinc-800 transition-colors duration-300">
          <BookOpen className="w-5 h-5 text-[#FF5733]" />
          <h4 className="text-sm font-medium text-[#FF5733] tracking-wider">SECTION OVERVIEW</h4>
        </div>
        
        <div className="space-y-3">
          <div>
            <h5 className="text-xs font-medium text-gray-600 dark:text-zinc-400 mb-2 tracking-wider transition-colors duration-300">PURPOSE</h5>
            <p className="text-sm text-gray-700 dark:text-zinc-300 leading-relaxed transition-colors duration-300">{overview.purpose}</p>
          </div>
          
          <div>
            <h5 className="text-xs font-medium text-gray-600 dark:text-zinc-400 mb-2 tracking-wider transition-colors duration-300">HOW TO USE & IMPLEMENT</h5>
            <p className="text-sm text-gray-700 dark:text-zinc-300 leading-relaxed transition-colors duration-300">{overview.implementation}</p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
    <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white transition-colors duration-300">
      {/* Sticky Header Actions */}
      <div className="sticky top-0 z-50 bg-white/95 dark:bg-black/95 backdrop-blur-sm border-b border-gray-200 dark:border-zinc-800 print:hidden transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <Button 
                onClick={handleDownload}
                className="bg-[#FF5733] hover:bg-[#FF5733]/90 text-white border-0"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </Button>

              <Button
                onClick={handleDeepCompetitorAnalysis}
                variant="outline"
                className="border-[#FF5733] text-[#FF5733] hover:bg-[#FF5733] hover:text-white transition-colors duration-200 gap-2"
              >
                <Search className="w-4 h-4" />
                Deep Competitor Analysis
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="relative overflow-hidden bg-white dark:bg-black border-b border-gray-200 dark:border-zinc-800 transition-colors duration-300">
        {/* Decorative blob */}
        <div className="absolute right-0 top-0 w-46 h-96 opacity-20 pointer-events-none">
          
        </div>

        <div className="relative max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
          <div className="space-y-6">
            <div className="flex items-center gap-3 text-xs tracking-[0.2em] text-gray-500 dark:text-zinc-400 transition-colors duration-300">
              <span>BY IIDATECH</span>
              <span className="w-1 h-1 bg-gray-400 dark:bg-zinc-600 rounded-full transition-colors duration-300"></span>
              <span>2026</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-serif font-light tracking-tight">
              <span className="text-gray-900 dark:text-white transition-colors duration-300">{data.topic.split(' ').slice(0, -1).join(' ')}</span>{' '}
              <span className="text-[#FF5733]">{data.topic.split(' ').slice(-1)[0]}</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-gray-600 dark:text-zinc-400 max-w-3xl font-light transition-colors duration-300">
              All Your Dreams deserve to be real
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-4">
              <Badge className="bg-gray-200 dark:bg-zinc-800 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-zinc-700 border-0 px-4 py-2 transition-colors duration-300">
                Generated: {data.generatedDate}
              </Badge>
              {data.industry && (
                <Badge className="bg-gray-200 dark:bg-zinc-800 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-zinc-700 border-0 px-4 py-2 transition-colors duration-300">
                  {data.industry}
                </Badge>
              )}
              {data.location && (
                <Badge className="bg-gray-200 dark:bg-zinc-800 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-zinc-700 border-0 px-4 py-2 flex items-center gap-2 transition-colors duration-300">
                  <Globe className="w-3 h-3" />
                  {data.location}
                </Badge>
              )}
              {data.currency && (
                <Badge className="bg-gray-200 dark:bg-zinc-800 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-zinc-700 border-0 px-4 py-2 flex items-center gap-2 transition-colors duration-300">
                  <Coins className="w-3 h-3" />
                  {currencyInfo.code} ({currencyInfo.symbol})
                </Badge>
              )}
              <Badge className="bg-[#FF5733] text-white border-0 px-4 py-2">
                {data.sections.length} Comprehensive Sections
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <div data-pdf-content className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-16 sm:space-y-24 overflow-x-hidden">
          
          {/* TABLE OF CONTENTS / INDEX */}
          <section className="space-y-4 sm:space-y-6">
            <div className="flex items-baseline gap-3 sm:gap-6">
              <span className="text-3xl sm:text-5xl md:text-6xl text-[#FF5733] font-light">00.</span>
              <h2 className="text-xl sm:text-3xl md:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                Table of Contents
              </h2>
            </div>
            
            <div className="ml-0 sm:ml-12 md:ml-20">
              <div className="flex items-center gap-2 mb-4 sm:mb-6">
                <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF5733]" />
                <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">REPORT SECTIONS</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 sm:gap-3">
                {enabledSections.map((section, index) => (
                  <a
                    key={section.key}
                    href={`#section-${section.key}`}
                    className="bg-gray-100 dark:bg-zinc-900 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-gray-300 dark:border-zinc-800 hover:border-[#FF5733] transition-all group flex items-center gap-2 sm:gap-4"
                  >
                    <span className="text-lg sm:text-2xl text-[#FF5733] font-light group-hover:text-gray-900 dark:group-hover:text-white transition-colors flex-shrink-0">
                      {String(index + 1).padStart(2, '0')}.
                    </span>
                    <span className="text-gray-900 dark:text-white text-xs sm:text-sm group-hover:text-[#FF5733] transition-colors break-words">
                      {section.title}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          </section>

          {/* SECTION 1: EXECUTIVE SUMMARY & STRATEGIC OVERVIEW */}
          {data.sections.includes('executiveSummary') && data.executiveSummary && (
            <section className="space-y-2" id="section-executiveSummary">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6 text-center sm:text-left">
                <span className="text-3xl sm:text-5xl md:text-6xl text-gray-900 dark:text-white font-regular transition-colors duration-300">{getSectionNumber('executiveSummary')}.</span>
                <h2 className="text-xl sm:text-3xl md:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300 break-words">
                  Executive Summary
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-6 text-gray-900 dark:text-white transition-colors duration-300">
                {renderSectionOverview('executiveSummary')}

                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 sm:w-5 sm:h-5 text-gray-900 dark:text-white transition-colors duration-300" />
                  <h3 className="text-xs tracking-[0.2em] text-gray-900 dark:text-white transition-colors duration-300">STRATEGIC OVERVIEW</h3>
                </div>
                
                <div 
                  className="text-gray-900 dark:text-white text-sm sm:text-base md:text-lg max-w-full leading-relaxed [&_h1]:text-gray-900 dark:[&_h1]:text-white [&_h2]:text-gray-900 dark:[&_h2]:text-white [&_h3]:text-gray-900 dark:[&_h3]:text-white [&_h4]:text-gray-900 dark:[&_h4]:text-white [&_p]:text-gray-900 dark:[&_p]:text-white [&_li]:text-gray-900 dark:[&_li]:text-white [&_strong]:text-gray-900 dark:[&_strong]:text-white [&_em]:text-gray-700 dark:[&_em]:text-gray-300 [&_a]:text-[#FF5733] transition-colors duration-300 px-[1px] py-[0px] break-words overflow-wrap-anywhere"
                  dangerouslySetInnerHTML={{
                    __html: data.executiveSummary.replace(/\[(\d+(?:,\d+)*)\]/g, (match, ids) => {
                      return `<sup class="text-[#FF5733] cursor-help ml-0.5 font-medium">[${ids}]</sup>`;
                    })
                  }}
                />
              </div>
            </section>
          )}

          {/* SECTION 2: GLOBAL MARKET SIZE & GROWTH DYNAMICS */}
          {data.sections.includes('marketAnalysis') && data.marketAnalysis && (
            <section className="space-y-6 sm:space-y-8" id="section-marketAnalysis">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6 text-center sm:text-left">
                <span className="text-3xl sm:text-5xl md:text-6xl text-[#FF5733] font-light">{getSectionNumber('marketAnalysis')}.</span>
                <h2 className="text-xl sm:text-3xl md:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300 break-words">
                  Market Analysis
                </h2>
              </div>

              <div className="ml-0 sm:ml-12 md:ml-20 space-y-6 sm:space-y-8">
                {renderSectionOverview('marketAnalysis')}

                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-gray-900 dark:text-white transition-colors duration-300" />
                  <h3 className="text-xs tracking-[0.2em] text-gray-900 dark:text-white transition-colors duration-300 break-words">GLOBAL MARKET SIZE & GROWTH DYNAMICS</h3>
                </div>

                {/* Market Stats Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
                  <div className="bg-gray-100 dark:bg-zinc-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                    <div className="text-xs text-gray-500 dark:text-zinc-500 mb-2 tracking-wider transition-colors duration-300">MARKET SIZE</div>
                    <div className="text-lg sm:text-xl md:text-2xl text-gray-900 dark:text-white font-regular transition-colors duration-300 break-words overflow-wrap-anywhere">{data.marketAnalysis.marketSize}</div>
                    {renderCitation(data.marketAnalysis.sources)}
                  </div>
                  <div className="bg-gray-100 dark:bg-zinc-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                    <div className="text-xs text-gray-500 dark:text-zinc-500 mb-2 tracking-wider transition-colors duration-300">GROWTH RATE</div>
                    <div className="text-lg sm:text-xl md:text-2xl text-emerald-400 font-regular break-words overflow-wrap-anywhere">{data.marketAnalysis.growthRate}</div>
                    {renderCitation(data.marketAnalysis.sources)}
                  </div>
                  <div className="bg-gray-100 dark:bg-zinc-900 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                    <div className="text-xs text-gray-500 dark:text-zinc-500 mb-2 tracking-wider transition-colors duration-300">TAM</div>
                    <div className="text-lg sm:text-xl md:text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words overflow-wrap-anywhere">{data.marketAnalysis.totalAddressableMarket}</div>
                    {renderCitation(data.marketAnalysis.sources)}
                  </div>
                  <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                    <div className="text-xs text-gray-500 dark:text-zinc-500 mb-2 tracking-wider transition-colors duration-300">MARKET SHARE</div>
                    <div className="text-2xl text-[#FF5733] font-light break-words">{data.marketAnalysis.marketShare}</div>
                    {renderCitation(data.marketAnalysis.sources)}
                  </div>
                </div>

              {data.trends && (
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-8 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="flex items-center gap-2 mb-6">
                    <TrendingUp className="w-5 h-5 text-[#FF5733]" />
                    <h4 className="text-lg text-gray-900 dark:text-white font-light transition-colors duration-300">Market Growth Projections (2026-2031)</h4>
                    {renderCitation(data.trends.sources)}
                  </div>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={data.trends.data} key="market-trends-chart">
                      <CartesianGrid key="trends-grid" strokeDasharray="3 3" stroke={isDark ? "#333" : "#e5e7eb"} />
                      <XAxis key="trends-xaxis" dataKey="year" stroke={isDark ? "#888" : "#6b7280"} />
                      <YAxis key="trends-yaxis-left" yAxisId="left" stroke={isDark ? "#888" : "#6b7280"} />
                      <YAxis key="trends-yaxis-right" yAxisId="right" orientation="right" stroke={isDark ? "#888" : "#6b7280"} />
                      <Tooltip 
                        key="trends-tooltip"
                        contentStyle={{ 
                          backgroundColor: isDark ? '#18181b' : '#ffffff', 
                          border: isDark ? '1px solid #333' : '1px solid #e5e7eb',
                          borderRadius: '8px',
                          color: isDark ? '#fff' : '#1f2937'
                        }} 
                      />
                      <Legend key="trends-legend" />
                      <Line key="trends-revenue-line" yAxisId="left" type="monotone" dataKey="revenue" stroke="#FF5733" strokeWidth={3} name="Revenue ($B)" />
                      <Line key="trends-marketshare-line" yAxisId="right" type="monotone" dataKey="marketShare" stroke="#10b981" strokeWidth={2} name="Market Share (%)" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <h4 className="text-gray-900 dark:text-white font-light text-lg mb-4 flex items-center gap-2 transition-colors duration-300">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    Key Market Drivers
                  </h4>
                  <ul className="space-y-3">
                    {data.marketAnalysis.keyDrivers.map((driver: any, idx: number) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-700 dark:text-zinc-300 transition-colors duration-300">
                        <span className="text-emerald-500 mt-1">•</span>
                        <span>
                          {driver.text}
                          {renderCitation(driver.sources)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <h4 className="text-gray-900 dark:text-white font-light text-lg mb-4 flex items-center gap-2 transition-colors duration-300">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    Market Barriers
                  </h4>
                  <ul className="space-y-3">
                    {data.marketAnalysis.marketBarriers.map((barrier: any, idx: number) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-700 dark:text-zinc-300 transition-colors duration-300">
                        <span className="text-orange-500 mt-1">•</span>
                        <span>
                          {barrier.text}
                          {renderCitation(barrier.sources)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
            </section>
          )}

          {/* SECTION 3: CORE PRODUCT ANALYSIS & VALUE PROPOSITION */}
          {data.sections.includes('productAnalysis') && data.productAnalysis && (
            <section className="space-y-8 sm:space-y-8" id="section-productAnalysis">
              <div className="flex flex-col sm-flex-row sm:items-baseline gap-2 sm:gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('productAnalysis')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Product Analysis
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-20 md:ml-20 soace-y-6 sm:space-y-10">
                {renderSectionOverview('productAnalysis')}

                <div className="flex items-center gap-2">
                  <Package className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">CORE PRODUCT & VALUE PROPOSITION</h3>
                </div>

              <Card className="mb-6">
                <CardHeader>
                    <CardTitle>Product Portfolio Overview{renderCitation(data.productAnalysis.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead>Market Share</TableHead>
                          <TableHead>Revenue</TableHead>
                          <TableHead>Growth</TableHead>
                          <TableHead>Customers</TableHead>
                          <TableHead>CSAT</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.productAnalysis.coreProducts.map((product: any, idx: number) => (
                          <TableRow key={idx}>
                            <TableCell className="font-medium">{product.name}</TableCell>
                            <TableCell>{product.marketShare}</TableCell>
                            <TableCell>{product.revenue}</TableCell>
                            <TableCell className="text-green-600">{product.growth}</TableCell>
                            <TableCell>{product.customerBase}</TableCell>
                            <TableCell>{product.satisfaction}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Value Propositions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {data.productAnalysis.valuePropositions.map((vp: any, idx: number) => (
                      <div key={idx} className="border-l-4 border-blue-500 pl-4">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-sm">{vp.category}</span>
                          <span className="text-2xl text-blue-600">{vp.value}</span>
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400 transition-colors duration-300">
                          {vp.description}
                          {renderCitation(vp.sources)}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Competitive Advantages</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-black">
                      {data.productAnalysis.competitiveAdvantages.map((adv: any, idx: number) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-gray-100 dark:bg-zinc-800 rounded-lg transition-colors duration-300 dark:text-white light:text:black">
                          <span className="text-sm font-medium text-black light:text-black dark:text-white transition-colors duration-300">{adv.advantage}</span>
                          <Badge variant={adv.impact === 'High' ? 'default' : 'secondary'}>
                            {adv.impact}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            </section>
          )}

          {/* SECTION 4: ADVANCED TECHNOLOGY TRENDS & R&D PIPELINE */}
          {data.sections.includes('technologyTrends') && data.technologyTrends && (
            <section className="space-y-8 sm-soace-y-8" id="section-technologyTrends">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('technologyTrends')}.</span>
                <h2 className="text-3xl sm:text-4xl md:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Technology & Innovation
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md-ml-20 space-y-8">
                {renderSectionOverview('technologyTrends')}

                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">R&D PIPELINE & EMERGING TECH</h3>
                </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">ANNUAL R&D INVESTMENT</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.technologyTrends.rdInvestment.annual}</div>
                  {renderCitation(data.technologyTrends.rdInvestment.sources)}
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">R&D TEAM SIZE</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.technologyTrends.rdInvestment.teamSize}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">PATENTS FILED</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.technologyTrends.rdInvestment.patentsFiled}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">% OF REVENUE</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.technologyTrends.rdInvestment.percentOfRevenue}</div>
                </div>
              </div>

              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Emerging Technologies & Adoption{renderCitation(data.technologyTrends.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.technologyTrends.emergingTechnologies.map((tech: any, idx: number) => (
                      <div key={idx} className="border rounded-lg p-4 overflow-hidden">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                          <h4 className="font-semibold text-lg break-words">{tech.technology}</h4>
                          <div className="flex flex-wrap gap-2">
                            <Badge variant="outline" className="whitespace-nowrap">{tech.adoptionRate} Adoption</Badge>
                            <Badge className={
                              tech.impact === 'Transformative' ? 'bg-purple-600 whitespace-nowrap' :
                              tech.impact === 'High' ? 'bg-blue-600 whitespace-nowrap' : 'bg-green-600 whitespace-nowrap'
                            }>
                              {tech.impact} Impact
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2 transition-colors duration-300 break-words">{tech.description}</p>
                        <div className="flex flex-wrap gap-4 text-sm">
                          <span className="break-words"><strong>Investment:</strong> {tech.investment}</span>
                          <span className="break-words"><strong>Timeline:</strong> {tech.timeline}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            </section>
          )}

          {/* SECTION 5: COMPETITIVE LANDSCAPE: DEEP ANALYSIS */}
          {data.sections.includes('competitiveAnalysis') && data.competitiveAnalysis && (
            <section className="space-y-8 sm:space-y-8" id="section-competitiveAnalysis">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('competitiveAnalysis')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Competitive Landscape
                </h2>
              </div>
              
              <div className="ml-0 md:ml-12 sm:ml-20 space-y-8">
                {renderSectionOverview('competitiveAnalysis')}

                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">DEEP COMPETITOR ANALYSIS</h3>
                </div>

              {/* Competitive Landscape Overview — from Gemini grounding */}
              {data.competitiveAnalysis.competitiveLandscape && (
                <Card className="mb-6 border-l-4 border-l-[#FF5733]">
                  <CardHeader>
                    <CardTitle>Market Overview{renderCitation(data.competitiveAnalysis.sources)}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">{data.competitiveAnalysis.competitiveLandscape}</p>
                    {data.competitiveAnalysis.marketConcentration && (
                      <div className="mt-3 p-3 bg-gray-50 dark:bg-zinc-800 rounded-lg text-sm text-gray-600 dark:text-gray-400">
                        <strong>Market Concentration:</strong> {data.competitiveAnalysis.marketConcentration}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Competitor Summary Table — improved columns */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Competitor Overview{!data.competitiveAnalysis.competitiveLandscape && renderCitation(data.competitiveAnalysis.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Company</TableHead>
                          <TableHead>Tier</TableHead>
                          <TableHead>Market Share</TableHead>
                          <TableHead>Revenue</TableHead>
                          <TableHead>Employees</TableHead>
                          <TableHead>Founded</TableHead>
                          <TableHead>Threat</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.competitiveAnalysis.competitors.map((comp: any, idx: number) => {
                          const tier = comp.tier || comp.position || 'Competitor';
                          const tierColor =
                            tier.includes('Leader') ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
                            tier.includes('Challenger') ? 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' :
                            tier.includes('Growing') ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
                            'bg-gray-100 text-gray-700 dark:bg-zinc-700 dark:text-zinc-300';
                          const threat = comp.threatLevel || (idx === 0 ? 'High' : idx <= 2 ? 'Medium' : 'Low');
                          const threatColor = threat === 'High' ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-200' : threat === 'Medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-200' : 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-200';
                          const trendIcon = comp.marketShareTrend === 'Growing' ? ' ▲' : comp.marketShareTrend === 'Declining' ? ' ▼' : '';
                          const trendColor = comp.marketShareTrend === 'Growing' ? 'text-green-600' : comp.marketShareTrend === 'Declining' ? 'text-red-500' : '';
                          return (
                            <TableRow key={idx}>
                              <TableCell className="font-medium">
                                {comp.website ? (
                                  <a href={comp.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">{comp.name}</a>
                                ) : comp.name}
                                {comp.headquarters && <div className="text-xs text-gray-400 dark:text-gray-500">{comp.headquarters}</div>}
                              </TableCell>
                              <TableCell>
                                <span className={`px-2 py-0.5 rounded text-xs font-semibold ${tierColor}`}>{tier}</span>
                              </TableCell>
                              <TableCell>
                                <span>{comp.marketShare}</span>
                                {trendIcon && <span className={`ml-1 text-xs font-bold ${trendColor}`}>{trendIcon}</span>}
                              </TableCell>
                              <TableCell className="text-sm">{comp.revenue}</TableCell>
                              <TableCell className="text-sm">{comp.employees}</TableCell>
                              <TableCell className="text-sm">{comp.founded || '—'}</TableCell>
                              <TableCell>
                                <span className={`px-2 py-0.5 rounded text-xs font-semibold ${threatColor}`}>{threat}</span>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Rich Competitor Intelligence Profiles */}
              {data.competitiveAnalysis.competitors && data.competitiveAnalysis.competitors.some((c: any) => c.recentMoves || c.strategy || c.pricingStrategy || c.customerBase || (Array.isArray(c.strengths) && c.strengths.length > 0)) && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Competitor Intelligence Profiles (2025–2026)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-5">
                      {data.competitiveAnalysis.competitors.map((comp: any, idx: number) => {
                        const strengths = Array.isArray(comp.strengths) ? comp.strengths : (comp.strengths ? [comp.strengths] : []);
                        const weaknesses = Array.isArray(comp.weaknesses) ? comp.weaknesses : (comp.weaknesses ? [comp.weaknesses] : []);
                        const keyProducts = Array.isArray(comp.keyProducts) ? comp.keyProducts : (comp.keyProducts ? [comp.keyProducts] : []);
                        const threat = comp.threatLevel || (idx === 0 ? 'High' : idx <= 2 ? 'Medium' : 'Low');
                        const hasRichData = comp.recentMoves || comp.strategy || comp.pricingStrategy || comp.customerBase || strengths.length > 0;
                        if (!hasRichData) return null;
                        return (
                          <div key={idx} className="border border-gray-200 dark:border-zinc-700 rounded-lg p-4 bg-white dark:bg-zinc-900 transition-colors duration-300">
                            <div className="flex flex-wrap items-center gap-2 mb-3">
                              <h4 className="font-semibold text-gray-900 dark:text-white text-base">
                                {comp.website ? (
                                  <a href={comp.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">{comp.name}</a>
                                ) : comp.name}
                              </h4>
                              <span className={`px-2 py-0.5 rounded text-xs font-bold ${threat === 'High' ? 'bg-red-100 text-red-700' : threat === 'Medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>{threat} Threat</span>
                              {comp.tier && <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-zinc-800 px-2 py-0.5 rounded">{comp.tier}</span>}
                              {comp.headquarters && <span className="text-xs text-gray-500 dark:text-gray-400">📍 {comp.headquarters}</span>}
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm mb-3">
                              {keyProducts.length > 0 && (
                                <div className="md:col-span-2">
                                  <span className="font-semibold text-gray-700 dark:text-gray-300">Products/Services: </span>
                                  <span className="text-gray-600 dark:text-gray-400">{keyProducts.join(' · ')}</span>
                                </div>
                              )}
                              {comp.pricingStrategy && (
                                <div>
                                  <span className="font-semibold text-gray-700 dark:text-gray-300">💲 Pricing: </span>
                                  <span className="text-gray-600 dark:text-gray-400">{comp.pricingStrategy}</span>
                                </div>
                              )}
                              {comp.customerBase && (
                                <div>
                                  <span className="font-semibold text-gray-700 dark:text-gray-300">🎯 Customer Base: </span>
                                  <span className="text-gray-600 dark:text-gray-400">{comp.customerBase}</span>
                                </div>
                              )}
                            </div>
                            {(strengths.length > 0 || weaknesses.length > 0) && (
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                                {strengths.length > 0 && (
                                  <div>
                                    <p className="text-xs font-semibold text-green-700 dark:text-green-400 mb-1">✅ Strengths</p>
                                    <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-0.5 list-disc list-inside">
                                      {strengths.slice(0, 4).map((s: string, i: number) => <li key={i}>{s}</li>)}
                                    </ul>
                                  </div>
                                )}
                                {weaknesses.length > 0 && (
                                  <div>
                                    <p className="text-xs font-semibold text-red-600 dark:text-red-400 mb-1">⚠️ Weaknesses</p>
                                    <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-0.5 list-disc list-inside">
                                      {weaknesses.slice(0, 3).map((w: string, i: number) => <li key={i}>{w}</li>)}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            )}
                            {comp.recentMoves && (
                              <div className="p-3 bg-amber-50 dark:bg-amber-950 border-l-4 border-amber-400 rounded-r-lg mb-3">
                                <p className="text-xs font-semibold text-amber-700 dark:text-amber-300 mb-1">📰 Recent Activity (2025–2026)</p>
                                <p className="text-xs text-gray-700 dark:text-gray-300">{comp.recentMoves}</p>
                              </div>
                            )}
                            {comp.strategy && (
                              <div className="text-sm mb-2">
                                <span className="font-semibold text-gray-700 dark:text-gray-300">🧩 Strategy: </span>
                                <span className="text-gray-600 dark:text-gray-400">
                                  {comp.strategy.length > 380 ? comp.strategy.substring(0, 377) + '…' : comp.strategy}
                                </span>
                              </div>
                            )}
                            {comp.differentiationOpportunity && (
                              <div className="p-3 bg-green-50 dark:bg-green-950 border-l-4 border-green-500 rounded-r-lg">
                                <p className="text-xs font-semibold text-green-700 dark:text-green-300 mb-1">💡 Your Differentiation Opportunity</p>
                                <p className="text-xs text-gray-700 dark:text-white">{comp.differentiationOpportunity}</p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Competitive Matrix */}
              {data.competitiveAnalysis.competitiveMatrix && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Competitive Matrix</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {data.competitiveAnalysis.competitiveMatrix.byPrice && (
                        <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                          <p className="text-xs font-bold text-blue-700 dark:text-blue-300 mb-1 uppercase tracking-wider">💲 By Price</p>
                          <p className="text-xs text-gray-700 dark:text-gray-300">{data.competitiveAnalysis.competitiveMatrix.byPrice}</p>
                        </div>
                      )}
                      {data.competitiveAnalysis.competitiveMatrix.byQuality && (
                        <div className="p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                          <p className="text-xs font-bold text-purple-700 dark:text-purple-300 mb-1 uppercase tracking-wider">⭐ By Quality</p>
                          <p className="text-xs text-gray-700 dark:text-gray-300">{data.competitiveAnalysis.competitiveMatrix.byQuality}</p>
                        </div>
                      )}
                      {data.competitiveAnalysis.competitiveMatrix.byInnovation && (
                        <div className="p-3 bg-amber-50 dark:bg-amber-950 rounded-lg">
                          <p className="text-xs font-bold text-amber-700 dark:text-amber-300 mb-1 uppercase tracking-wider">🚀 By Innovation</p>
                          <p className="text-xs text-gray-700 dark:text-gray-300">{data.competitiveAnalysis.competitiveMatrix.byInnovation}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Barriers to Entry */}
              {data.competitiveAnalysis.barriersToEntry && data.competitiveAnalysis.barriersToEntry.length > 0 && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Barriers to Entry</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {data.competitiveAnalysis.barriersToEntry.map((barrier: string, i: number) => (
                        <li key={i} className="flex gap-3 text-sm text-gray-700 dark:text-gray-300">
                          <span className="text-red-500 mt-0.5 shrink-0">🚧</span>
                          <span>{barrier}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {/* Competitive Gaps / Opportunities */}
              {data.competitiveAnalysis.competitiveGaps && data.competitiveAnalysis.competitiveGaps.length > 0 && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Market Gaps & Opportunities</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {data.competitiveAnalysis.competitiveGaps.map((gap: string, i: number) => (
                        <li key={i} className="flex gap-3 text-sm text-gray-700 dark:text-gray-300">
                          <span className="text-green-500 mt-0.5 shrink-0">💡</span>
                          <span>{gap}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {/* Detailed HTML Analysis (fallback from reportDataGenerator path) */}
              {data.competitiveAnalysis.realCompetitorAnalysis && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Detailed Market Player Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div 
                      className="prose prose-sm max-w-none prose-headings:text-gray-900 dark:prose-headings:text-white prose-p:text-gray-700 dark:prose-p:text-gray-300 prose-li:text-gray-700 dark:prose-li:text-gray-300 prose-strong:text-gray-900 dark:prose-strong:text-white transition-colors duration-300"
                      dangerouslySetInnerHTML={{ __html: data.competitiveAnalysis.realCompetitorAnalysis }}
                    />
                  </CardContent>
                </Card>
              )}

              {data.competitiveAnalysis.competitiveFeatures && (
                <Card>
                  <CardHeader>
                    <CardTitle>Competitive Feature Comparison</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <RadarChart data={data.competitiveAnalysis.competitiveFeatures} key="competitive-radar-chart">
                        <PolarGrid key="radar-grid" />
                        <PolarAngleAxis key="radar-angle" dataKey="feature" />
                        <PolarRadiusAxis key="radar-radius" angle={90} domain={[0, 100]} />
                        <Radar key="radar-us" name="Our Company" dataKey="us" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                        <Radar key="radar-leader" name="Market Leader" dataKey="leader" stroke="#ef4444" fill="#ef4444" fillOpacity={0.4} />
                        <Radar key="radar-avg" name="Industry Average" dataKey="avg" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                        <Legend key="radar-legend" />
                        <Tooltip key="radar-tooltip" />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}
            </div>
            </section>
          )}

          {/* SECTION 6: MICRO-SEGMENTATION: GRANULAR ANALYSIS */}
          {data.sections.includes('microSegmentation') && data.microSegmentation && (
            <section className="space-y-8 sm:space-y-8" id="section-microSegmentation">
              <div className="flex flex-com sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('microSegmentation')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Micro-Segmentation
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('microSegmentation')}

                <div className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">GRANULAR CUSTOMER ANALYSIS</h3>
                </div>

              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white transition-colors duration-300">Customer Segments{renderCitation(data.microSegmentation.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Segment</TableHead>
                          <TableHead>Size</TableHead>
                          <TableHead>ARR Value</TableHead>
                          <TableHead>Avg Deal</TableHead>
                          <TableHead>Sales Cycle</TableHead>
                          <TableHead>Churn</TableHead>
                          <TableHead>LTV</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.microSegmentation.segments.map((seg: any, idx: number) => (
                          <TableRow key={idx}>
                            <TableCell className="font-medium">{seg.name}</TableCell>
                            <TableCell>{seg.size}</TableCell>
                            <TableCell>{seg.value}</TableCell>
                            <TableCell>{seg.avgDealSize}</TableCell>
                            <TableCell>{seg.salesCycle}</TableCell>
                            <TableCell className={parseFloat(seg.churnRate) > 10 ? 'text-orange-600' : 'text-green-600'}>
                              {seg.churnRate}
                            </TableCell>
                            <TableCell>{seg.ltv}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {data.microSegmentation.behavioralSegments && (
                <Card className="bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white transition-colors duration-300">Behavioral Segments</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {data.microSegmentation.behavioralSegments.map((seg: any, idx: number) => (
                        <div key={idx} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-4 border border-gray-300 dark:border-zinc-700 rounded-lg bg-gray-100 dark:bg-zinc-800/50 transition-colors duration-300">
                          <div className="flex-1 overflow-hidden">
                            <h4 className="font-semibold text-gray-900 dark:text-white transition-colors duration-300 break-words">{seg.behavior}</h4>
                            <p className="text-sm text-gray-600 dark:text-zinc-400 transition-colors duration-300 break-words">{seg.description}</p>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-center text-sm">
                            <div>
                              <div className="text-xs text-gray-500 dark:text-zinc-500 transition-colors duration-300">Share</div>
                              <div className="font-semibold text-gray-900 dark:text-white transition-colors duration-300 break-words">{seg.percentage}</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-500 dark:text-zinc-500 transition-colors duration-300">Engagement</div>
                              <div className="font-semibold text-gray-900 dark:text-white transition-colors duration-300 break-words">{seg.engagement}</div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-500 dark:text-zinc-500 transition-colors duration-300">Revenue</div>
                              <div className="font-semibold text-gray-900 dark:text-white transition-colors duration-300 break-words">{seg.revenue}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            </section>
          )}

          {/* SECTION 7: GEOGRAPHIC PENETRATION: REGIONAL HUBS */}
          {data.sections.includes('geographicPenetration') && data.geographicPenetration && (
            <section className="space-y-8 sm:space-y-8" id="section-geographicPenetration">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('geographicPenetration')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Geographic Penetration
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('geographicPenetration')}

                <div className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">REGIONAL MARKET HUBS</h3>
                </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-6 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-2 tracking-wider transition-colors duration-300">MARKET PENETRATION RATE</div>
                  <div className="text-4xl text-gray-900 dark:text-white font-light mb-2 transition-colors duration-300">{data.geographicPenetration.penetrationRate}</div>
                  <p className="text-sm text-gray-600 dark:text-zinc-400 transition-colors duration-300">Current market coverage{renderCitation(data.geographicPenetration.sources)}</p>
                </div>

                <Card className="bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white font-light text-lg transition-colors duration-300">Top Markets by Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {data.geographicPenetration.majorCities?.slice(0, 3).map((city: any, idx: number) => (
                        <div key={idx} className="flex items-center justify-between">
                          <span className="font-medium text-gray-900 dark:text-white transition-colors duration-300">{city.city}</span>
                          <div className="text-right">
                            <div className="font-semibold text-emerald-400">{city.revenue}</div>
                            <div className="text-xs text-gray-500 dark:text-zinc-500 transition-colors duration-300">{city.penetration} penetration</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {data.geographicPenetration.expansionOpportunities && (
                <Card className="bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white font-light transition-colors duration-300">Expansion Opportunities{renderCitation(data.geographicPenetration.sources)}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Market</TableHead>
                            <TableHead>TAM Potential</TableHead>
                            <TableHead>Timeline</TableHead>
                            <TableHead>Investment Required</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {data.geographicPenetration.expansionOpportunities.map((opp: any, idx: number) => (
                            <TableRow key={idx}>
                              <TableCell className="font-medium">{opp.market}</TableCell>
                              <TableCell className="text-green-600">{opp.potential}</TableCell>
                              <TableCell>{opp.timeline}</TableCell>
                              <TableCell>{opp.investment}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            </section>
          )}

          {/* SECTION 8: QUARTERLY FINANCIAL PROJECTIONS */}
          {data.sections.includes('financialProjections') && data.financialProjections && (
            <section className="space-y-8" id="section-financialProjections">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('financialProjections')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Financial Projections
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('financialProjections')}

                <div className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">5-YEAR REVENUE & PROFITABILITY</h3>
                </div>

              {/* 5-Year Revenue & Profitability Chart */}
              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white transition-colors duration-300">5-Year Revenue, EBITDA & Net Income Projections{renderCitation(data.financialProjections.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <ComposedChart data={data.financialProjections.yearlyProjections} key="financial-composed-chart">
                      <CartesianGrid key="composed-grid" strokeDasharray="3 3" />
                      <XAxis key="composed-xaxis" dataKey="year" />
                      <YAxis key="composed-yaxis-left" yAxisId="left" label={{ value: 'Amount ($M)', angle: -90, position: 'insideLeft' }} />
                      <YAxis key="composed-yaxis-right" yAxisId="right" orientation="right" label={{ value: 'Margin (%)', angle: 90, position: 'insideRight' }} />
                      <Tooltip 
                        key="composed-tooltip"
                        formatter={(value: any, name: string) => {
                          if (name.includes('Margin')) return `${value}%`;
                          return `$${typeof value === 'number' ? value.toFixed(2) : value}M`;
                        }}
                      />
                      <Legend key="composed-legend" />
                      <Bar key="bar-revenue" yAxisId="left" dataKey="revenue" fill="#3b82f6" name="Revenue" />
                      <Bar key="bar-ebitda" yAxisId="left" dataKey="ebitda" fill="#10b981" name="EBITDA" />
                      <Bar key="bar-netincome" yAxisId="left" dataKey="netIncome" fill="#8b5cf6" name="Net Income" />
                      <Line key="line-ebitda-margin" yAxisId="right" type="monotone" dataKey="ebitdaMargin" stroke="#059669" strokeWidth={3} name="EBITDA Margin %" />
                      <Line key="line-net-margin" yAxisId="right" type="monotone" dataKey="netMargin" stroke="#7c3aed" strokeWidth={3} name="Net Margin %" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Comprehensive 5-Year Financial Table */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Detailed 5-Year Financial Projections</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="font-bold">Year</TableHead>
                          <TableHead className="font-bold">Revenue</TableHead>
                          <TableHead className="font-bold">Gross Profit</TableHead>
                          <TableHead className="font-bold">EBITDA</TableHead>
                          <TableHead className="font-bold">Net Income</TableHead>
                          <TableHead className="font-bold">FCF</TableHead>
                          <TableHead className="font-bold">Growth %</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.financialProjections.yearlyProjections?.map((proj: any, idx: number) => (
                          <TableRow key={idx}>
                            <TableCell className="font-medium">{proj.year}</TableCell>
                            <TableCell className="text-blue-600 font-semibold">{proj.revenueFormatted}</TableCell>
                            <TableCell>{formatAmount(proj.grossProfit * 1000000)}</TableCell>
                            <TableCell className="text-green-600 font-semibold">{proj.ebitdaFormatted}</TableCell>
                            <TableCell className="text-purple-600 font-semibold">{proj.netIncomeFormatted}</TableCell>
                            <TableCell>{proj.freeCashFlowFormatted}</TableCell>
                            <TableCell className="text-emerald-600">{proj.revenueGrowth}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Profitability Margins Chart */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Profitability Margins Over 5 Years</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={data.financialProjections.yearlyProjections} key="margins-line-chart">
                      <CartesianGrid key="margins-grid" strokeDasharray="3 3" />
                      <XAxis key="margins-xaxis" dataKey="year" />
                      <YAxis key="margins-yaxis" label={{ value: 'Margin (%)', angle: -90, position: 'insideLeft' }} />
                      <Tooltip key="margins-tooltip" formatter={(value: any) => `${value}%`} />
                      <Legend key="margins-legend" />
                      <Line key="gross-margin-line" type="monotone" dataKey="grossMargin" stroke="#3b82f6" strokeWidth={3} name="Gross Margin %" />
                      <Line key="ebitda-margin-line" type="monotone" dataKey="ebitdaMargin" stroke="#10b981" strokeWidth={3} name="EBITDA Margin %" />
                      <Line key="net-margin-line" type="monotone" dataKey="netMargin" stroke="#8b5cf6" strokeWidth={3} name="Net Margin %" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Quarterly Projections */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Quarterly Revenue & Profit Projections (Next 2 Years)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={350}>
                    <ComposedChart data={data.financialProjections.quarterlyProjections}>
                      <CartesianGrid key="quarterly-grid" strokeDasharray="3 3" />
                      <XAxis key="quarterly-xaxis" dataKey="quarter" />
                      <YAxis key="quarterly-yaxis-left" yAxisId="left" />
                      <YAxis key="quarterly-yaxis-right" yAxisId="right" orientation="right" />
                      <Tooltip key="quarterly-tooltip" />
                      <Legend key="quarterly-legend" />
                      <Bar key="bar-quarterly-revenue" yAxisId="left" dataKey="revenue" fill="#3b82f6" name="Revenue ($M)" />
                      <Bar key="bar-quarterly-costs" yAxisId="left" dataKey="costs" fill="#ef4444" name="Costs ($M)" />
                      <Line key="line-quarterly-margin" yAxisId="right" type="monotone" dataKey="margin" stroke="#10b981" strokeWidth={3} name="Margin %" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Financial Assumptions */}
              {data.financialProjections.assumptions && (
                <Card className="mb-6 border-blue-200 bg-blue-50">
                  <CardHeader className="bg-blue-100">
                    <CardTitle className="text-blue-900">{data.financialProjections.assumptions.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <ul className="space-y-2">
                      {data.financialProjections.assumptions.items.map((item: string, idx: number) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="text-blue-600 mt-1">•</span>
                          <span className="text-blue-900">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {data.financialProjections.industryFundingMetrics && (
                <Card className="mb-6 border-indigo-200 dark:border-indigo-900 bg-indigo-50 dark:bg-indigo-950/30 transition-colors duration-300">
                  <CardHeader className="bg-indigo-100 dark:bg-indigo-900/40 transition-colors duration-300">
                    <CardTitle className="text-indigo-900 dark:text-indigo-100 transition-colors duration-300">Industry Funding Landscape (2025)</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-indigo-600">{data.financialProjections.industryFundingMetrics.totalFunding2025}</div>
                        <div className="text-xs text-indigo-800 mt-1">Total Industry Funding</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-indigo-600">{data.financialProjections.industryFundingMetrics.totalDeals}</div>
                        <div className="text-xs text-indigo-800 mt-1">Total Deals</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-indigo-600">{data.financialProjections.industryFundingMetrics.avgDealSize}</div>
                        <div className="text-xs text-indigo-800 mt-1">Avg Deal Size</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-indigo-600">{data.financialProjections.industryFundingMetrics.topInvestors.length}</div>
                        <div className="text-xs text-indigo-800 mt-1">Top Investors</div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-indigo-900 mb-2">Leading Investors in This Space:</h4>
                      <div className="flex flex-wrap gap-2">
                        {data.financialProjections.industryFundingMetrics.topInvestors.map((investor: string, idx: number) => (
                          <Badge key={idx} className="bg-indigo-600 text-white">{investor}</Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <PieChart key="revenue-pie-chart">
                        <Pie
                          key="revenue-pie"
                          data={data.financialProjections.revenueDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={(entry) => `${entry.category}: ${entry.value}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {data.financialProjections.revenueDistribution.map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip key="pie-tooltip" />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Cost Structure Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {data.financialProjections.costStructure?.map((cost: any, idx: number) => (
                        <div key={idx} className="flex justify-between items-center border-b pb-2">
                          <span className="text-sm font-medium">{cost.category}</span>
                          <div className="text-right">
                            <div className="font-bold">{cost.amount}</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400 transition-colors duration-300">{cost.percentage} of revenue</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            </section>
          )}

          {/* SECTION 9: SWOT ANALYSIS: INTERNAL & EXTERNAL FACTORS */}
          {data.sections.includes('swotAnalysis') && data.swotAnalysis && (
            <section className="space-y-8" id="section-swotAnalysis">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('swotAnalysis')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  SWOT Analysis
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('swotAnalysis')}

                <div className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">STRATEGIC POSITION ASSESSMENT</h3>
                </div>

              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-green-200 dark:border-green-900 bg-green-50 dark:bg-green-950/30 transition-colors duration-300">
                  <CardHeader className="bg-green-100 dark:bg-green-900/40 transition-colors duration-300">
                    <CardTitle className="text-green-900 dark:text-green-100 transition-colors duration-300">Strengths</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <ul className="space-y-2">
                      {data.swotAnalysis.strengths.map((item: any, idx: number) => (
                        <li key={idx} className="text-sm flex items-start gap-2 text-gray-900 dark:text-gray-100 transition-colors duration-300">
                          <span className="text-green-600 dark:text-green-400 mt-1">•</span>
                          <span>
                            {item.text}
                            {renderCitation(item.sources)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-orange-200 dark:border-orange-900 bg-orange-50 dark:bg-orange-950/30 transition-colors duration-300">
                  <CardHeader className="bg-orange-100 dark:bg-orange-900/40 transition-colors duration-300">
                    <CardTitle className="text-orange-900 dark:text-orange-100 transition-colors duration-300">Weaknesses</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <ul className="space-y-2">
                      {data.swotAnalysis.weaknesses.map((item: any, idx: number) => (
                        <li key={idx} className="text-sm flex items-start gap-2 text-gray-900 dark:text-gray-100 transition-colors duration-300">
                          <span className="text-orange-600 dark:text-orange-400 mt-1">•</span>
                          <span>
                            {item.text}
                            {renderCitation(item.sources)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/30 transition-colors duration-300">
                  <CardHeader className="bg-blue-100 dark:bg-blue-900/40 transition-colors duration-300">
                    <CardTitle className="text-blue-900 dark:text-blue-100 transition-colors duration-300">Opportunities</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <ul className="space-y-2">
                      {data.swotAnalysis.opportunities.map((item: any, idx: number) => (
                        <li key={idx} className="text-sm flex items-start gap-2 text-gray-900 dark:text-gray-100 transition-colors duration-300">
                          <span className="text-blue-600 dark:text-blue-400 mt-1">•</span>
                          <span>
                            {item.text}
                            {renderCitation(item.sources)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 transition-colors duration-300">
                  <CardHeader className="bg-red-100 dark:bg-red-900/40 transition-colors duration-300">
                    <CardTitle className="text-red-900 dark:text-red-100 transition-colors duration-300">Threats</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <ul className="space-y-2">
                      {data.swotAnalysis.threats.map((item: any, idx: number) => (
                        <li key={idx} className="text-sm flex items-start gap-2 text-gray-900 dark:text-gray-100 transition-colors duration-300">
                          <span className="text-red-600 dark:text-red-400 mt-1">•</span>
                          <span>
                            {item.text}
                            {renderCitation(item.sources)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
            </section>
          )}

          {/* SECTION 10: RISK ASSESSMENT & MITIGATION STRATEGY */}
          {data.sections.includes('riskAssessment') && data.riskAssessment && (
            <section className="space-y-8" id="section-riskAssessment">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('riskAssessment')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Risk Assessment
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('riskAssessment')}

                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">RISK & MITIGATION STRATEGY</h3>
                </div>

              <Card className="bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white transition-colors duration-300">Risk Portfolio{renderCitation(data.riskAssessment.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.riskAssessment.risks.map((risk: any, idx: number) => (
                      <div key={idx} className={`border rounded-lg p-4 ${getRiskColor(risk.severity)} transition-colors duration-300`}>
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-lg text-gray-900 dark:text-white transition-colors duration-300">{risk.category}</h4>
                            <p className="text-sm mt-1 text-gray-700 dark:text-gray-300 transition-colors duration-300">{risk.description}</p>
                          </div>
                          <Badge variant="outline" className="ml-4">
                            Severity: {risk.severity}/10
                          </Badge>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4 mt-3 text-sm text-gray-700 dark:text-gray-300 transition-colors duration-300">
                          <div>
                            <strong>Probability:</strong> {risk.probability} | <strong>Impact:</strong> {risk.impact}
                          </div>
                          <div className="text-right">
                            <Badge variant="secondary">{risk.status}</Badge>
                          </div>
                        </div>
                        <div className="mt-2 pt-2 border-t border-current/20">
                          <strong className="text-sm text-gray-900 dark:text-white transition-colors duration-300">Mitigation:</strong>
                          <p className="text-sm mt-1 text-gray-700 dark:text-gray-300 transition-colors duration-300">{risk.mitigation}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            </section>
          )}

          {/* SECTION 11: REGULATORY COMPLIANCE & LEGAL FRAMEWORK */}
          {data.sections.includes('regulatoryCompliance') && data.regulatoryCompliance && (
            <section className="space-y-8" id="section-regulatoryCompliance">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('regulatoryCompliance')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Regulatory Compliance
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('regulatoryCompliance')}

                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">LEGAL & REGULATORY FRAMEWORK</h3>
                </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">ANNUAL INVESTMENT</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.regulatoryCompliance.complianceInvestment.annual}</div>
                  {renderCitation(data.regulatoryCompliance.complianceInvestment.sources)}
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">COMPLIANCE TEAM</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.regulatoryCompliance.complianceInvestment.team}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">ANNUAL AUDITS</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.regulatoryCompliance.complianceInvestment.audits}</div>
                </div>
              </div>

              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Active Compliance Standards{renderCitation(data.regulatoryCompliance.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Standard</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Certification Date</TableHead>
                          <TableHead>Renewal Date</TableHead>
                          <TableHead>Cost</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.regulatoryCompliance.activeCompliance.map((comp: any, idx: number) => (
                          <TableRow key={idx}>
                            <TableCell className="font-medium">{comp.standard}</TableCell>
                            <TableCell>
                              <Badge variant={comp.status === 'Certified' ? 'default' : 'secondary'}>
                                {comp.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{comp.certificationDate}</TableCell>
                            <TableCell>{comp.renewalDate}</TableCell>
                            <TableCell>{comp.cost}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
            </section>
          )}

          {/* SECTION 12: SUPPLY CHAIN LOGISTICS & EFFICIENCY */}
          {data.sections.includes('supplyChain') && data.supplyChain && (
            <section className="space-y-8" id="section-supplyChain">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-center">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('supplyChain')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Supply Chain
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('supplyChain')}

                <div className="flex items-center gap-2">
                  <Truck className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">LOGISTICS & EFFICIENCY ANALYSIS</h3>
                </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">TOTAL SUPPLIERS</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.supplyChain.supplyChainOverview.suppliers}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">CRITICAL SUPPLIERS</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.supplyChain.supplyChainOverview.criticalSuppliers}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">AVG LEAD TIME</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.supplyChain.supplyChainOverview.leadTime}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300 overflow-hidden">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">RELIABILITY</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300 break-words">{data.supplyChain.supplyChainOverview.reliability}</div>
                  {renderCitation(data.supplyChain.supplyChainOverview.sources)}
                </div>
              </div>

              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Key Suppliers{renderCitation(data.supplyChain.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {data.supplyChain.keySuppliers.map((supplier: any, idx: number) => (
                      <div key={idx} className="border rounded-lg p-4 overflow-hidden">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 mb-2">
                          <h4 className="font-semibold break-words">{supplier.supplier}</h4>
                          <Badge variant={
                            supplier.criticality === 'Critical' ? 'destructive' :
                            supplier.criticality === 'High' ? 'default' : 'secondary'
                          } className="whitespace-nowrap self-start">
                            {supplier.criticality}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div className="break-words"><strong>Category:</strong> {supplier.category}</div>
                          <div className="break-words"><strong>Spend:</strong> {supplier.spend}</div>
                          <div className="break-words"><strong>Reliability:</strong> {supplier.reliability}</div>
                          <div className="break-words"><strong>Backup:</strong> {supplier.backup}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            </section>
          )}

          {/* SECTION 13: CONSUMER BEHAVIOR & ADOPTION PATTERNS */}
          {data.sections.includes('consumerBehavior') && data.consumerBehavior && (
            <section className="space-y-8" id="section-consumerBehavior">
              <div className="flex flex-col sm:flex-row sm:items-baseline gap-6 text-center sm:text-left">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('consumerBehavior')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Consumer Behavior
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('consumerBehavior')}

                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">ADOPTION & BEHAVIORAL PATTERNS</h3>
                </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Adoption Funnel{renderCitation(data.consumerBehavior.sources)}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {data.consumerBehavior.adoptionFunnel.map((stage: any, idx: number) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-gray-100 dark:bg-zinc-800 rounded transition-colors duration-300">
                          <span className="font-medium text-gray-900 dark:text-white transition-colors duration-300">{stage.stage}</span>
                          <div className="text-right">
                            <div className="font-semibold text-gray-900 dark:text-white transition-colors duration-300">{stage.count.toLocaleString()}</div>
                            <div className="text-sm text-green-600 dark:text-green-400">{stage.conversion} conv.</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Satisfaction Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {data.consumerBehavior.satisfactionMetrics.map((metric: any, idx: number) => (
                        <div key={idx} className="border-l-4 border-blue-500 dark:border-blue-400 pl-4">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-gray-900 dark:text-white transition-colors duration-300">{metric.metric}</span>
                            <span className="text-xl text-blue-600 dark:text-blue-400">{metric.value}</span>
                          </div>
                          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1 transition-colors duration-300">
                            Industry: {metric.benchmark} | Trend: {metric.trend}
                            {renderCitation(metric.sources)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {data.consumerBehavior.behavioralInsights && (
                <Card>
                  <CardHeader>
                    <CardTitle>Key Behavioral Insights</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {data.consumerBehavior.behavioralInsights.map((insight: any, idx: number) => (
                        <div key={idx} className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg transition-colors duration-300">
                          <Lightbulb className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900 dark:text-white transition-colors duration-300">{insight.insight}</p>
                            <div className="flex gap-4 mt-2 text-xs">
                              <Badge variant={insight.priority === 'High' ? 'default' : 'secondary'}>
                                {insight.priority} Priority
                              </Badge>
                              <span className="text-gray-600 dark:text-gray-400 transition-colors duration-300">Action: {insight.action}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            </section>
          )}

          {/* SECTION 14: DISRUPTIVE OPPORTUNITIES & FUTURE ROADMAP */}
          {data.sections.includes('disruptiveOpportunities') && data.disruptiveOpportunities && (
            <section className="space-y-8" id="section-disruptiveOpportunities">
              <div className="flex flex-col sm:flex-row text-center sm:text-left sm:items-baseline gap-6">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('disruptiveOpportunities')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Disruptive Opportunities
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('disruptiveOpportunities')}

                <div className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">INNOVATION & FUTURE ROADMAP</h3>
                </div>

              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white transition-colors duration-300">Disruptive Forces{renderCitation(data.disruptiveOpportunities.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.disruptiveOpportunities.disruptiveForces.map((force: any, idx: number) => (
                      <div key={idx} className="border border-gray-300 dark:border-zinc-700 rounded-lg p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950/30 dark:to-blue-950/30 transition-colors duration-300">
                        <div className="flex items-start justify-between mb-3">
                          <h4 className="font-semibold text-lg text-gray-900 dark:text-white transition-colors duration-300">{force.force}</h4>
                          <Badge className={
                            force.impact === 'Transformative' ? 'bg-purple-600' :
                            force.impact === 'High' ? 'bg-blue-600' : 'bg-green-600'
                          }>
                            {force.impact} Impact
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mb-3 transition-colors duration-300">{force.description}</p>
                        <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-700 dark:text-gray-300 transition-colors duration-300">
                          <div><strong>Timeline:</strong> {force.timeline}</div>
                          <div><strong>Opportunity:</strong> <span className="text-green-600 dark:text-green-400">{force.opportunity}</span></div>
                          <div><strong>Investment:</strong> {force.investmentRequired}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {data.disruptiveOpportunities.strategicRoadmap && (
                <Card>
                  <CardHeader>
                    <CardTitle>Strategic Roadmap</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {data.disruptiveOpportunities.strategicRoadmap.map((phase: any, idx: number) => (
                        <div key={idx} className="border-l-4 border-blue-500 dark:border-blue-400 pl-6">
                          <h4 className="font-semibold text-lg mb-2 text-gray-900 dark:text-white transition-colors duration-300">{phase.phase}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 transition-colors duration-300">{phase.focus}</p>
                          <ul className="space-y-1 mb-3">
                            {phase.keyInitiatives.map((initiative: string, iIdx: number) => (
                              <li key={iIdx} className="text-sm flex items-start gap-2 text-gray-700 dark:text-gray-300 transition-colors duration-300">
                                <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                                {initiative}
                              </li>
                            ))}
                          </ul>
                          <div className="flex gap-4 text-sm text-gray-700 dark:text-gray-300 transition-colors duration-300">
                            <span><strong>Investment:</strong> {phase.investment}</span>
                            <span><strong>Expected Outcome:</strong> {phase.expectedOutcome}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            </section>
          )}

          {/* SECTION 15: STRATEGIC RECOMMENDATIONS & ACTION PLAN */}
          {data.sections.includes('strategicRecommendations') && data.strategicRecommendations && (
            <section className="space-y-8" id="section-strategicRecommendations">
              <div className="flex flex-col sm:flex-row text-center sm:text-left sm:items-baseline gap-6">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('strategicRecommendations')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Strategic Recommendations
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 sm:md-20 space-y-8">
                {renderSectionOverview('strategicRecommendations')}

                <div className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">ACTIONABLE STRATEGIC PLAN</h3>
                </div>

              <div className="space-y-4">
                {data.strategicRecommendations.recommendations.map((rec: any, idx: number) => (
                  <Card key={idx} className={
                    rec.priority === 'Critical' ? 'border-red-300 dark:border-red-900 bg-red-50 dark:bg-red-950/30 transition-colors duration-300' :
                    rec.priority === 'High' ? 'border-orange-300 dark:border-orange-900 bg-orange-50 dark:bg-orange-950/30 transition-colors duration-300' :
                    'border-blue-300 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/30 transition-colors duration-300'
                  }>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <Badge variant={rec.priority === 'Critical' ? 'destructive' : 'default'} className="mb-2">
                            {rec.priority} Priority
                          </Badge>
                          <CardTitle className="text-lg text-gray-900 dark:text-white transition-colors duration-300">{rec.area}</CardTitle>
                        </div>
                        <div className="text-right text-sm">
                          <div className="font-semibold text-green-600 dark:text-green-400">{rec.expectedImpact}</div>
                          <div className="text-gray-600 dark:text-gray-400 transition-colors duration-300">{rec.timeline}</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm mb-3 text-gray-900 dark:text-white transition-colors duration-300"><strong>Recommendation:</strong> {rec.recommendation}</p>
                      <p className="text-sm mb-3 text-gray-700 dark:text-gray-300 transition-colors duration-300"><strong>Rationale:</strong> {rec.rationale}{renderCitation(rec.sources)}</p>
                      <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-700 dark:text-gray-300 transition-colors duration-300">
                        <div><strong>Investment:</strong> {rec.investment}</div>
                        <div><strong>Owner:</strong> {rec.owner}</div>
                      </div>
                      <div className="mt-3 pt-3 border-t border-gray-300 dark:border-gray-700">
                        <strong className="text-sm text-gray-900 dark:text-white transition-colors duration-300">Key KPIs:</strong>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {rec.kpis.map((kpi: string, kIdx: number) => (
                            <Badge key={kIdx} variant="outline">{kpi}</Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            </section>
          )}

          {/* SECTION 16: INVESTMENT READINESS & ROI PROJECTIONS */}
          {data.sections.includes('investmentReadiness') && data.investmentReadiness && (
            <section className="space-y-8" id="section-investmentReadiness">
              <div className="flex flex-col sm:flex-row text-center sm:text-left sm:items-baseline gap-6">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('investmentReadiness')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Investment Readiness
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('investmentReadiness')}

                <div className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">ROI & INVESTMENT ANALYSIS</h3>
                </div>

              <div className="grid md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">TOTAL FUNDING</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.investmentReadiness.investmentOverview.totalFundingRaised}</div>
                  {renderCitation(data.investmentReadiness.investmentOverview.sources)}
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">VALUATION</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.investmentReadiness.investmentOverview.currentValuation}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">CASH POSITION</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.investmentReadiness.investmentOverview.cashPosition}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">RUNWAY</div>
                  <div className="text-2xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.investmentReadiness.investmentOverview.currentRunway}</div>
                </div>
              </div>

              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>ROI Scenario Analysis{renderCitation(data.investmentReadiness.sources)}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Scenario</TableHead>
                          <TableHead>Probability</TableHead>
                          <TableHead>Year 5 Revenue</TableHead>
                          <TableHead>Exit Valuation</TableHead>
                          <TableHead>IRR</TableHead>
                          <TableHead>MOIC</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.investmentReadiness.roiProjections.map((proj: any, idx: number) => (
                          <TableRow key={idx} className={
                            proj.scenario === 'Bull Case' ? 'bg-green-50 dark:bg-green-950/30' :
                            proj.scenario === 'Bear Case' ? 'bg-red-50 dark:bg-red-950/30' : ''
                          }>
                            <TableCell className="font-medium">{proj.scenario}</TableCell>
                            <TableCell>{proj.probability}</TableCell>
                            <TableCell>{proj.year5Revenue}</TableCell>
                            <TableCell className="text-green-600">{proj.exitValuation}</TableCell>
                            <TableCell>{proj.irr}</TableCell>
                            <TableCell>{proj.moic}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {data.investmentReadiness.investmentHighlights && (
                <Card>
                  <CardHeader>
                    <CardTitle>Investment Highlights</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {data.investmentReadiness.investmentHighlights.map((highlight: any, idx: number) => (
                        <div key={idx} className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg transition-colors duration-300">
                          <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                          <div className="flex-1">
                            <span className="text-sm font-medium text-gray-900 dark:text-white transition-colors duration-300">{highlight.highlight}</span>
                            <div className="flex gap-2 mt-1">
                              <Badge variant="outline" className="text-xs">{highlight.category}</Badge>
                              {renderCitation(highlight.sources)}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
            </section>
          )}

          {/* SECTION 17: SUSTAINABILITY, CIRCULAR ECONOMY & ESG */}
          {data.sections.includes('sustainability') && data.sustainability && (
            <section className="space-y-8" id="section-sustainability">
              <div className="flex flex-col sm:flex-row text-center sm:text-left sm:items-baseline gap-6">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('sustainability')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Sustainability & ESG
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('sustainability')}

                <div className="flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">ENVIRONMENTAL & SOCIAL IMPACT</h3>
                </div>

              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">ESG SCORE</div>
                  <div className="text-3xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.sustainability.esgOverview.esgScore}</div>
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mt-1 transition-colors duration-300">Industry Avg: {data.sustainability.esgOverview.industryAverage}</div>
                  {renderCitation(data.sustainability.esgOverview.sources)}
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">ESG RATING</div>
                  <div className="text-3xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.sustainability.esgOverview.rating}</div>
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mt-1 transition-colors duration-300">Framework: {data.sustainability.esgOverview.framework}</div>
                </div>
                <div className="bg-gray-100 dark:bg-zinc-900 rounded-2xl p-4 border border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                  <div className="text-xs text-gray-500 dark:text-zinc-500 mb-1 tracking-wider transition-colors duration-300">CARBON FOOTPRINT</div>
                  <div className="text-xl text-gray-900 dark:text-white font-light transition-colors duration-300">{data.sustainability.environmental.carbonFootprint.totalEmissions}</div>
                  {renderCitation(data.sustainability.environmental.carbonFootprint.sources)}
                </div>
              </div>

              <Tabs defaultValue="environmental" className="mb-6">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="environmental">Environmental</TabsTrigger>
                  <TabsTrigger value="social">Social</TabsTrigger>
                  <TabsTrigger value="governance">Governance</TabsTrigger>
                </TabsList>

                <TabsContent value="environmental">
                  <Card>
                    <CardHeader>
                      <CardTitle>Environmental Initiatives{renderCitation(data.sustainability.sources)}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {data.sustainability.environmental.initiatives.map((init: any, idx: number) => (
                          <div key={idx} className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold">{init.initiative}</h4>
                              <Badge variant={init.status === 'Active' ? 'default' : 'secondary'}>
                                {init.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2 transition-colors duration-300">{init.description}</p>
                            <div className="grid md:grid-cols-2 gap-4 text-sm">
                              <div><strong>Investment:</strong> {init.investment}</div>
                              <div><strong>Impact:</strong> <span className="text-green-600">{init.impact}</span></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="social">
                  <Card>
                    <CardHeader>
                      <CardTitle>Social Impact & Diversity</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4 mb-6">
                        {data.sustainability.social.diversity.map((metric: any, idx: number) => (
                          <div key={idx} className="flex items-center justify-between p-3 bg-gray-100 dark:bg-zinc-800 rounded-lg transition-colors duration-300">
                            <div>
                              <div className="font-medium text-gray-900 dark:text-white transition-colors duration-300">{metric.metric}</div>
                              <div className="text-sm text-gray-600 dark:text-gray-400 transition-colors duration-300">Target: {metric.target}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl text-blue-600 dark:text-blue-400">{metric.value}</div>
                              <div className="text-xs text-gray-500 dark:text-gray-400 transition-colors duration-300">Industry: {metric.industry}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="governance">
                  <Card>
                    <CardHeader>
                      <CardTitle>Governance Structure</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-3 gap-4 mb-6">
                        <div className="text-center p-4 bg-gray-100 dark:bg-zinc-800 rounded-lg transition-colors duration-300">
                          <div className="text-3xl text-blue-600 dark:text-blue-400 mb-1">{data.sustainability.governance.boardComposition.totalMembers}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400 transition-colors duration-300">Board Members</div>
                        </div>
                        <div className="text-center p-4 bg-gray-100 dark:bg-zinc-800 rounded-lg transition-colors duration-300">
                          <div className="text-3xl text-green-600 dark:text-green-400 mb-1">{data.sustainability.governance.boardComposition.independent}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400 transition-colors duration-300">Independent Directors</div>
                        </div>
                        <div className="text-center p-4 bg-gray-100 dark:bg-zinc-800 rounded-lg transition-colors duration-300">
                          <div className="text-3xl text-purple-600 dark:text-purple-400 mb-1">{data.sustainability.governance.boardComposition.diversity}</div>
                          <div className="text-sm text-gray-600 dark:text-gray-400 transition-colors duration-300">Diversity Rate</div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {data.sustainability.governance.policies.map((policy: any, idx: number) => (
                          <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                            <span className="font-medium">{policy.policy}</span>
                            <Badge variant="outline">{policy.compliance} Compliance</Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
            </section>
          )}

          {/* SECTION 18: FINAL CRITICAL ANALYSIS & SYNTHESIS */}
          {data.sections.includes('criticalAnalysis') && data.criticalAnalysis && (
            <section className="space-y-8" id="section-criticalAnalysis">
              <div className="flex flex-col sm:flex-row text-center sm:text-left sm:items-baseline gap-6">
                <span className="text-6xl text-[#FF5733] font-light">{getSectionNumber('criticalAnalysis')}.</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  Critical Analysis
                </h2>
              </div>
              
              <div className="ml-0 sm:ml-12 md:ml-20 space-y-8">
                {renderSectionOverview('criticalAnalysis')}

                <div className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-[#FF5733]" />
                  <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">FINAL SYNTHESIS & RECOMMENDATIONS</h3>
                </div>

              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader className="bg-gray-200 dark:bg-zinc-800 border-b border-gray-300 dark:border-zinc-700 transition-colors duration-300">
                  <CardTitle className="text-[#FF5733] font-light">Executive Synthesis</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div 
                    className="prose dark:prose-invert max-w-none text-gray-700 dark:text-zinc-300 leading-relaxed transition-colors duration-300"
                    dangerouslySetInnerHTML={{
                      __html: data.criticalAnalysis.executiveSynthesis.replace(/\[(\d+(?:,\d+)*)\]/g, (match, ids) => {
                        return `<sup class="text-[#FF5733] cursor-help ml-0.5 font-medium">[${ids}]</sup>`;
                      })
                    }}
                  />
                </CardContent>
              </Card>

              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader className="bg-gray-200 dark:bg-zinc-800 border-b border-gray-300 dark:border-zinc-700 transition-colors duration-300">
                  <CardTitle className="text-[#FF5733] font-light">Key Findings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.criticalAnalysis.keyFindings.map((finding: any, idx: number) => (
                      <div key={idx} className="border-l-4 border-[#FF5733] pl-4 py-2">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold text-lg text-gray-500">{finding.category}</h4>
                          <Badge variant={
                            finding.significance === 'Critical' ? 'destructive' :
                            finding.significance === 'High' ? 'default' : 'secondary'
                          }>
                            {finding.significance}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-zinc-300 mb-2 transition-colors duration-300">{finding.finding}</p>
                        <p className="text-sm text-gray-600 dark:text-zinc-400 transition-colors duration-300">
                          <strong>Supporting Evidence:</strong> {finding.supporting}
                          {renderCitation(finding.sources)}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader className="bg-gray-200 dark:bg-zinc-800 border-b border-gray-300 dark:border-zinc-700 transition-colors duration-300">
                  <CardTitle className="text-[#FF5733] font-light">Scenario Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {data.criticalAnalysis.scenarioAnalysis.map((scenario: any, idx: number) => (
                      <Card key={idx} className={
                        scenario.scenario.includes('Bull') ? 'bg-green-50 dark:bg-green-950/30 border-green-300 dark:border-green-800 transition-colors duration-300' :
                        scenario.scenario.includes('Bear') ? 'bg-red-50 dark:bg-red-950/30 border-red-300 dark:border-red-800 transition-colors duration-300' :
                        'bg-gray-100 dark:bg-zinc-800 border-gray-300 dark:border-zinc-700 transition-colors duration-300'
                      }>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg text-gray-900 dark:text-white transition-colors duration-300">{scenario.scenario}</CardTitle>
                            <Badge variant="outline">{scenario.revenue2028} by 2028</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm mb-3 text-gray-700 dark:text-zinc-300 transition-colors duration-300">{scenario.narrative}</p>
                          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600 dark:text-zinc-400 transition-colors duration-300">
                            <div>
                              <strong className="text-gray-900 dark:text-white transition-colors duration-300">Key Assumptions:</strong> {scenario.keyAssumptions}
                            </div>
                            <div>
                              <strong className="text-gray-900 dark:text-white transition-colors duration-300">Triggers:</strong> {scenario.triggers}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="mb-6 bg-gray-100 dark:bg-zinc-900 border-[#FF5733] transition-colors duration-300">
                <CardHeader className="bg-gray-200 dark:bg-zinc-800 border-b border-[#FF5733] transition-colors duration-300">
                  <CardTitle className="text-[#FF5733] font-light">Investment Recommendation</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div 
                    className="prose dark:prose-invert max-w-none text-gray-700 dark:text-zinc-300 leading-relaxed transition-colors duration-300"
                    dangerouslySetInnerHTML={{
                      __html: data.criticalAnalysis.conclusions.replace(/\[(\d+(?:,\d+)*)\]/g, (match, ids) => {
                        return `<sup class="text-[#FF5733] cursor-help ml-0.5 font-medium">[${ids}]</sup>`;
                      })
                    }}
                  />
                </CardContent>
              </Card>

              <Card className="bg-gray-100 dark:bg-zinc-900 border-gray-300 dark:border-zinc-800 transition-colors duration-300">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white transition-colors duration-300">Key Recommendations Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <ol className="space-y-2">
                    {data.criticalAnalysis.keyRecommendations.map((rec: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3">
                        <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm">
                          {idx + 1}
                        </span>
                        <span className="text-sm pt-0.5">{rec}</span>
                      </li>
                    ))}
                  </ol>
                </CardContent>
              </Card>
            </div>
            </section>
          )}

          {/* SOURCES & REFERENCES */}
          {data.sources && data.sources.length > 0 && (
            <section className="space-y-8">
              <div className="flex flex-col sm:flex-row text-center sm:text-left sm:items-baseline gap-6">
                <span className="text-6xl text-[#FF5733] font-light">*</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-gray-900 dark:text-white transition-colors duration-300">
                  References & Sources
                </h2>
              </div>

              <div className="ml-0 sm:ml-12 md:ml-20 grid grid-cols-1 md:grid-cols-2 sm:grid-col-1 gap-0">
                <div className="col-span-full">
                  <div className="flex items-center gap-2 mb-6">
                    <BookOpen className="w-5 h-5 text-[#FF5733]" />
                    <h3 className="text-xs tracking-[0.2em] text-[#FF5733]">RESEARCH CITATIONS</h3>
                  </div>
                </div>
                <div className="col-span-full grid grid-cols-1 md:grid-cols-2 gap-4">
                    {data.sources.map((source) => (
                      <div key={source.id} className="bg-gray-100 dark:bg-zinc-900 rounded-xl p-6 border border-gray-300 dark:border-zinc-800 hover:border-[#FF5733]/50 transition-colors">
                        <div className="flex gap-3">
                          <span className="text-[#FF5733] font-mono text-sm">[{source.id}]</span>
                          <div className="flex-1 space-y-1">
                            <h4 className="text-gray-900 dark:text-white font-medium text-sm transition-colors duration-300">{source.title}</h4>
                            <p className="text-gray-600 dark:text-zinc-400 text-xs transition-colors duration-300">{source.author}</p>
                            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-zinc-500 transition-colors duration-300">
                              <span>{source.publication}</span>
                              <span>•</span>
                              <span>{source.date}</span>
                            </div>
                            {source.type && (
                              <Badge className="bg-gray-200 dark:bg-zinc-800 text-gray-900 dark:text-zinc-300 text-xs border-0 mt-2 transition-colors duration-300">
                                {source.type}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
            </section>
          )}

          {/* Footer */}
          <div className="text-center text-gray-500 dark:text-zinc-600 text-xs tracking-wider py-12 border-t border-gray-300 dark:border-zinc-800 transition-colors duration-300">
            <p>BY IIDATECH • 2026 • ALL RIGHTS RESERVED</p>
            <p className="mt-2 text-gray-600 dark:text-zinc-700 transition-colors duration-300">COMPREHENSIVE BUSINESS INTELLIGENCE REPORT</p>
            <p className="mt-3 text-[10px] text-gray-500 dark:text-zinc-600 transition-colors duration-300">
              Research-backed data synthesized from multiple authoritative sources including market research firms,<br />
              industry reports, government statistics, and verified company information
            </p>
          </div>
        </div>
      </div>

      {/* ── Deep Competitor Analysis Modal ─────────────────────────────────── */}
      {compModalOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-start justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto"
          onClick={(e) => { if (e.target === e.currentTarget) setCompModalOpen(false); }}
        >
          <div
            ref={compModalRef}
            className="relative w-full max-w-4xl my-8 bg-white dark:bg-zinc-950 rounded-2xl shadow-2xl border border-gray-200 dark:border-zinc-800 flex flex-col"
            style={{ maxHeight: 'calc(100vh - 4rem)' }}
          >
            {/* Modal Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 rounded-t-2xl">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#FF5733] rounded-lg flex items-center justify-center shrink-0">
                  <Search className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h2 className="font-semibold text-gray-900 dark:text-white text-base">Deep Competitor Analysis</h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 truncate max-w-xs sm:max-w-sm">
                    {data.topic} · {data.location}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCompModalOpen(false)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Prompt context pill */}
            <div className="px-6 pt-4 pb-2">
              <div className="bg-gray-50 dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl px-4 py-3 space-y-2">
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Analysis Parameters Sent to AI</p>
                <div className="flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs bg-[#FF5733]/10 text-[#FF5733] border border-[#FF5733]/20 rounded-full px-3 py-1">
                    <Target className="w-3 h-3 shrink-0" />
                    <span className="font-medium">Idea:</span> {data.topic}
                  </span>
                  {data.industry && (
                    <span className="inline-flex items-center gap-1.5 text-xs bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-full px-3 py-1">
                      <BarChart3 className="w-3 h-3 shrink-0" />
                      <span className="font-medium">Industry:</span> {data.industry}
                    </span>
                  )}
                  {data.location && (
                    <span className="inline-flex items-center gap-1.5 text-xs bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-full px-3 py-1">
                      <Globe className="w-3 h-3 shrink-0" />
                      <span className="font-medium">Location:</span> {data.location}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400">AI finds direct competitors to your idea first, then industry players in your location, then global leaders.</p>
              </div>
            </div>

            {/* Google Search queries used */}
            {compSearchQueries.length > 0 && (
              <div className="px-6 py-2">
                <div className="flex flex-wrap gap-2 items-center">
                  <span className="text-xs font-medium text-gray-500 dark:text-gray-400 shrink-0">🔍 Search queries:</span>
                  {compSearchQueries.map((q, i) => (
                    <span key={i} className="text-xs bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-800">{q}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {/* Loading state */}
              {compLoading && (
                <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-gray-200 dark:border-zinc-700" />
                    <div className="absolute inset-0 w-16 h-16 rounded-full border-4 border-t-[#FF5733] animate-spin" />
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-gray-900 dark:text-white mb-1">Researching competitors for "{data.topic}"</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Finding direct competitors first, then {data.industry ? `${data.industry} ` : ''}players in {data.location}</p>
                  </div>
                  <div className="flex gap-2 mt-2 flex-wrap justify-center">
                    {['Finding competitors', 'Checking financials', 'Analysing growth', 'Building report'].map((step, i) => (
                      <span key={i} className="text-xs px-3 py-1 rounded-full bg-gray-100 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 animate-pulse" style={{ animationDelay: `${i * 0.3}s` }}>
                        {step}…
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Error state */}
              {compError && !compLoading && (
                <div className="flex flex-col items-center justify-center py-12 gap-4">
                  <div className="w-12 h-12 bg-red-100 dark:bg-red-950 rounded-full flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-red-500" />
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-gray-900 dark:text-white mb-1">Analysis Failed</p>
                    <p className="text-sm text-red-600 dark:text-red-400 max-w-md">{compError}</p>
                  </div>
                  <Button
                    onClick={handleDeepCompetitorAnalysis}
                    className="bg-[#FF5733] hover:bg-[#FF5733]/90 text-white border-0 mt-2"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Retry Analysis
                  </Button>
                </div>
              )}

              {/* Results */}
              {compResult && !compLoading && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        Analysis complete — click any competitor to expand / collapse
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        const allKeys: Record<number, boolean> = {};
                        // Count blocks (rough estimate for toggle-all)
                        const headingCount = (compResult.match(/^## /gm) || []).length;
                        const anyCollapsed = Object.values(compExpanded).some(v => v === true);
                        for (let i = 0; i < headingCount; i++) allKeys[i] = anyCollapsed ? false : true;
                        setCompExpanded(allKeys);
                      }}
                      className="text-xs text-[#FF5733] hover:underline"
                    >
                      Toggle All
                    </button>
                  </div>
                  {renderCompetitorResult(compResult)}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            {compResult && !compLoading && (
              <div className="sticky bottom-0 px-6 py-3 border-t border-gray-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 rounded-b-2xl flex items-center justify-between gap-3">
                <p className="text-xs text-gray-400 dark:text-gray-500">
                  Powered by Gemini + Google Search Grounding · Data current as of Q1 2026
                </p>
                <div className="flex gap-2 shrink-0">
                  <Button
                    onClick={handleDeepCompetitorAnalysis}
                    variant="outline"
                    size="sm"
                    className="text-xs border-[#FF5733] text-[#FF5733] hover:bg-[#FF5733] hover:text-white"
                  >
                    <Search className="w-3 h-3 mr-1" />
                    Re-run
                  </Button>
                  <Button
                    onClick={() => setCompModalOpen(false)}
                    size="sm"
                    className="text-xs bg-[#FF5733] hover:bg-[#FF5733]/90 text-white border-0"
                  >
                    Close
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
