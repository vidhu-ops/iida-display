// Script to fix Business Plan theme patterns
// This script fixes all hardcoded dark mode classes in BusinessPlanResults.tsx

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../components/BusinessPlanResults.tsx');

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Define replacements - order matters!
const replacements = [
  // Headings - h3 tags
  {
    from: 'className="font-semibold text-lg mb-2 text-white"',
    to: 'className="font-semibold text-lg mb-2 text-gray-900 dark:text-white transition-colors duration-300"'
  },
  {
    from: 'className="font-semibold text-lg mb-3 text-white"',
    to: 'className="font-semibold text-lg mb-3 text-gray-900 dark:text-white transition-colors duration-300"'
  },
  {
    from: 'className="font-semibold text-lg text-white"',
    to: 'className="font-semibold text-lg text-gray-900 dark:text-white transition-colors duration-300"'
  },
  
  // Small headings - h4 tags  
  {
    from: 'className="font-semibold text-sm mb-2 text-white"',
    to: 'className="font-semibold text-sm mb-2 text-gray-900 dark:text-white transition-colors duration-300"'
  },
  
  // Background boxes - most common
  {
    from: /className="bg-zinc-800 p-3 rounded border border-zinc-700"/g,
    to: 'className="bg-gray-100 dark:bg-zinc-800 p-3 rounded border border-gray-300 dark:border-zinc-700 transition-colors duration-300"'
  },
  {
    from: /className="bg-zinc-800 p-4 rounded-lg border border-zinc-700"/g,
    to: 'className="bg-gray-100 dark:bg-zinc-800 p-4 rounded-lg border border-gray-300 dark:border-zinc-700 transition-colors duration-300"'
  },
  {
    from: /className="border border-zinc-700 rounded-lg p-4 bg-zinc-800 hover:shadow-md transition-shadow"/g,
    to: 'className="border border-gray-300 dark:border-zinc-700 rounded-lg p-4 bg-gray-100 dark:bg-zinc-800 hover:shadow-md transition-all duration-300"'
  },
  {
    from: /className="border border-zinc-700 rounded-lg p-4 bg-zinc-800"/g,
    to: 'className="border border-gray-300 dark:border-zinc-700 rounded-lg p-4 bg-gray-100 dark:bg-zinc-800 transition-colors duration-300"'
  },
  {
    from: /className="border border-zinc-700 rounded-lg p-3 bg-zinc-800"/g,
    to: 'className="border border-gray-300 dark:border-zinc-700 rounded-lg p-3 bg-gray-100 dark:bg-zinc-800 transition-colors duration-300"'
  },
  
  // Tables
  {
    from: /className="bg-zinc-800 border-b border-zinc-700"/g,
    to: 'className="bg-gray-100 dark:bg-zinc-800 border-b border-gray-300 dark:border-zinc-700 transition-colors duration-300"'
  },
  {
    from: /className="border-b border-zinc-800"/g,
    to: 'className="border-b border-gray-200 dark:border-zinc-800 transition-colors duration-300"'
  },
  {
    from: /className="border-b border-zinc-700"/g,
    to: 'className="border-b border-gray-300 dark:border-zinc-700 transition-colors duration-300"'
  },
  
  // Text colors - most common patterns (excluding already fixed ones)
  {
    from: /"text-white"/g,
    to: '"text-gray-900 dark:text-white transition-colors duration-300"'
  },
  {
    from: /"text-zinc-300"/g,
    to: '"text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /"text-zinc-400"/g,
    to: '"text-gray-600 dark:text-zinc-400 transition-colors duration-300"'
  },
  {
    from: /className="text-sm text-zinc-300"/g,
    to: 'className="text-sm text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /className="text-xs text-zinc-300"/g,
    to: 'className="text-xs text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /className="font-bold text-lg text-white"/g,
    to: 'className="font-bold text-lg text-gray-900 dark:text-white transition-colors duration-300"'
  },
  {
    from: /className="font-bold text-sm text-white"/g,
    to: 'className="font-bold text-sm text-gray-900 dark:text-white transition-colors duration-300"'
  },
  {
    from: /className="font-semibold text-white"/g,
    to: 'className="font-semibold text-gray-900 dark:text-white transition-colors duration-300"'
  },
  
  // Background colors for inner sections
  {
    from: /className="bg-zinc-700 p-2 rounded"/g,
    to: 'className="bg-gray-200 dark:bg-zinc-700 p-2 rounded transition-colors duration-300"'
  },
  {
    from: /className="bg-zinc-700"/g,
    to: 'className="bg-gray-200 dark:bg-zinc-700 transition-colors duration-300"'
  },
  
  // Lists
  {
    from: /className="list-disc list-inside text-zinc-300 space-y-1"/g,
    to: 'className="list-disc list-inside text-gray-700 dark:text-zinc-300 space-y-1 transition-colors duration-300"'
  },
  {
    from: /className="list-disc list-inside text-zinc-300 space-y-0.5"/g,
    to: 'className="list-disc list-inside text-gray-700 dark:text-zinc-300 space-y-0.5 transition-colors duration-300"'
  },
  {
    from: /className="list-disc list-inside text-sm text-zinc-300 space-y-0.5"/g,
    to: 'className="list-disc list-inside text-sm text-gray-700 dark:text-zinc-300 space-y-0.5 transition-colors duration-300"'
  },
  {
    from: /className="list-decimal list-inside text-sm text-zinc-300 space-y-1"/g,
    to: 'className="list-decimal list-inside text-sm text-gray-700 dark:text-zinc-300 space-y-1 transition-colors duration-300"'
  },
  
  // Specific table cells
  {
    from: /className="text-left p-2 text-zinc-300"/g,
    to: 'className="text-left p-2 text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /className="text-center p-2 text-zinc-300"/g,
    to: 'className="text-center p-2 text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /className="text-right p-2 text-zinc-300"/g,
    to: 'className="text-right p-2 text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /className="p-2 text-zinc-300"/g,
    to: 'className="p-2 text-gray-700 dark:text-zinc-300 transition-colors duration-300"'
  },
  {
    from: /className="text-right p-2 font-semibold text-white"/g,
    to: 'className="text-right p-2 font-semibold text-gray-900 dark:text-white transition-colors duration-300"'
  },
  {
    from: /className="p-2 font-semibold text-white"/g,
    to: 'className="p-2 font-semibold text-gray-900 dark:text-white transition-colors duration-300"'
  },
];

// Apply all replacements
replacements.forEach(({ from, to }) => {
  content = content.replace(from, to);
});

// Write back to file
fs.writeFileSync(filePath, content, 'utf8');

console.log('✅ Business Plan theme fixed successfully!');
console.log(`Applied ${replacements.length} pattern replacements.`);
