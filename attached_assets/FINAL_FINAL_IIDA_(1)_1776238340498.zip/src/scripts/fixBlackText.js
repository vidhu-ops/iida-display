#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../components/BusinessPlanResults.tsx');
let content = fs.readFileSync(filePath, 'utf8');

// Replace all instances of text-gray-900 with text-black for main text
content = content.replace(/text-gray-900 dark:text-white/g, 'text-black dark:text-white');

// Replace all font-semibold text-white with black in light mode
content = content.replace(/font-semibold text-white"/g, 'font-semibold text-black dark:text-white transition-colors duration-300"');

// Replace all font-bold text-white with black in light mode  
content = content.replace(/font-bold text-lg text-white"/g, 'font-bold text-lg text-black dark:text-white transition-colors duration-300"');
content = content.replace(/font-bold text-sm text-white"/g, 'font-bold text-sm text-black dark:text-white transition-colors duration-300"');
content = content.replace(/font-bold text-white"/g, 'font-bold text-black dark:text-white transition-colors duration-300"');

// Replace standalone text-white with black in light mode
content = content.replace(/"text-white"/g, '"text-black dark:text-white transition-colors duration-300"');
content = content.replace(/text-lg text-white"/g, 'text-lg text-black dark:text-white transition-colors duration-300"');
content = content.replace(/text-sm text-white"/g, 'text-sm text-black dark:text-white transition-colors duration-300"');
content = content.replace(/text-xs text-white"/g, 'text-xs text-black dark:text-white transition-colors duration-300"');

// Replace text-zinc-300 (body text) with black in light mode
content = content.replace(/text-zinc-300"/g, 'text-black dark:text-zinc-300 transition-colors duration-300"');
content = content.replace(/text-sm text-zinc-300/g, 'text-sm text-black dark:text-zinc-300 transition-colors duration-300');
content = content.replace(/text-xs text-zinc-300/g, 'text-xs text-black dark:text-zinc-300 transition-colors duration-300');

// Replace list-disc styles
content = content.replace(/list-disc list-inside text-zinc-300/g, 'list-disc list-inside text-black dark:text-zinc-300 transition-colors duration-300');

// Fix table cells
content = content.replace(/p-2 text-zinc-300"/g, 'p-2 text-black dark:text-zinc-300 transition-colors duration-300"');
content = content.replace(/text-left p-2 text-zinc-300"/g, 'text-left p-2 text-black dark:text-zinc-300 transition-colors duration-300"');
content = content.replace(/text-center p-2 text-zinc-300"/g, 'text-center p-2 text-black dark:text-zinc-300 transition-colors duration-300"');
content = content.replace(/text-right p-2 text-zinc-300"/g, 'text-right p-2 text-black dark:text-zinc-300 transition-colors duration-300"');

// Fix h3/h4 headings
content = content.replace(/font-semibold text-lg mb-2 text-white"/g, 'font-semibold text-lg mb-2 text-black dark:text-white transition-colors duration-300"');
content = content.replace(/font-semibold text-lg mb-3 text-white"/g, 'font-semibold text-lg mb-3 text-black dark:text-white transition-colors duration-300"');
content = content.replace(/font-semibold text-lg text-white"/g, 'font-semibold text-lg text-black dark:text-white transition-colors duration-300"');
content = content.replace(/font-semibold text-sm mb-2 text-white"/g, 'font-semibold text-sm mb-2 text-black dark:text-white transition-colors duration-300"');

fs.writeFileSync(filePath, content, 'utf8');

console.log('✅ All text colors fixed for light mode!');
console.log('   - Changed text-gray-900 → text-black');
console.log('   - Changed text-white → text-black dark:text-white');
console.log('   - Changed text-zinc-300 → text-black dark:text-zinc-300');
