import { createBrowserRouter } from "react-router";
import MainApp from "./components/MainApp";
import { ChecklistView } from "./components/ChecklistView";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: MainApp,
  },
  {
    path: "/checklist",
    Component: ChecklistView,
  },
]);