# Gemini API Setup Guide

This application uses Google's Gemini API to generate real-time, AI-powered business intelligence reports with actual market data, company names, and financial figures.

## Quick Setup (3 Steps)

### Step 1: Get Your Free Gemini API Key

1. Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy your API key

### Step 2: Add API Key to the App

1. Open `/utils/geminiService.ts`
2. Find this line:
   ```typescript
   const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY_HERE';
   ```
3. Replace `YOUR_GEMINI_API_KEY_HERE` with your actual API key:
   ```typescript
   const GEMINI_API_KEY = 'AIzaSy...your-actual-key';
   ```

### Step 3: Test the Integration

1. Refresh your app
2. The blue "Gemini API Not Configured" alert should disappear
3. Generate a report - it will now use real AI-powered data!

## What Changes With Gemini API?

### Without Gemini API (Sample Mode)
- Uses realistic mock data
- Pre-generated company examples
- Static market figures
- Works offline

### With Gemini API (AI Mode)
- ✅ **Real company names** specific to your selected location
- ✅ **Current market data** based on 2026 conditions
- ✅ **Location-specific insights** with actual regulatory info
- ✅ **Brutal honest assessments** with real challenges and opportunities
- ✅ **Accurate financial figures** in your selected currency
- ✅ **Dynamic recommendations** tailored to your specific topic

## Features Powered by Gemini

1. **Research Reports** - Comprehensive business intelligence with real data
2. **Plan It Out** - Actionable business plans with local vendor recommendations
3. **Find Solutions** - Problem-solving with location-specific solutions

## API Usage & Costs

- Gemini API offers a **free tier** with generous limits
- Perfect for testing and small-scale use
- No credit card required for basic usage
- Check current pricing at [Google AI Pricing](https://ai.google.dev/pricing)

## Troubleshooting

### "Gemini API Not Configured" still shows
- Make sure you saved `/utils/geminiService.ts`
- Refresh your browser
- Check that your API key doesn't have extra spaces

### API errors during report generation
- Verify your API key is valid
- Check your internet connection
- Ensure you haven't exceeded free tier limits
- Try with a simpler report (fewer sections)

### Reports still use sample data
- Confirm the API key is correct
- Check browser console for error messages
- The app falls back to mock data if API fails

## Privacy & Security

⚠️ **Important**: Never commit your API key to public repositories!

- Keep your API key private
- Don't share it in screenshots or videos
- Consider using environment variables for production
- Rotate your key if accidentally exposed

## Advanced Configuration

### Adjusting AI Behavior

Edit `/utils/geminiService.ts` to customize:

- **Temperature** (0.0-1.0): Higher = more creative, Lower = more focused
- **Max Tokens**: Control response length
- **Prompts**: Customize what data the AI generates

### Using Environment Variables (Optional)

For production, use environment variables:

```typescript
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || 'YOUR_GEMINI_API_KEY_HERE';
```

Then create a `.env` file:
```
VITE_GEMINI_API_KEY=your-api-key-here
```

## Need Help?

- Check the [Gemini API Documentation](https://ai.google.dev/docs)
- Review error messages in browser console
- Ensure you're using a valid API key

---

**Ready to go?** Get your free API key now: [Google AI Studio](https://aistudio.google.com/app/apikey)
